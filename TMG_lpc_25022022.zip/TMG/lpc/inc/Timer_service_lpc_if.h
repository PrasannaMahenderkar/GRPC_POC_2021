#ifndef _LPCDATA_H
#define _LPCDATA_H
/**********************************************************************
*                                                                     *
* NEC TECHNOLOGIES INDIA CONFIDENTIAL AND PROPRIETARY                 *
*                                                                     *
* COPYRIGHT (C) NEC CORPORATION INDIA, LTD 2021                       *
*                                                                     *
* ALL RIGHTS RESERVED BY NEC CORPORATION, LTD. THIS PROGRAM MUST      *
* BE USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY        *
* NEC CORPORATION, LTD. NO PART OF THIS PROGRAM MAY BE REPRODUCED     *
* OR DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN      *
* PERMISSION OF NEC CORPORATION, LTD.                                 *
*                                                                     *
*USE OF COPYRIGHT NOTICE DOES NOT EVIDENCE PUBLICATION OF THE PROGRAM.*
*                                                                     *
* NEC CORPORATION CONFIDENTIAL AND PROPRIETARY                        *
*                                                                     *
**********************************************************************/ 
/*
 * Title: Timer_service_lpc_if.h
 * Description : This file contains lpc interface code to receive settimer, 
 * cancel timer request from mmp.
 * Revision History
 * Owner                Date                Reason for change  
 * Prasanna M	        16-02-2022          Initial version created
 **********************************************************************/ 

#include "Llpc_lib.h"
#include "string.h"

typedef enum eMmp_module_userid
{
    MMP_EMC_MODULE = 1,
    MMP_EDC_MODULE,
    MMP_E1M_MODULE,
    MMP_ECC_MODULE,
    MMP_EGG_MODULE,
    MMP_ELC_MODULE,
    MMP_EGP_MODULE,
    MMP_EGT_MODULE,
    MMP_EGX_MODULE,
    MMP_EOC_MODULE,
    MMP_EVC_MODULE
}eMmp_module_userid;

typedef enum eTimer_service_lpcqueueid
{
    TMR_SRV_NOQUEUE = 0,
    TMR_SRV_EMC_SETTIMER = 90,
    TMR_SRV_EDC_SETTIMER = 1,
    TMR_SRV_E1M_SETTIMER,
    TMR_SRV_ECC_SETTIMER,
    TMR_SRV_EGG_SETTIMER,
    TMR_SRV_ELC_SETTIMER,
    TMR_SRV_EGP_SETTIMER,
    TMR_SRV_EGT_SETTIMER,
    TMR_SRV_EGX_SETTIMER,
    TMR_SRV_EOC_SETTIMER,
    TMR_SRV_EVC_SETTIMER = 11,
    TMR_SRV_EMC_CANCELTIMER = 91,
    TMR_SRV_EDC_CANCELTIMER = 59,
    TMR_SRV_E1M_CANCELTIMER,
    TMR_SRV_ECC_CANCELTIMER,
    TMR_SRV_EGG_CANCELTIMER,
    TMR_SRV_ELC_CANCELTIMER,
    TMR_SRV_EGP_CANCELTIMER,
    TMR_SRV_EGT_CANCELTIMER,
    TMR_SRV_EGX_CANCELTIMER,
    TMR_SRV_EOC_CANCELTIMER,
    TMR_SRV_EVC_CANCELTIMER = 68,
    TMR_SRV_EMC_TONOTIFICATION = 92,
    TMR_SRV_EDC_TONOTIFICATION = 70,
    TMR_SRV_E1M_TONOTIFICATION,
    TMR_SRV_ECC_TONOTIFICATION,
    TMR_SRV_EGG_TONOTIFICATION,
    TMR_SRV_ELC_TONOTIFICATION,
    TMR_SRV_EGP_TONOTIFICATION,
    TMR_SRV_EGT_TONOTIFICATION,
    TMR_SRV_EGX_TONOTIFICATION,
    TMR_SRV_EOC_TONOTIFICATION,
    TMR_SRV_EVC_TONOTIFICATION = 79
}eTimer_service_lpcqueueid;


struct stTimerData
{
    eMmp_module_userid userid;
    int32_t timerid;
    unsigned long timeout;
    int userdata_size;
    char* userdata;

};

void Timer_service_lpcinit();
void* Timer_service_lpc_settimer_receive(void* param);
void* Timer_service_lpc_canceltimer_receive(void* param);
int Timer_service_lpcsend(eTimer_service_lpcqueueid queueid, stTimerData tstTimerData);
int Timer_Service_lpctimeout_notify(stTimerData tstTimerData);
void* lpcreceive(void* param);
eTimer_service_lpcqueueid Timer_service_get_timeout_notify_queueid(eMmp_module_userid userid);

#endif

