#ifndef HAVE_LPC_ERROR_STR
#define HAVE_LPC_ERROR_STR

char* get_lpc_err(int v);

#endif
