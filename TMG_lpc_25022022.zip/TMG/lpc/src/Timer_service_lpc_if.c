/**********************************************************************
*                                                                     *
* NEC TECHNOLOGIES INDIA CONFIDENTIAL AND PROPRIETARY                 *
*                                                                     *
* COPYRIGHT (C) NEC CORPORATION INDIA, LTD 2021                       *
*                                                                     *
* ALL RIGHTS RESERVED BY NEC CORPORATION, LTD. THIS PROGRAM MUST      *
* BE USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY        *
* NEC CORPORATION, LTD. NO PART OF THIS PROGRAM MAY BE REPRODUCED     *
* OR DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN      *
* PERMISSION OF NEC CORPORATION, LTD.                                 *
*                                                                     *
*USE OF COPYRIGHT NOTICE DOES NOT EVIDENCE PUBLICATION OF THE PROGRAM.*
*                                                                     *
* NEC CORPORATION CONFIDENTIAL AND PROPRIETARY                        *
*                                                                     *
**********************************************************************/ 
/*
 * Title: Timer_service_lpc_if.cc
 * Description : This file contains lpc interface code to receive settimer, 
 * cancel timer request from mmp.
 * Revision History
 * Owner                Date                Reason for change  
 * Prasanna M	        20-01-2022          Initial version created
 **********************************************************************/ 
#include <stdio.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdlib.h>
#include <unistd.h>
#include "Tmg_if_CommonDebug.h"
#include "Timer_service_lpc_if.h"
#include "lpc_error_str.h"
#include "Timer_wrap.h"
#include "DbgCom.h"
/************************************************************************
* Function Name: Timer_service_lpc_settimer_receive(void* param)
*
* @brief:  Receive Thread for set timer
*                               
* @param[in]: void* param
*
* @return:    None
************************************************************************/
void* Timer_service_lpc_settimer_receive(void* param)
{
    char str[100];
    int ret = -1;
    /* Attach to resource */
    int queueId = *(int*)param;
    printf ("Timer_service_lpc_settimer_receive : %d\n",queueId);
    for(;;)
    {
        sleep(5);
        ret = Llpc_attach(queueId);

        if (ret != Jlpc_OK)
        {
            printf ("failure for Llpc_attach for queue id : %d , with return %s\n", queueId,get_lpc_err(Nlpc_errno));
        }
        /*Print the number of resources and get the data */
        

        if(Llpc_check( queueId ) > 0){
        printf ("number of queue elements in queue : %d are %d\n", queueId, Llpc_check( queueId ));
        ret = Llpc_receive (queueId,&str,sizeof (str));
        stTimer_wrap_TimerData tmdata;
        tmdata.userID = str[0];
        tmdata.timerID = str[4];
        tmdata.timeout = str[8];
        
        int userdata_size = str[16];
        //tmdata.userdata_size = str[16];
        tmdata.userdata = (char*)malloc(userdata_size*sizeof(char)); 
        
        //tmdata.servicename = (char*)malloc(strlen(g_servicename)+1);
       // strcpy(tmdata.servicename,g_servicename);
        //strncpy(tmdata.userdata,&str[8],5);
        strncpy(tmdata.userdata,&str[20],userdata_size);
        Timer_wrap_settimer(tmdata);
        if (ret != Jlpc_OK)
        {
           printf ("failure for Llpc_receive with return %s\n", get_lpc_err(Nlpc_errno));
           // return ;
        }

        printf (" tstTimerData.userid ,data received is : %u\n", tmdata.userID);
        printf (" tstTimerData.timerid, data received is : %d\n",tmdata.timerID);
        printf (" tstTimerData.userdata, data received is : %s\n",tmdata.userdata);
        printf ("number of queue elements after receiving: %d\n", Llpc_check( queueId ));

        printf ("number of queues elements after processing : %d\n", Llpc_check(queueId));
       }

        /* Detach the resource */
       ret = Llpc_detach (queueId);
    }
    if (ret != Jlpc_OK)
    {
       printf ("failure for Llpc_detach with return %s\n",get_lpc_err(Nlpc_errno));
    }
}
/************************************************************************
* Function Name: Timer_service_lpc_canceltimer_receive(void* param)
*
* @brief:  Receive thread for cancel timer
*                               
* @param[in]: void* param
*
* @return:    void
************************************************************************/

void* Timer_service_lpc_canceltimer_receive(void* param)
{
    char str[100];
    int ret = -1;
    /* Attach to resource */
    int queueId = *(int*)param;
    printf ("Timer_service_lpc_canceltimer_receive : %d\n",queueId);
    for(;;)
    {
        sleep(5);
        ret = Llpc_attach(queueId);

        if (ret != Jlpc_OK)
        {
            printf ("failure for Llpc_attach for queue id : %d , with return %s\n", queueId,get_lpc_err(Nlpc_errno));
        }
        /*Print the number of resources and get the data */
        printf ("number of queue elements in queue : %d are %d\n", queueId, Llpc_check( queueId ));

        if(Llpc_check( queueId ) > 0){
        ret = Llpc_receive (queueId,&str,sizeof (str));
        Timer_wrap_canceltimer(str[0]);
        if (ret != Jlpc_OK)
        {
           printf ("failure for Llpc_receive with return %s\n", get_lpc_err(Nlpc_errno));
           // return ;
        }
        printf (" tstTimerData.timerid, data received is : %d\n",str[0]);
        printf ("number of queue elements after receiving: %d\n", Llpc_check( queueId ));

        printf ("number of queues elements after processing : %d\n", Llpc_check(queueId));
       }
        /* Detach the resource */
       ret = Llpc_detach (queueId);
    }
    if (ret != Jlpc_OK)
    {
       printf ("failure for Llpc_detach with return %s\n",get_lpc_err(Nlpc_errno));
    }
}
/************************************************************************
* Function Name: Timer_service_lpcsend()
*
* @brief:  This function sends the time out notification to mmp over lpc queue
*                               
* @param[in]: eTimer_service_lpcqueueid queueid, stTimerData tstTimerData
*
* @return:    int
************************************************************************/

int Timer_service_lpcsend(eTimer_service_lpcqueueid queueid, stTimerData tstTimerData)
{
    int ret = Jlpc_NG;
    char str[100] = {0};
   
    /* Attach to resource */
    ret = Llpc_attach (queueid);

    if (ret != Jlpc_OK)
    {
        printf ("failure for Llpc_attach with return %s\n",get_lpc_err(Nlpc_errno));
        return ret;
    }
    printf ("number of queue elements before send: %d\n", Llpc_check( queueid ));
    str[0] = (int)tstTimerData.userid;
    str[4] = tstTimerData.timerid;
    strncpy(&str[8],tstTimerData.userdata,tstTimerData.userdata_size);
    /* send the data */
    ret = Llpc_send (queueid,str,sizeof(str));

    if (ret != Jlpc_OK)
    {
        printf ("failure for Llpc_send with return %s\n",get_lpc_err(Nlpc_errno));
        return ret;
    }

    /* Print the data and queue details */
    printf (" tstTimerData.userid ,data sent is : %d\n", tstTimerData.userid);
    printf (" tstTimerData.timerid, data sent is : %d\n",tstTimerData.timerid);
    printf (" tstTimerData.userdata, data sent is : %s\n",tstTimerData.userdata);
    printf ("number of queue elements after send: %d\n", Llpc_check( queueid ));

    /* Detach from resource */
    ret = Llpc_detach (queueid);

    if (ret != Jlpc_OK)
      {
        printf ("failure for Llpc_detach with return %s\n",get_lpc_err(Nlpc_errno));
      }
    return ret;
}
/************************************************************************
* Function Name: Timer_Service_lpctimeout_notify(stTimerData tstTimerData)
*
* @brief:  This function sends the time out notification to mmp over lpc queue
*                               
* @param[in]: stTimerData tstTimerData
*
* @return:    void
************************************************************************/
int Timer_Service_lpctimeout_notify(stTimerData tstTimerData)
{
   eTimer_service_lpcqueueid queueid = Timer_service_get_timeout_notify_queueid(tstTimerData.userid);
   int ret = Jlpc_NG;
   ret = Timer_service_lpcsend(queueid,tstTimerData);
   return ret;
}
/************************************************************************
* Function Name: Timer_service_get_timeout_notify_queueid()
*
* @brief:  This function sends the time out notification to mmp over lpc queue
*                               
* @param[in]: eTimer_service_lpcqueueid queueid, stTimerData tstTimerData
*
* @return:    eTimer_service_lpcqueueid
************************************************************************/
eTimer_service_lpcqueueid Timer_service_get_timeout_notify_queueid(eMmp_module_userid userid)
{
   eTimer_service_lpcqueueid queueid = TMR_SRV_NOQUEUE;
   switch(userid)
   {
        case MMP_EMC_MODULE:
             queueid = TMR_SRV_EMC_TONOTIFICATION;
             break;
        case MMP_EDC_MODULE:
             queueid = TMR_SRV_EDC_TONOTIFICATION;
             break;
    	case MMP_E1M_MODULE:
             queueid = TMR_SRV_E1M_TONOTIFICATION;
             break;
    	case MMP_ECC_MODULE:
             queueid = TMR_SRV_ECC_TONOTIFICATION;
             break;
    	case MMP_EGG_MODULE:
             queueid = TMR_SRV_EGG_TONOTIFICATION;
             break;
    	case MMP_ELC_MODULE:
             queueid = TMR_SRV_ELC_TONOTIFICATION;
             break;
    	case MMP_EGP_MODULE:
             queueid = TMR_SRV_EGP_TONOTIFICATION;
             break;
    	case MMP_EGX_MODULE:
             queueid = TMR_SRV_EGX_TONOTIFICATION;
             break;
    	case MMP_EOC_MODULE:
             queueid = TMR_SRV_EOC_TONOTIFICATION;
             break;
    	case MMP_EVC_MODULE:
             queueid = TMR_SRV_EVC_TONOTIFICATION;
             break;
    	default: 
	    break;
   }
   return queueid;
}
