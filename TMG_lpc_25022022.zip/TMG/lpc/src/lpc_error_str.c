#include "lpc_error_str.h"

char* get_lpc_err(int v)
{
    switch (v)
    {
      case -1:
      return "Jlpc_NG";
      case 0:
      return "Jlpc_OK";
      case 1:
      return "Jlpc_ERR_SYS";
      case 2 :
      return "Jlpc_ERR_MM";
      case 3 :
      return "Jlpc_ERR_RSC";
      case 4 :
      return "Jlpc_ERR_QUEID";
      case 5 :
      return "Jlpc_ERR_MAID";
      case 6 :
      return "Jlpc_ERR_SIZE";
      case 7 :
      return "Jlpc_ERR_MAILL";
      case 8 :
      return "Jlpc_ERR_MABSY";
      case 9 :
      return "Jlpc_ERR_MANON";
      case 10 :
      return "Jlpc_ERR_SGOPEN";
      case 11 :
      return "Jlpc_ERR_SGFMT";
      case 12 :
      return "Jlpc_ERR_SGPARA";
      case 13 :
      return "Jlpc_ERR_INTR";
      default :
      return "default";
    }
return "default";
}

