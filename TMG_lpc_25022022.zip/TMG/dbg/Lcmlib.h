/* $Id: Lcmlib.h 3.3 2008/05/26 11:18:13 iwamoto Exp LCMV32-0036-01 $ */
/* $Id: Lcmlib.h,v 3.3 2008/05/26 02:18:13 iwamoto Exp $ */
#ifndef _LCMLIB_H
#define _LCMLIB_H

/**************** FILE DESCRIPTION ********************************************/
/*                                                                            */
/*      FILE NAME : Lcmlib.h                                                  */
/*                                                                            */
/*      REVISION  : 0.1     2003/04/18   ����                                 */
/*                  0.2     2003/04/23   ������������������               */   
/*                  0.3     2003/05/14   �ڤ��ؤ����������ɲ�                 */   
/*                  0.4     2003/05/14   Lcm_ThreadAssign()�ɲ�               */
/*                  0.5     2003/06/23   step2 �ͤ��ѹ� ous=3,sta=4,sts=5     */
/*                  0.6     2003/07/22   step3                                */
/*                  0.7     2003/08/04   step3 full release                   */
/*                  0.8     2003/09/01   step4 �ե����빹���������           */
/*                  0.9     2003/10/27   step4.3 �ե����빹������ɲ�         */
/*                  1.0     2004/01/07   step5.0 ���顼����ɲ�               */
/*                                                                            */
/*      REMARKS   : LCM(SBC��Ĺ����)���                                      */
/*                                                                            */
/******************************************************************************/

#include <netinet/in.h>

#include "J_project.h"    /* Jpdt_vEPC */

/*----------------------------------------------------------------------------*/
/*  �������                                                                  */
/*----------------------------------------------------------------------------*/
#define    LcmS_OK                 0  /* OK                                   */
#define    LcmS_NG                -1  /* NG                                   */
#define    LcmS_MEMNG             -2  /* ����Ʊ��NG                         */
#define    LcmS_NOPROC            -3  /* �ץ�����̤��ư */          
#define    LcmS_NOFUNC            -4  /* ��ǽ̵��                             */

/*----------------------------------------------------------------------------*/
/*  ON / OFF                                                                  */
/*----------------------------------------------------------------------------*/
#define    LcmS_OFF                0  /* OFF                                  */
#define    LcmS_ON                 1  /* ON                                   */

/*----------------------------------------------------------------------------*/
/*  LOCK / UNLOCK ���ޥե���                                                  */
/*----------------------------------------------------------------------------*/
#define    LcmS_UNLOCK             0  /* UNLOCK                               */
#define    LcmS_LOCK               1  /* LOCK                                 */

/*----------------------------------------------------------------------------*/
/*  ��Ͽ / ���(�������ܾܺ�����)                                             */
/*----------------------------------------------------------------------------*/
#define    LcmS_REG                1  /* ��Ͽ                                 */
#define    LcmS_DEL                0  /* ���                                 */

/*----------------------------------------------------------------------------*/
/* �Ƴ��ե�����(�������ܾܺ�����)                                             */
/*----------------------------------------------------------------------------*/
#define    LcmS_NONSYSPH       0xfe   /* �Ƴ��ʤ�                             */

/*----------------------------------------------------------------------------*/
/* �Ρ��ɴ�Ϣ���                                                             */
/*----------------------------------------------------------------------------*/
#define LcmS_SELF_NODE             0 /* ��������:���Ρ���                     */
#define LcmS_PAIR_NODE             1 /* ��������:�ڥ��Ρ���                   */
#define LcmS_NON_NODE              0 /* ��������:�����Ρ����ֹ�̵��           */
#define LcmS_ADD_NODE              1 /* ��������:�����Ρ����ֹ��դ�           */

/*----------------------------------------------------------------------------*/
/* ʪ�������м���                                                             */
/*----------------------------------------------------------------------------*/
#define    LcmS_PSV_SBC            0  /* Single Board Computer                */
#define    LcmS_PSV_FS             1  /* File Server                          */

/*----------------------------------------------------------------------------*/
/* ���������м���                                                             */
/*----------------------------------------------------------------------------*/
#define    LcmS_OMP                0  /* O&M�ץ����å�                        */
#define    LcmS_LB                 1  /* �����ɥХ��                       */
#define    LcmS_SGP                2  /* SGSN�ƽ����ץ����å�                 */
#define    LcmS_GGP                3  /* GGSN�ƽ����ץ����å�                 */
#define    LcmS_FS                 4  /* �ե����륵����                       */
#define    LcmS_RMP                5  /* RMP�ץ����å�                        */
#define    LcmS_CLP                6  /* CLP�ץ����å�                        */
#define    LcmS_FEP                7  /* FEP�ץ����å�                        */
#define    LcmS_USP                8  /* USP�ץ����å�                        */
#define    LcmS_ESP                9  /* ESP�ץ����å�                        */
#define    LcmS_CMP               10  /* CMP�ץ����å�                        */
#define    LcmS_MRP               11  /* MRP�ץ����å�                        */
#define    LcmS_NAT               12  /* NAT�ץ����å�                        */
#define    LcmS_VSU               13  /* VSU�ץ����å�                        */
#define    LcmS_ARF               14  /* ARF�ץ����å�                        */
#define    LcmS_CCP               15  /* CCP�ץ����å�                        */
#define    LcmS_UCP               16  /* UCP�ץ����å�                        */
#define    LcmS_PCP               17  /* PCP�ץ����å�                        */
#define    LcmS_SDA               18  /* SDA�ץ����å�                        */
#define    LcmS_PGC               19  /* PGC�ץ����å�                        */
#define    LcmS_PCS               20  /* PCS�ץ����å�                        */
#define    LcmS_SCS               21  /* SCS�ץ����å�                        */
#define    LcmS_SRB               22  /* SRB�ץ����å�                        */
#define    LcmS_IPSCP             29  /* IPSCP�����ƥ�                        */
#define    LcmS_SUSCP             30  /* SCSCP�����ƥ�                        */
#define    LcmS_EBSCP             31  /* EBSCP�����ƥ�                        */

/*----------------------------------------------------------------------------*/
/* ���������                                                                 */
/*----------------------------------------------------------------------------*/
#define    LcmS_MAXBLD            14  /* aTCA�֥졼�ɺ�����                   */
#define    LcmS_MAXPSV            32  /* ʪ���������ֹ������                 */
#define    LcmS_MAXLSV            32  /* �����������ֹ������                 */
#define    LcmS_MAXLSNO           24  /* ���������м�����Ͽ�����             */
#define    LcmS_MAXNODEID          3  /* %N!<%I<oJL:GBgCM                     */
#define    LcmS_HCADDRMAX          4  /* �إ륹�����å���IP���ɥ쥹��������   */
#define    LcmS_SVNAME_MAX         7  /* ������̾�κ�����                     */
#define    LcmS_NODENAME_MAX       7  /* �Ρ��ɼ���ʸ�������Ĺ               */
#ifdef CGE60
#define    LcmS_FW_VER_LEN        16  /* SBC FW�С������ʸ�����󥵥���       */
#else
#define    LcmS_FW_VER_LEN         5  /* SBC FW�С������ʸ�����󥵥���       */
#endif
#define    LcmS_GT_SERVERNUM     128  /* �����ƥ๽����Ͽ�����               */
#define    LcmS_GT_LSVIDNUM       48  /* lcmsg��󥸾�����Ͽ�����            */
#define    LcmS_MAXLSVID          (LcmS_GT_SERVERNUM + LcmS_GT_LSVIDNUM +1)
                                      /* ���������м��̺�����                 */
#ifdef Jpdt_vEPC
#define    LcmS_VMNAME_MAX        32  /* VM�����ӥ�ʸ�������Ĺ               */
#define    LcmS_HOST_IP_MAX       15  /* HOST IPʸ�������Ĺ                  */
#define    LcmS_HOST_IP6_MAX      63  /* HOST IPʸ�������Ĺ(IPv6)            */
#define    LcmS_HOST_ACCOUNT_MAX  15  /* HOST���������ʸ�������Ĺ           */
#endif /* Jpdt_vEPC */
#define LcmS_CHGSTS_SEQMAX   0x7fffffff   /* �������ܺ����κ��祷�������ֹ� */

/*----------------------------------------------------------------------------*/
/* �إ륹�����å���ϩ�������                                                 */
/*----------------------------------------------------------------------------*/
#define    LcmS_HCST_NG             0  /* �إ륹�����å���ϩ�㳲              */
#define    LcmS_HCST_OK             1  /* �إ륹�����å���ϩ����/����         */
#define    LcmS_HCST_START          2  /* �إ륹�����å�����                  */
#define    LcmS_HCST_STOP           3  /* �إ륹�����å����                  */

/*----------------------------------------------------------------------------*/
/* �����о�Ĺ�������                                                         */
/*----------------------------------------------------------------------------*/
#define    LcmS_MD_UUM             0  /* ̤���ѡ���������                     */
#define    LcmS_MD_SGM             1  /* 1�Ų���ž����                        */
#define    LcmS_MD_DLM             2  /* 2�Ų���ž����                        */

/*----------------------------------------------------------------------------*/
/* �����б�ž�������                                                         */
/*----------------------------------------------------------------------------*/
#define    LcmS_ACT                1  /* ACT(�����ӥ��»���)                  */
#define    LcmS_SBY                2  /* SBY(�����ӥ��Ե���)                  */
#define    LcmS_OUS                3  /* OUS(���ڤ�Υ����)                    */
#define    LcmS_STA                4  /* ACT������                            */
#define    LcmS_STS                5  /* SBY������                            */
#define    LcmS_INI                6  /* INI(�������(�Ƴ���))                */
#define    LcmS_FLT                7  /* FLT(�㳲)                            */
#define    LcmS_OUS_FLT            8  /* OUS���֤���FLT����                   */
#define    LcmS_DLD_OUS            9  /* OUS���֤���FW�������������          */
#define    LcmS_NIS               10  /* NIS(�ѥå�����ȴ��)�����Ͼ�������    */
#define    LcmS_POF               11  /* POF(�Ÿ�OFF)                         */
#define    LcmS_NIS_MISINST     0xfe  /* ���ա��������������θ����������̿����� */


/*----------------------------------------------------------------------------*/
/* NIS�װ�                                                                    */
/*----------------------------------------------------------------------------*/
#define    LcmS_UNKNOWN           30  /* NIS:��������                         */
#define    LcmS_COMEOFF           31  /* NIS:�֥졼��ȴ��                     */
#define    LcmS_MISSINSERT        32  /* NIS:������                           */

/*----------------------------------------------------------------------------*/
/* ���Ų�/���Ų�                                                              */
/*----------------------------------------------------------------------------*/
#define    LcmS_SERVERMODE1        1  /* ���Ų�������                         */
#define    LcmS_SERVERMODE2        2  /* ���Ų�������                         */


/*----------------------------------------------------------------------------*/
/* ����������                                                                 */
/*----------------------------------------------------------------------------*/
#define    LcmS_CHGSTOUS           1  /* ���ڤ�Υ��                           */
#define    LcmS_CHGSTINS           2  /* ���Ȥ߹���                           */
#define    LcmS_CHGSTSYS           3  /* ���ڤ��ؤ�                           */
#define    LcmS_CHGSTFUPSTR        4  /* �ե����빹���ڤ��ؤ�(���ե�����)     */
#define    LcmS_CHGSTFUPCAN        5  /* �ե����빹���ڤ��ؤ�(�ڤ��ᤷ)       */
#define    LcmS_CHGSTFDT           6  /* TM�����ּ���                         */
#define    LcmS_CHGSTINSLV0        7  /* ���Ȥ߹���INS(UPDATE)                */
#define    LcmS_CHGSTFUPSTRPH1     8  /* �ե����빹���ڤ��ؤ�(���ե�����PH1�Ƴ�) */

#define    LcmS_CHGNOINTRPT        9  /* act_fup������ OUS -> ACT�ڤ��ؤ�     */
#define   LcmS_SNG_CHGSTFUPSTR    10 /* �ե����빹���ڤ��ؤ�(���ե����롦PH2�Ƴ�) */
#define   LcmS_SNG_CHGSTFUPSTRPH3 11 /* �ե����빹���ڤ��ؤ�(���ե����롦PH3�Ƴ�) */
#define   LcmS_SNG_CHGSTFUPCAN    12 /* �ե����빹���ڤ��ᤷ(��ե����롦PH3�Ƴ�) */
#define   LcmS_ALL_CHGSTFUPCAN    13 /* �ե����빹���ڤ��ᤷ(�������٥���������е�ե����� */
#define    LcmS_CHGSTOUS2         14  /* ���ڤ�Υ��(FTM����)                  */

#define   LcmS_CHGSTMGRCAN        15 /* �ޥ������ڤ��ᤷ */

#define    LcmS_SWCHKPROC     10 /* ������礻�� ACT-OUSOUS      */

/*----------------------------------------------------------------------------*/
/* ���٥�������ǡ��� ���������׵��                                          */
/*----------------------------------------------------------------------------*/
#define    LcmS_SWACT              1  /* ACT����                              */
#define    LcmS_SWSBY              2  /* SBY����                              */
#define    LcmS_SWOUS              3  /* OUS����                              */

/*----------------------------------------------------------------------------*/
/* ��������                                                                   */
/*----------------------------------------------------------------------------*/
#define    LcmS_SWPROC             1  /* �ڤ��ؤ�����                         */
#define    LcmS_FAILSWPROC         2  /* �㳲�ڤ��ؤ�����                     */
#define    LcmS_COMPPROC           3  /* �������ܴ�λ����                     */

/*----------------------------------------------------------------------------*/
/* ���٥�������ǡ��� �����������λ�                                          */
/*----------------------------------------------------------------------------*/
#define    LcmS_O_ACT              1  /* ��������ACT                          */
#define    LcmS_O_SBY              2  /* ��������SBY                          */
#define    LcmS_O_OUS              3  /* ��������OUS                          */
#define    LcmS_O_INI              6  /* ��������INI                          */
#define    LcmS_O_FLT              7  /* ��������FLT                          */
#define    LcmS_M_ACT            101  /* ��Ĺ¾������ACT                      */
#define    LcmS_M_SBY            102  /* ��Ĺ¾������SBY                      */
#define    LcmS_M_OUS            103  /* ��Ĺ¾������OUS                      */
#define    LcmS_M_INI            106  /* ��Ĺ¾������INI                      */
#define    LcmS_M_FLT            107  /* ��Ĺ¾������FLT                      */
#define    LcmS_M_NIS            110  /* ��Ĺ¾������NIS                      */
#define    LcmS_M_POF            111  /* ��Ĺ¾������POF                      */

/*----------------------------------------------------------------------------*/
/* ous���������                                                              */
/*----------------------------------------------------------------------------*/
#define   LcmS_OUSCHG_EXE         1  /* ous������                             */
#define   LcmS_OUSCHG_END         2  /* ous���ܴ�λ�Ѥ�                       */

/*----------------------------------------------------------------------------*/
/* �������� (Lcm_dldinf API)                                                  */
/*----------------------------------------------------------------------------*/
#define    LcmS_DLDINF             0  /* BIOS�ե����०�����ɤ߽Ф�����       */
#define    LcmS_DLDINF_BMC         1  /* BMC�ե����०�����ɤ߽Ф�����        */
#define    LcmS_DLDINF_MMC         2  /* MMC�ե����०�����ɤ߽Ф�����        */

/*----------------------------------------------------------------------------*/
/* ���٥�������ǡ��� ���ꥯ�ꥢ�׵��                                      */
/*----------------------------------------------------------------------------*/
#define    LcmS_MC_SVCTL           1  /* ���ޥ�ɷ�����                       */
#define    LcmS_MC_SVCTLNG         2  /* ���ޥ�ɷ�����NG                     */
#define    LcmS_MC_HEALTHNG        3  /* �إ륹�����å��۾�                   */
#define    LcmS_MC_PH2CHG          4  /* PH2ƻϢ��Ƴ�(PH�쥹/PH1����)        */
#define    LcmS_MC_MEMNG           5  /* ����Ʊ���Σ�     ����              */

/*----------------------------------------------------------------------------*/
/* �����з����إ⡼�����                                                     */
/*----------------------------------------------------------------------------*/
#define LcmS_CHGMODE1              1  /* ���ꥯ�ꥢ̵��                     */
#define LcmS_CHGMODE2              2  /* ���ꥯ�ꥢͭ��                     */

/*----------------------------------------------------------------------------*/
/* ���������߾���                                                             */
/*----------------------------------------------------------------------------*/
#define    LcmS_SVCONF_NON         0  /* ����������̤�»�                     */
#define    LcmS_SVCONF_CRE         1  /* ���������߼»���                     */
#define    LcmS_SVCONF_DEL         2  /* �����и��߼»���                     */

/*----------------------------------------------------------------------------*/
/* �������������׵ᡦ���μ���                                                 */
/*----------------------------------------------------------------------------*/
#define    LcmS_CREREG             0  /* ������������Ͽ�׵�                   */
#define    LcmS_CRECMT             1  /* ���������߳�������                   */
#define    LcmS_CRECAN             2  /* ���������߲������                   */
#define    LcmS_DELREG             3  /* �����и�����Ͽ�׵�                   */
#define    LcmS_DELCMT             4  /* �����и��߳�������                   */
#define    LcmS_DELCAN             5  /* �����и��߲������                   */

/*----------------------------------------------------------------------------*/
/* ���������߾���                                                             */
/*----------------------------------------------------------------------------*/
#define    LcmS_SVSTAT_NON         0  /* ����̤�»�                           */
#define    LcmS_SVSTAT_CREREG      1  /* ������Ͽ�����                       */
#define    LcmS_SVSTAT_CRE         2  /* ���������                           */
#define    LcmS_SVSTAT_LOAD        3  /* �����������                         */
#define    LcmS_SVSTAT_CREPRE      4  /* ���߳����������                     */
#define    LcmS_SVSTAT_CRECMT1     5  /* ���߳������"1"                      */
#define    LcmS_SVSTAT_CRECMT2     6  /* ���߳������"2"                      */
#define    LcmS_SVSTAT_CRECAN      7  /* ���߲�������                       */
#define    LcmS_SVSTAT_DELREG      8  /* ������Ͽ����                         */
#define    LcmS_SVSTAT_DELCMT1     9  /* ���߳������"1"                      */
#define    LcmS_SVSTAT_DELCMT2    10  /* ���߳������"2"                      */
#define    LcmS_SVSTAT_DELCAN     11  /* ���߲�������                       */
#define    LcmS_SVSTAT_SELFCRE    20  /* �����������������                   */
#define    LcmS_SVSTAT_CREPRE_NG  30  /* ���߳�������ᤷ�����»���           */

/*----------------------------------------------------------------------------*/
/* �����Ρ��ɺƳ������                                                       */
/*----------------------------------------------------------------------------*/
#define    LcmS_LN_NONODESTART        0 /* �����ƥ൯ư��������Ρ������������� */
#define    LcmS_LN_RCVNODEPH          1 /* �����Ρ��ɺƳ����μ�����           */
#define    LcmS_LN_NODECOMPWAIT       2 /* �����Ρ��ɵ�ư��λ�����Ԥ���       */
#define    LcmS_LN_SWCHANGEWAIT       3 /* �����Ρ��ɾ���������               */
#define    LcmS_LN_STANDARDWAIT       4 /* �����Ρ����̾����                 */

/*----------------------------------------------------------------------------*/
/* ���顼���                                                                 */
/*----------------------------------------------------------------------------*/
#define    LcmE_STATERR            1  /* �Ρ��ɾ��֥��顼                     */
#define    LcmE_MSGERR             2  /* ���٥���������顼                   */
#define    LcmE_SETSTATERR         3  /* ���ܾ��ֻ��ꥨ�顼                   */
#define    LcmE_SETPROCERR         4  /* �ڤ��ؤ��������̻��ꥨ�顼           */
#define    LcmE_SETRESULTERR       5  /* ������̻��ꥨ�顼                   */
#define    LcmE_PRMERR             6  /* �ѥ�᡼�����顼                     */
#define    LcmE_FERR               7  /* ����ɽ���������顼                   */
#define    LcmE_NINSTERR           8  /* ������̤����                         */
#define    LcmE_NSTRERR            9  /* ���ϥ���饯���ʤ�                   */
#define    LcmE_SYSERR            10  /* �����ƥ२�顼                       */
#define    LcmE_VERR              11  /* ���ϰϳ����顼                       */
#define    LcmE_COMMERR           12  /* �����д��̿����顼                   */
#define    LcmE_SYSSTATERR        13  /* �����ƥ���֥��顼                   */
#define    LcmE_RBUSYERR          14  /* �꥽�����ӥ���                       */
#define    LcmE_OVR               15  /* ��Ͽ�������С�                       */
#define    LcmE_ALREADY           16  /* ��Ͽ�Ѥ�                             */
#define    LcmE_HCSTOP            17  /* �إ륹�����å���߾���               */
#define    LcmE_SETSVINFOERR      18  /* �����߽������̻��ꥨ�顼             */
#define    LcmE_SVMODEERR         19  /* �����о�Ĺ������Ŭ�����顼           */
#define    LcmE_DBLSTS            20  /* ����׵ᥨ�顼                       */
#define    LcmE_HC_STERR          21  /* ��Ų��إ륹�����å���ư/��߼���    */
#define    LcmE_HC_ERR            22  /* �إ륹�����å��۾���                 */
#define    LcmE_ACTFSERR          23  /* FS��ACT)�����аʳ����顼             */
#define    LcmE_NODATA            24  /* �����ʤ�                             */
#define    LcmE_SVCONFERR         25
#define    LcmE_FREADERR          26
#define    LcmE_MEMRPLERR         27  /* ����ž���楨�顼                   */
#define    LcmE_FILECTRLERR       28  /* �����о��֤�ȼ���ե��������顼   */

/*----------------------------------------------------------------------------*/
/* �㳲���                                                                   */
/*----------------------------------------------------------------------------*/
/* �������и��о㳲 */
#define LcmS_FLT_HOME_MIN  40 /* �������и��о㳲�Ǿ���                      */
#define LcmS_FLT_HOME_MAX  69 /* �������и��о㳲������                      */

#if defined(CGHV) || defined(RHEL)
#define LcmS_FLT_HOME_MIN2 1024 /* �������и��о㳲�Ǿ���2                   */
#define LcmS_FLT_HOME_MAX2 1100 /* �������и��о㳲������2                   */
#endif

#define LcmS_FLT_HOME_RBD_MIN 1200 /* RBD��syslog�㳲�װ��ֹ�Ǿ���          */
#define LcmS_FLT_HOME_RBD_MAX 1299 /* RBD��syslog�㳲�װ��ֹ������          */

/* CMM���о㳲 */
#define LcmS_FLT_CMM_MIN   70 /* CMM���о㳲�Ǿ���                           */
#define LcmS_FLT_CMM_MAX  252 /* CMM���о㳲������                           */
#define LcmS_FLT_CMM_MIN2 259 /* CMM���о㳲�Ǿ����ɲ�ʬ(�Ǿ����-1)         */
#define LcmS_FLT_CMM_MAX2 496 /* CMM���о㳲�������ɲ�ʬ(�������+1)         */
/*
 * CGE3.1 syslog�Ǥ��Ф��㳲�װ�
 */
#define  LcmS_FLT_FSYS                             41     /* file system fault */
#define  LcmS_FLT_IDE                              42     /* ide disk fault */
#define  LcmS_FLT_SCSI                             43     /* scsi device fault */
#define  LcmS_FLT_HC                               44     /* HC�۾�۾�(T.O.)     "" */
#define  LcmS_FLT_SAS                              45     /* Sas driver fault  */
/*
 * CGE4.0 syslog�Ǥ��Ф��㳲�װ�
 */
#define LcmS_FLT_KERN                              46     /* kernel fault         */
#define LcmS_FLT_OTHER                             47     /* other hardware fault */
#define LcmS_FLT_BLK                               48     /* block device fault   */
#define LcmS_FLT_IPMI                              49     /* IPMI fault           */
/*
 * CGE6.0 syslog�Ǥ��Ф��㳲�װ�
 */
#define LcmS_FLT_FCDRV                             50     /* fc driver fault   */
#define LcmS_FLT_MLX4DRV                           51     /* mlx4 driver fault */
#define LcmS_FLT_SASDEV                            52     /* sas device fault  */
#define LcmS_FLT_SCSIDRV                           53     /* scsi driver fault */
#define LcmS_FLT_NETDRIVER                         54     /* network driver fault */
/*
 * vEPC ����������ȥߥɥ��Ǥ��Ф��㳲�װ�
 */
#ifdef Jpdt_vEPC
    #define LcmS_FLT_PMSERVER                          59     /* PM Server hardware fault */
#endif /* Jpdt_vEPC */
/*
 * Lcm_fltind�㳲�װ�
 */
#define  LcmS_FLT_EVLDG                            60     /* Server diagnosis stop */
#define  LcmS_FLT_NIC                              61     /* nic link double fault */
#define  LcmS_FLT_LTMNTP                           62     /* ntp control fault */
#define  LcmS_FLT_LDKERR                           63     /* disk read diagnosis fault */
#define  LcmS_FLT_RAIDFERR                         64     /* raid disk diagnosis  fault */
#define  LcmS_FLT_RAIDUNUSE                        65     /* raid disk unusable */
#define  LcmS_FLT_RAIDUNWTH                        66     /* unable to watch RAID device */
#define  LcmS_FLT_DKNORSP                          67     /* disk no response */
#define  LcmS_FLT_CR_ALARM                         68     /* critical alarm */
#define  LcmS_FLT_DKEIO                            69     /* EIO ERROR */
/*
 * CMM���󥵡��㳲�װ�
 */
#define  LcmS_FLT_IPMB_AB                          71     /* ipmb link double fault */
#define  LcmS_FLT_IPMB_A                           72     /* ipmb-a link fault */
#define  LcmS_FLT_IPMB_B                           73     /* ipmb-b link fault */
#define LcmS_FLT_IPMB_RECOVER                      74     /* IPMB ξ������   "" */
#define  LcmS_FLT_BBTMP_HIASRT                     75     /* Baseboard Temp Upper critical going high asserted */
#define  LcmS_FLT_BBTMP_LOWASRT                    76     /* Baseboard Temp Lower critical going high asserted */
#define  LcmS_FLT_CPU1TEMP_HIASRT                  77     /* CPU 1 Temp Upper critical going high asserted */
#define  LcmS_FLT_CPU1TEMP_LOWASRT                 78     /* CPU 1 Temp Lower critical going high asserted */
#define  LcmS_FLT_CPU2TEMP_HIASRT                  79     /* CPU 2 Temp Upper critical going high asserted */
#define  LcmS_FLT_CPU2TEMP_LOWASRT                 80     /* CPU 2 Temp Lower critical going high asserted */
#define  LcmS_FLT_CPU1PROCHOT_HIASRT               81     /* CPU 1 PROCHOT Upper critical going high asserted */
#define  LcmS_FLT_CPU1PROCHOT_LOWASRT              82     /* CPU 1 PROCHOT Lower critical going high asserted */
#define  LcmS_FLT_CPU2PROCHOT_HIASRT               83     /* CPU 2 PROCHOT Upper critical going high asserted */
#define  LcmS_FLT_CPU2PROCHOT_LOWASRT              84     /* CPU 2 PROCHOT Lower critical going high asserted */
#define  LcmS_FLT_P3_3VSB_HIASRT                   85     /* +3.3VSB Upper critical going high asserted */
#define  LcmS_FLT_P3_3VSB_LOWASRT                  86     /* +3.3VSB Lower critical going high asserted */
#define  LcmS_FLT_P5VSB_HIASRT                     87     /* +5VSB Upper critical going high asserted */
#define  LcmS_FLT_P5VSB_LOWASRT                    88     /* +5VSB Lower critical going high asserted */
#define  LcmS_FLT_P1_8VSB_HIASRT                   89     /* +1.8VSB Upper critical going high asserted */
#define  LcmS_FLT_P1_8VSB_LOWASRT                  90     /* +1.8VSB Lower critical going high asserted */
#define  LcmS_FLT_VBAT_HIASRT                      91     /* VBAT Upper critical going high asserted */
#define  LcmS_FLT_VBAT_LOWASRT                     92     /* VBAT Lower critical going high asserted */
#define  LcmS_FLT_P1_2V_HIASRT                     93     /* +1.2V Upper critical going high asserted */
#define  LcmS_FLT_P1_2V_LOWASRT                    94     /* +1.2V Lower critical going high asserted */
#define  LcmS_FLT_VVTDDR_HIASRT                    95     /* VVT DDR Upper critical going high asserted */
#define  LcmS_FLT_VVTDDR_LOWASRT                   96     /* VVT DDR Lower critical going high asserted */
#define  LcmS_FLT_P1_8V_HIASRT                     97     /* +1.8V Upper critical going high asserted */
#define  LcmS_FLT_P1_8V_LOWASRT                    98     /* +1.8V Lower critical going high asserted */
#define  LcmS_FLT_P2_5V_HIASRT                     99     /* +2.5V Upper critical going high asserted */
#define  LcmS_FLT_P2_5V_LOWASRT                    100    /* +2.5V Lower critical going high asserted */
#define  LcmS_FLT_P3_3V_HIASRT                     101    /* +3.3V Upper critical going high asserted */
#define  LcmS_FLT_P3_3V_LOWASRT                    102    /* +3.3V Lower critical going high asserted */
#define  LcmS_FLT_P5V_HIASRT                       103    /* +5V Upper critical going high asserted */
#define  LcmS_FLT_P5V_LOWASRT                      104    /* +5V Lower critical going high asserted */
#define  LcmS_FLT_P12V_HIASRT                      105    /* +12V Upper critical going high asserted */
#define  LcmS_FLT_P12V_LOWASRT                     106    /* +12V Lower critical going high asserted */
#define  LcmS_FLT_M12V_HIASRT                      107    /* -12V Upper critical going high asserted */
#define  LcmS_FLT_M12V_LOWASRT                     108    /* -12V Lower critical going high asserted */
#define  LcmS_FLT_CPUCOREVOL_HIASRT                109    /* CPU Core Voltage Upper critical going high asserted */
#define  LcmS_FLT_CPUCOREVOL_LOWASRT               110    /* CPU Core Voltage Loewr critical going high asserted */
#define  LcmS_FLT_P1_5V_HIASRT                     111    /* +1.5V Upper critical going high asserted */
#define  LcmS_FLT_P1_5V_LOWASRT                    112    /* +1.5V Lower critical going high asserted */
#define  LcmS_FLT_MUL_BBP1_25V_UPNCRIT             113    /* Baseboard +1.25V Upper non-critical going high asserted */
#define  LcmS_FLT_MUL_BBP1_25V_UPCRIT              114    /* Baseboard +1.25V Upper critical going high asserted */
#define  LcmS_FLT_MUL_BBP1_25V_LOWNCRIT            115    /* Baseboard +1.25V Lower non-critical going high asserted */
#define  LcmS_FLT_MUL_BBP1_25V_LOWCRIT             116    /* Baseboard +1.25V Lower critical going high asserted */
#define  LcmS_FLT_MUL_BBP2_5V_UPNCRIT              117    /* Baseboard +2.5V Upper non-critical going high asserted */
#define  LcmS_FLT_MUL_BBP2_5V_UPCRIT               118    /* Baseboard +2.5V Upper critical going high asserted */
#define  LcmS_FLT_MUL_BBP2_5V_LOWNCRIT             119    /* Baseboard +2.5V Lower non-critical going high asserted */
#define  LcmS_FLT_MUL_BBP2_5V_LOWCRIT              120    /* Baseboard +2.5V Lower critical going high asserted */
#define  LcmS_FLT_MUL_BBP3_3V_UPNCRIT              121    /* Baseboard +3.3V Upper non-critical going high asserted */
#define  LcmS_FLT_MUL_BBP3_3V_UPCRIT               122    /* Baseboard +3.3V Upper critical going high asserted */
#define  LcmS_FLT_MUL_BBP3_3V_LOWNCRIT             123    /* Baseboard +3.3V Lower non-critical going high asserted */
#define  LcmS_FLT_MUL_BBP3_3V_LOWCRIT              124    /* Baseboard +3.3V Lower critical going high asserted */
#define  LcmS_FLT_MUL_BBP3_3VSBY_UPNCRIT           125    /* Baseboard +3.3V Standby Upper non-critical going high asserted */
#define  LcmS_FLT_MUL_BBP3_3VSBY_UPCRIT            126    /* Baseboard +3.3V Standby Upper critical going high asserted */
#define  LcmS_FLT_MUL_BBP3_3VSBY_LOWNCRIT          127    /* Baseboard +3.3V Standby Lower non-critical going high asserted */
#define  LcmS_FLT_MUL_BBP3_3VSBY_LOWCRIT           128    /* Baseboard +3.3V Standby Lower critical going high asserted */
#define  LcmS_FLT_MUL_BBP5V_UPNCRIT                129    /* Baseboard +5V Upper non-critical going high asserted */
#define  LcmS_FLT_MUL_BBP5V_UPCRIT                 130    /* Baseboard +5V Upper critical going high asserted */
#define  LcmS_FLT_MUL_BBP5V_LOWNCRIT               131    /* Baseboard +5V Lower non-critical going high asserted */
#define  LcmS_FLT_MUL_BBP5V_LOWCRIT                132    /* Baseboard +5V Lower critical going high asserted */
#define  LcmS_FLT_MUL_BBP12V_UPNCRIT               133    /* Baseboard +12V Upper non-critical going high asserted */
#define  LcmS_FLT_MUL_BBP12V_UPCRIT                134    /* Baseboard +12V Upper critical going high asserted */
#define  LcmS_FLT_MUL_BBP12V_LOWNCRIT              135    /* Baseboard +12V Lower non-critical going high asserted */
#define  LcmS_FLT_MUL_BBP12V_LOWCRIT               136    /* Baseboard +12V Lower critical going high asserted */
#define  LcmS_FLT_MUL_BBM12V_UPNCRIT               137    /* Baseboard -12V Upper non-critical going high asserted */
#define  LcmS_FLT_MUL_BBM12V_UPCRIT                138    /* Baseboard -12V Upper critical going high asserted */
#define  LcmS_FLT_MUL_BBM12V_LOWNCRIT              139    /* Baseboard -12V Lower non-critical going high asserted */
#define  LcmS_FLT_MUL_BBM12V_LOWCRIT               140    /* Baseboard -12V Lower critical going high asserted */
#define  LcmS_FLT_MUL_BBVBAT_UPNCRIT               141    /* Baseboard VBAT Upper non-critical going high asserted */
#define  LcmS_FLT_MUL_BBVBAT_UPCRIT                142    /* Baseboard VBAT Upper critical going high asserted */
#define  LcmS_FLT_MUL_BBVBAT_LOWNCRIT              143    /* Baseboard VBAT Lower non-critical going high asserted */
#define  LcmS_FLT_MUL_BBVBAT_LOWCRIT               144    /* Baseboard VBAT Lower critical going high asserted */
#define  LcmS_FLT_MUL_BBTEMP_UPNCRIT               145    /* Baseboard Temp Upper non-critical going high asserted */
#define  LcmS_FLT_MUL_BBTEMP_UPCRIT                146    /* Baseboard Temp Upper critical going high asserted */
#define  LcmS_FLT_MUL_BBTEMP_LOWNCRIT              147    /* Baseboard Temp Lower non-critical going high asserted */
#define  LcmS_FLT_MUL_BBTEMP_LOWCRIT               148    /* Baseboard Temp Lower critical going high asserted */
#define  LcmS_FLT_MUL_TECHFAN1_LOWNCRIT            149    /* Tech Fan 1 Lower non-critical going high asserted */
#define  LcmS_FLT_MUL_TECHFAN1_LOWCRIT             150    /* Tech Fan 1 Lower critical going high asserted */
#define  LcmS_FLT_MUL_TECHFAN2_LOWNCRIT            151    /* Tech Fan 2 Lower non-critical going high asserted */
#define  LcmS_FLT_MUL_TECHFAN2_LOWCRIT             152    /* Tech Fan 2 Lower critical going high asserted */
#define  LcmS_FLT_MUL_TECHFAN3_LOWNCRIT            153    /* Tech Fan 3 Lower non-critical going high asserted */
#define  LcmS_FLT_MUL_TECHFAN3_LOWCRIT             154    /* Tech Fan 3 Lower critical going high asserted */
#define  LcmS_FLT_MUL_TECHFAN4_LOWNCRIT            155    /* Tech Fan 4 Lower non-critical going high asserted */
#define  LcmS_FLT_MUL_TECHFAN4_LOWCRIT             156    /* Tech Fan 4 Lower critical going high asserted */
#define  LcmS_FLT_MUL_TECHFAN5_LOWNCRIT            157    /* Tech Fan 5 Lower non-critical going high asserted */
#define  LcmS_FLT_MUL_TECHFAN5_LOWCRIT             158    /* Tech Fan 5 Lower critical going high asserted */
#define  LcmS_FLT_MUL_PROC1CORETEMP_UPNCRIT        159    /* Proc 1 Core Temp Upper non-critical going high asserted */
#define  LcmS_FLT_MUL_PROC1CORETEMP_UPCRIT         160    /* Proc 1 Core Temp Upper critical going high asserted */
#define  LcmS_FLT_MUL_PROC1CORETEMP_LOWNCRIT       161    /* Proc 1 Core Temp Lower non-critical going high asserted */
#define  LcmS_FLT_MUL_PROC1CORETEMP_LOWCRIT        162    /* Proc 1 Core Temp Lower critical going high asserted */
#define  LcmS_FLT_MUL_PROC2CORETEMP_UPNCRIT        163    /* Proc 2 Core Temp Upper non-critical going high asserted */
#define  LcmS_FLT_MUL_PROC2CORETEMP_UPCRIT         164    /* Proc 2 Core Temp Upper critical going high asserted */
#define  LcmS_FLT_MUL_PROC2CORETEMP_LOWNCRIT       165    /* Proc 2 Core Temp Lower non-critical going high asserted */
#define  LcmS_FLT_MUL_PROC2CORETEMP_LOWCRIT        166    /* Proc 2 Core Temp Lower critical going high asserted */
#define  LcmS_FLT_MUL_PROCVRM_UPNCRIT              167    /* Proc VRM Upper non-critical going high asserted */
#define  LcmS_FLT_MUL_PROCVRM_UPCRIT               168    /* Proc VRM Upper critical going high asserted */
#define  LcmS_FLT_MUL_PROCVRM_LOWNCRIT             169    /* Proc VRM Lower non-critical going high asserted */
#define  LcmS_FLT_MUL_PROCVRM_LOWCRIT              170    /* Proc VRM Lower critical going high asserted */


#define LcmS_FLT_RUT_CPU0_Temp_UPCRIT              171    /* Rutile CPU0 Temp           */
#define LcmS_FLT_RUT_CPU0_Temp_LOWCRIT             172    /* Rutile CPU0 Temp           */

#define LcmS_FLT_RUT_ADD1_5VSB_UPCRIT              173    /* Rutile +1.5VSB             */
#define LcmS_FLT_RUT_ADD1_5VSB_LOWCRIT             174    /* Rutile +1.5VSB             */

#define LcmS_FLT_RUT_FCADD1_8V_UPCRIT              175    /* Rutile FC+1.8V             */
#define LcmS_FLT_RUT_FCADD1_8V_LOWCRIT             176    /* Rutile FC+1.8V             */

#define LcmS_FLT_RUT_SASADD1_2V_UPCRIT             177    /* Rutile SAS+1.2V            */
#define LcmS_FLT_RUT_SASADD1_2V_LOWCRIT            178    /* Rutile SAS+1.2V            */

#define LcmS_FLT_RUT_VCCP_0_UPCRIT                 179    /* Rutile VCCP 0              */
#define LcmS_FLT_RUT_VCCP_0_LOWCRIT                180    /* Rutile VCCP 0              */

#define LcmS_FLT_RUT_VCCP_1_UPCRIT                 181    /* Rutile VCCP 1              */
#define LcmS_FLT_RUT_VCCP_1_LOWCRIT                182    /* Rutile VCCP 1              */

#define LcmS_FLT_RUT_ProcVR_OvrVoltg_UPCRIT        183    /* Rutile ProcVR OverVoltg    */
#define LcmS_FLT_RUT_ProcVR_OvrVoltg_LOWCRIT       184    /* Rutile ProcVR OverVoltg    */

#define LcmS_FLT_RUT_OUT_ADD5v_UPCRIT              185    /* Rutile OUT +5v             */
#define LcmS_FLT_RUT_OUT_ADD5v_LOWCRIT             186    /* Rutile OUT +5v             */

#define LcmS_FLT_RUT_OUT_ADD12v_UPCRIT             187    /* Rutile OUT +12v            */
#define LcmS_FLT_RUT_OUT_ADD12v_LOWCRIT            188    /* Rutile OUT +12v            */

#define LcmS_FLT_RUT_Pwr_Unt_Out_48v_UPCRIT        189    /* Rutile Power Unit Out -48v */
#define LcmS_FLT_RUT_Pwr_Unt_Out_48v_LOWCRIT       190    /* Rutile Power Unit Out -48v */

#define LcmS_FLT_CPU0STS_PRO                       191    /* CPU 0 Status Processor     */
#define LcmS_FLT_CPU0STS_THE                       192    /* CPU 0 Status Thermal       */
#define LcmS_FLT_CPU0STS_FRB                       193    /* CPU 0 Status FRB3          */
#define LcmS_FLT_CPU0STS_CON                       194    /* CPU 0 Status Configuration */

#define LcmS_FLT_CPU1STS_PRO                       195    /* CPU 1 Status Processor     */
#define LcmS_FLT_CPU1STS_THE                       196    /* CPU 1 Status Thermal       */
#define LcmS_FLT_CPU1STS_FRB                       197    /* CPU 1 Status FRB3          */
#define LcmS_FLT_CPU1STS_CON                       198    /* CPU 1 Status Configuration */

#define LcmS_FLT_SYS_FW_FIRM0                      199    /* Timer count read/writeerror */
#define LcmS_FLT_SYS_FW_FIRM1                      200    /* CMOS battery error         */
#define LcmS_FLT_SYS_FW_FIRM2                      201    /* CMOS diagnosis error       */
#define LcmS_FLT_SYS_FW_FIRM3                      202    /* CMOS checksum error        */
#define LcmS_FLT_SYS_FW_FIRM4                      203    /* CMOS memory size error     */
#define LcmS_FLT_SYS_FW_FIRM5                      204    /* RAM read/write test error  */
#define LcmS_FLT_SYS_FW_FIRM6                      205    /* CMOS date/time error       */
#define LcmS_FLT_SYS_FW_FIRM7                      206    /* Microcontroller in update  */
#define LcmS_FLT_SYS_FW_FIRM8                      207    /* Microcontroller response failure */
#define LcmS_FLT_SYS_FW_SENS0                      208    /* Sensor Event description unknown */

#define LcmS_FLT_CRI_PCI_PERR                      209    /* Critical Int PCI PERR detected */
#define LcmS_FLT_CRI_PCI_SERR                      210    /* Critical Int PCI SERR detected */
#define LcmS_FLT_CRI_BUS_CORR                      211    /* Critical Int Bus correctable error */

#define LcmS_FLT_BIS_MAIN_SEC                      212    /* BIOS Main Flash Invalid boot sector */
#define LcmS_FLT_BIS_FRED_SEC                      213    /* BIOS FRED Flash Invalid boot sector */
#define LcmS_FLT_MUL_SCSI_1_8V_UPCRIT              214    /* SCSI+1.8V */
#define LcmS_FLT_MUL_SCSI_1_8V_LOWCRIT             215    /* SCSI+1.8V */
#define LcmS_FLT_MUL_SCSI_A_2_5V_UPCRIT            216    /* SCSI-A+2.5V */
#define LcmS_FLT_MUL_SCSI_A_2_5V_LOWCRIT           217    /* SCSI-A+2.5V */
#define LcmS_FLT_MUL_SCSI_B_2_5V_UPCRIT            218    /* SCSI-B+2.5V */
#define LcmS_FLT_MUL_SCSI_B_2_5V_LOWCRIT           219    /* SCSI-B+2.5V */
#define LcmS_FLT_CPU0STS_PROC                      220    /* CPU 0 Status Processor     */
#define LcmS_FLT_CPU0STS_FRB1                      221    /* CPU 0 Status FRB1/BIST failure          */
#define LcmS_FLT_CPU0STS_FRB2                      222    /* CPU 0 Status FRB2/Hang in POST failure  */
#define LcmS_FLT_CPU1STS_PROC                      223    /* CPU 1 Status Processor     */
#define LcmS_FLT_CPU1STS_FRB1                      224    /* CPU 1 Status FRB1/BIST failure          */
#define LcmS_FLT_CPU1STS_FRB2                      225    /* CPU 1 Status FRB2/Hang in POST failure  */
#define LcmS_FLT_BBTMP1_HIASRT                     226    /* Baseboard Temp1 Upper critical going high asserted */
#define LcmS_FLT_BBTMP2_HIASRT                     227    /* Baseboard Temp2 Upper critical going high asserted */
#define LcmS_FLT_BBTMP3_HIASRT                     228    /* Baseboard Temp3 Upper critical going high asserted */
#define LcmS_FLT_BBTMP4_HIASRT                     229    /* Baseboard Temp4 Upper critical going high asserted */
#define LcmS_FLT_ProcVR1_LOWNONCRIT                230    /* CPUVR1 Over Volt Lower non-critical going high asserted */
#define LcmS_FLT_ProcVR2_LOWNONCRIT                231    /* CPUVR2 Over Volt Lower non-critical going high asserted */
#define LcmS_FLT_VCCP_2_UPCRIT                     232    /*  VCCP 2 Upper critical     */
#define LcmS_FLT_VCCP_2_LOWCRIT                    233    /*  VCCP 2 Lower critical     */
#define LcmS_FLT_CPU1_THERM_UPCRIT                 234    /*  CPU1 Therm Upper critical */
#define LcmS_FLT_CPU2_THERM_UPCRIT                 235    /*  CPU2 Therm Upper critical */
#define LcmS_FLT_CPU0PROCHOT_HIASRT                236    /* CPU 0 PROCHOT Upper critical */
#define LcmS_FLT_PWRUNT_DWN                        237    /* Power Unit 240VA Power Down */
#define LcmS_FLT_PWRUNT_CTL                        238    /* Power Unit Soft Power Control Failure */
#define LcmS_FLT_MEMORY_ECC                        239    /* Memory Uncorrectable ECC/Other uncorrectable memory error */
#define LcmS_FLT_SYS_FW_FIRM                       240    /* Sys FW Progress System Firmware Error */
#define LcmS_FLT_ProcVR_OvrVoltg_LOWNONCRIT        241    /* ProcVR OverVoltg Lower non-critical */
#define LcmS_FLT_MEMORY_CRT                        242    /* Memory Correctable ECC/Other correctable memory error */
#define LcmS_FLT_BOOT_ERR_NOBOOTMEDIA              243    /* Boot Error no bootable media */
/*
 * LCM���о㳲�װ�(�������ɲä�����LcmS_FLT_CMM_MAX���ѹ���)
 */
#define  LcmS_FLT_NETWORK                          252    /* NIC��ϩ�۾�      */
#define  LcmS_FLT_CPUPFOM                          253    /* CPU����ǽ���㲼  */
#define  LcmS_FLT_MEMSHT                           254    /* ɬ�ץ�����­  */
#define  LcmS_FLT_CPUNUM                           255    /* ɬ��CPU����­   */
#define  LcmS_FLT_SYSRCV_NOEXE                     256    /* sysrecovery̤�»ܸ��� */
#define  LcmS_FLT_UPDATE_BIOS                      257    /* BIOS update fault */
#define  LcmS_FLT_UPDATE_BMC                       258    /* BMC update fault */
#define  LcmS_FLT_UPDATE_MMC                       259    /* MMC update fault */

/*
 * CMM���󥵡��㳲�װ�(255�ʹߤϤ�������ɲ�)
 * �ɲø��LcmS_FLT_CMM_MAX2���ѹ���
 * 242��251��ǰ�Τ��ᡢ�������װ��Ѥξ㳲�ֹ�ˤȤäƤ���
 */
#define LcmS_FLT_TEMP_AIR_NRHIASRT      260     /* Temp AirInlet Upper non-recoverable */
#define LcmS_FLT_TEMP_AIR_HIASRT        261     /* Temp AirInlet Upper critical */
#define LcmS_FLT_TEMP_LANA_NRHIASRT     262     /* Temp LAN A Upper non-recoverable */
#define LcmS_FLT_TEMP_LANA_HIASRT       263     /* Temp LAN A Upper critical */
#define LcmS_FLT_TEMP_LANB_NRHIASRT     264     /* Temp LAN B Upper non-recoverable */
#define LcmS_FLT_TEMP_LANB_HIASRT       265     /* Temp LAN B Upper critical */
#define LcmS_FLT_TEMP_SWITCH_NRHIASRT   266     /* Temp Switch Upper non-recoverable */
#define LcmS_FLT_TEMP_SWITCH_HIASRT     267     /* Temp Switch Upper critical */
#define LcmS_FLT_TEMP_EXHST1_NRHIASRT   268     /* Temp Exhaust1 Upper non-recoverable */
#define LcmS_FLT_TEMP_EXHST1_HIASRT     269     /* Temp Exhaust1 Upper critical */
#define LcmS_FLT_TEMP_EXHST2_NRHIASRT   270     /* Temp Exhaust2 Upper non-recoverable */
#define LcmS_FLT_TEMP_EXHST2_HIASRT     271     /* Temp Exhaust2 Upper critical */
#define LcmS_FLT_BRD_3_3V_HIASRT        272     /* Board 3.3V Upper critical */
#define LcmS_FLT_BRD_3_3V_LOWASRT       273     /* Board 3.3V Lower critical */
#define LcmS_FLT_BRD_3_3VSUS_HIASRT     274     /* Board 3.3VSUS Upper critical */
#define LcmS_FLT_BRD_3_3VSUS_LOWASRT    275     /* Board 3.3VSUS Lower critical */
#define LcmS_FLT_BRD_12_0V_HIASRT       276     /* Board 12.0v Upper critical */
#define LcmS_FLT_BRD_12_0V_LOWASRT      277     /* Board 12.0v Lower critical */
#define LcmS_FLT_BRD_1_8V_HIASRT        278     /* Board 1.8V Upper critical */
#define LcmS_FLT_BRD_1_8V_LOWASRT       279     /* Board 1.8V Lower critical */
#define LcmS_FLT_BRD_VTT1_5V_HIASRT     280     /* Board Vtt1.5V Upper critical */
#define LcmS_FLT_BRD_VTT1_5V_LOWASRT    281     /* Board Vtt1.5V Lower critical */
#define LcmS_FLT_BRD_1_1V_HIASRT        282     /* Board 1.1V Upper critical */
#define LcmS_FLT_BRD_1_1V_LOWASRT       283     /* Board 1.1V Lower critical */
#define LcmS_FLT_BRD_1_0V_HIASRT        284     /* Board 1.0V Upper critical */
#define LcmS_FLT_BRD_1_0V_LOWASRT       285     /* Board 1.0V Lower critical */
#define LcmS_FLT_STRG_ERR_MEMASRT       286     /* Storage Err memory error: Assertion Event */
#define LcmS_FLT_HDDTMP_HIASRT          287     /* HDD Temp Upper critical */
#define LcmS_FLT_AMCTMP_HIASRT          288     /* AMC Temp Upper critical */
#define LcmS_FLT_DIMMTMP_HIASRT         289     /* DIMM Temp Upper critical */
#define LcmS_FLT_RTMTMP_HIASRT          290     /* RTM Temp Upper critical */
#define LcmS_FLT_RTMATMP_HIASRT         291     /* RTM Ambient Temp Upper critical */
#define LcmS_FLT_P1_0V_HIASRT           292     /* +1.0V Upper critical */
#define LcmS_FLT_P1_0V_LOWASRT          293     /* +1.0V Lower critical */
#define LcmS_FLT_P1_05V_HIASRT          294     /* +1.05V Upper critical */
#define LcmS_FLT_P1_05V_LOWASRT         295     /* +1.05V Lower critical */
#define LcmS_FLT_RTMP1_2V_HIASRT        296     /* RTM��+1.2V Upper critical */
#define LcmS_FLT_RTMP1_2V_LOWASRT       297     /* RTM��+1.2V Lower critical */
#define LcmS_FLT_RTMP1_5V_HIASRT        298     /* RTM��+1.5V Upper critical */
#define LcmS_FLT_RTMP1_5V_LOWASRT       299     /* RTM��+1.5V Lower critical */
#define LcmS_FLT_RTMP1_8V_HIASRT        300     /* RTM��+1.8V Upper critical */
#define LcmS_FLT_RTMP1_8V_LOWASRT       301     /* RTM��+1.8V Lower critical */
#define LcmS_FLT_RTMP2_5V_HIASRT        302     /* RTM��+2.5V Upper critical */
#define LcmS_FLT_RTMP2_5V_LOWASRT       303     /* RTM��+2.5V Lower critical */
#define LcmS_FLT_RTMP3_3V_HIASRT        304     /* RTM��+3.3V Upper critical */
#define LcmS_FLT_RTMP3_3V_LOWASRT       305     /* RTM��+3.3V Lower critical */
#define LcmS_FLT_RTMP3_3VSB_HIASRT      306     /* RTM��+3.3VSB Upper critical */
#define LcmS_FLT_RTMP3_3VSB_LOWASRT     307     /* RTM��+3.3VSB Lower critical */
#define LcmS_FLT_RTMP5V_HIASRT          308     /* RTM��+5V Upper critical */
#define LcmS_FLT_RTMP5V_LOWASRT         309     /* RTM��+5V Lower critical */
#define LcmS_FLT_RTMP12V_HIASRT         310     /* RTM��+12V Upper critical */
#define LcmS_FLT_RTMP12V_LOWASRT        311     /* RTM��+12V Lower critical */
#define LcmS_FLT_CPU2STS_PRO            312     /* CPU 2 Status Processor IERR detected: Assertion Event */
#define LcmS_FLT_CPU2STS_THE            313     /* CPU 2 Status Thermal trip detected: Assertion Event */
#define LcmS_FLT_CPU2STS_FRB1           314     /* CPU 2 Status FRB1/BIST failure */
#define LcmS_FLT_CPU2STS_FRB2           315     /* CPU 2 Status FRB2/Hang in POST failure */
#define LcmS_FLT_CPU2STS_FRB            316     /* CPU 2 Status FRB3 */
#define LcmS_FLT_CPU2STS_CON            317     /* CPU 2 Status Configuration Error detected: Assertion Event */
#define LcmS_FLT_INLET1TMP_HIASRT                  318    /* Inlet Temp 1 Upper critical */
#define LcmS_FLT_INLET1TMP_NRHIASRT                319    /* Inlet Temp 1 Upper non-recoverable */
#define LcmS_FLT_INLET2TMP_HIASRT                  320    /* Inlet Temp 2 Upper critical */
#define LcmS_FLT_INLET2TMP_NRHIASRT                321    /* Inlet Temp 2 Upper non-recoverable */
#define LcmS_FLT_CPU0DIMMTMP_HIASRT                322    /* CPU0 DIMM Temp Upper critical */
#define LcmS_FLT_CPU0DIMMTMP_NRHIASRT              323    /* CPU0 DIMM Temp Upper non-recoverable */
#define LcmS_FLT_CPU1DIMMTMP_HIASRT                324    /* CPU1 DIMM Temp Upper critical */
#define LcmS_FLT_CPU1DIMMTMP_NRHIASRT              325    /* CPU1 DIMM Temp Upper non-recoverable */
#define LcmS_FLT_PCHDIETMP_HIASRT                  326    /* PCH Die Temp Upper critical */
#define LcmS_FLT_PCHDIETMP_NRHIASRT                327    /* PCH Die Temp Upper non-recoverable */
#define LcmS_FLT_CPU0COREDTS_HIASRT                328    /* CPU0 Core DTS Upper critical */
#define LcmS_FLT_CPU0COREDTS_NRHIASRT              329    /* CPU0 Core DTS Upper non-recoverable */
#define LcmS_FLT_CPU1COREDTS_HIASRT                330    /* CPU1 Core DTS Upper critical */
#define LcmS_FLT_CPU1COREDTS_NRHIASRT              331    /* CPU1 Core DTS Upper non-recoverable */
#define LcmS_FLT_RTMOUTLETTMP_HIASRT               332    /* RTM Outlet Temp Upper critical */
#define LcmS_FLT_RTMOUTLETTMP_NRHIASRT             333    /* RTM Outlet Temp Upper non-recoverable */
#define LcmS_FLT_RTMINLETHDDTMP_HIASRT             334    /* RTM Inlet/HDD Temp Upper critical */
#define LcmS_FLT_RTMINLETHDDTMP_NRHIASRT           335    /* RTM Inlet/HDD Temp Upper non-recoverable */
#define LcmS_FLT_RTMSAS1064ETMP_HIASRT             336    /* RTM SAS1064E Temp Upper critical */
#define LcmS_FLT_RTMSAS1064ETMP_NRHIASRT           337    /* RTM SAS1064E Temp Upper non-recoverable */
#define LcmS_FLT_RTMPM8032TMP_HIASRT               338    /* RTM PM8032 Temp Upper critical */
#define LcmS_FLT_RTMPM8032TMP_NRHIASRT             339    /* RTM PM8032 Temp Upper non-recoverable */
#define LcmS_FLT_P12V_NRLOWASRT                    340    /* +12V Lower non-recoverable */
#define LcmS_FLT_P12V_NRHIASRT                     341    /* +12V Upper non-recoverable */
#define LcmS_FLT_RTMP12V_NRLOWASRT                 342    /* RTM +12V Lower non-recoverable */
#define LcmS_FLT_RTMP12V_NRHIASRT                  343    /* RTM +12V Upper non-recoverable */
#define LcmS_FLT_P5V_NRLOWASRT                     344    /* +5V Lower non-recoverable */
#define LcmS_FLT_P5V_NRHIASRT                      345    /* +5V Upper non-recoverable */
#define LcmS_FLT_RTMP5V_NRLOWASRT                  346    /* RTM +5V Lower non-recoverable */
#define LcmS_FLT_RTMP5V_NRHIASRT                   347    /* RTM +5V Upper non-recoverable */
#define LcmS_FLT_P5VSBY_LOWASRT                    348    /* +5V Standby Lower critical */
#define LcmS_FLT_P5VSBY_NRLOWASRT                  349    /* +5V Standby Lower non-recoverable */
#define LcmS_FLT_P5VSBY_HIASRT                     350    /* +5V Standby Upper critical */
#define LcmS_FLT_P5VSBY_NRHIASRT                   351    /* +5V Standby Upper non-recoverable */
#define LcmS_FLT_P3_3VIPMI_LOWASRT                 352    /* +3.3V IPMI Lower critical */
#define LcmS_FLT_P3_3VIPMI_NRLOWASRT               353    /* +3.3V IPMI Lower non-recoverable */
#define LcmS_FLT_P3_3VIPMI_HIASRT                  354    /* +3.3V IPMI Upper critical */
#define LcmS_FLT_P3_3VIPMI_NRHIASRT                355    /* +3.3V IPMI Upper non-recoverable */
#define LcmS_FLT_P3_3V_NRLOWASRT                   356    /* +3.3V Lower non-recoverable */
#define LcmS_FLT_P3_3V_NRHIASRT                    357    /* +3.3V Upper non-recoverable */
#define LcmS_FLT_RTMP3_3V_NRLOWASRT                358    /* RTM +3.3V Lower non-recoverable */
#define LcmS_FLT_RTMP3_3V_NRHIASRT                 359    /* RTM +3.3V Upper non-recoverable */
#define LcmS_FLT_P1_8V_NRLOWASRT                   360    /* +1.8V Lower non-recoverable */
#define LcmS_FLT_P1_8V_NRHIASRT                    361    /* +1.8V Upper non-recoverable */
#define LcmS_FLT_RTMP1_8V_NRLOWASRT                362    /* RTM +1.8V Lower non-recoverable */
#define LcmS_FLT_RTMP1_8V_NRHIASRT                 363    /* RTM +1.8V Upper non-recoverable */
#define LcmS_FLT_P1_8VFR_LOWASRT                   364    /* +1.8V FR Lower critical */
#define LcmS_FLT_P1_8VFR_NRLOWASRT                 365    /* +1.8V FR Lower non-recoverable */
#define LcmS_FLT_P1_8VFR_HIASRT                    366    /* +1.8V FR Upper critical */
#define LcmS_FLT_P1_8VFR_NRHIASRT                  367    /* +1.8V FR Upper non-recoverable */
#define LcmS_FLT_P1_5VPCH_LOWASRT                  368    /* +1.5V PCH Lower critical */
#define LcmS_FLT_P1_5VPCH_NRLOWASRT                369    /* +1.5V PCH Lower non-recoverable */
#define LcmS_FLT_P1_5VPCH_HIASRT                   370    /* +1.5V PCH Upper critical */
#define LcmS_FLT_P1_5VPCH_NRHIASRT                 371    /* +1.5V PCH Upper non-recoverable */
#define LcmS_FLT_P1_2V_NRLOWASRT                   372    /* +1.2V Lower non-recoverable */
#define LcmS_FLT_P1_2V_NRHIASRT                    373    /* +1.2V Upper non-recoverable */
#define LcmS_FLT_RTMP1_2V_NRLOWASRT                374    /* RTM +1.2V Lower non-recoverable */
#define LcmS_FLT_RTMP1_2V_NRHIASRT                 375    /* RTM +1.2V Upper non-recoverable */
#define LcmS_FLT_P1_1V_LOWASRT                     376    /* +1.1V Lower critical */
#define LcmS_FLT_P1_1V_NRLOWASRT                   377    /* +1.1V Lower non-recoverable */
#define LcmS_FLT_P1_1V_HIASRT                      378    /* +1.1V Upper critical */
#define LcmS_FLT_P1_1V_NRHIASRT                    379    /* +1.1V Upper non-recoverable */
#define LcmS_FLT_P1V_LOWASRT                       380    /* +1V Lower critical */
#define LcmS_FLT_P1V_NRLOWASRT                     381    /* +1V Lower non-recoverable */
#define LcmS_FLT_P1V_HIASRT                        382    /* +1V Upper critical */
#define LcmS_FLT_P1V_NRHIASRT                      383    /* +1V Upper non-recoverable */
#define LcmS_FLT_PVCCP0_LOWASRT                    384    /* +VCCP0 Lower critical */
#define LcmS_FLT_PVCCP0_NRLOWASRT                  385    /* +VCCP0 Lower non-recoverable */
#define LcmS_FLT_PVCCP0_HIASRT                     386    /* +VCCP0 Upper critical */
#define LcmS_FLT_PVCCP0_NRHIASRT                   387    /* +VCCP0 Upper non-recoverable */
#define LcmS_FLT_PVCCP1_LOWASRT                    388    /* +VCCP1 Lower critical */
#define LcmS_FLT_PVCCP1_NRLOWASRT                  389    /* +VCCP1 Lower non-recoverable */
#define LcmS_FLT_PVCCP1_HIASRT                     390    /* +VCCP1 Upper critical */
#define LcmS_FLT_PVCCP1_NRHIASRT                   391    /* +VCCP1 Upper non-recoverable */
#define LcmS_FLT_PVDDQ0_LOWASRT                    392    /* +VDDQ0 Lower critical */
#define LcmS_FLT_PVDDQ0_NRLOWASRT                  393    /* +VDDQ0 Lower non-recoverable */
#define LcmS_FLT_PVDDQ0_HIASRT                     394    /* +VDDQ0 Upper critical */
#define LcmS_FLT_PVDDQ0_NRHIASRT                   395    /* +VDDQ0 Upper non-recoverable */
#define LcmS_FLT_PVDDQ1_LOWASRT                    396    /* +VDDQ1 Lower critical */
#define LcmS_FLT_PVDDQ1_NRLOWASRT                  397    /* +VDDQ1 Lower non-recoverable */
#define LcmS_FLT_PVDDQ1_HIASRT                     398    /* +VDDQ1 Upper critical */
#define LcmS_FLT_PVDDQ1_NRHIASRT                   399    /* +VDDQ1 Upper non-recoverable */
#define LcmS_FLT_PVTT0_LOWASRT                     400    /* +VTT0 Lower critical */
#define LcmS_FLT_PVTT0_NRLOWASRT                   401    /* +VTT0 Lower non-recoverable */
#define LcmS_FLT_PVTT0_HIASRT                      402    /* +VTT0 Upper critical */
#define LcmS_FLT_PVTT0_NRHIASRT                    403    /* +VTT0 Upper non-recoverable */
#define LcmS_FLT_PVTT1_LOWASRT                     404    /* +VTT1 Lower critical */
#define LcmS_FLT_PVTT1_NRLOWASRT                   405    /* +VTT1 Lower non-recoverable */
#define LcmS_FLT_PVTT1_HIASRT                      406    /* +VTT1 Upper critical */
#define LcmS_FLT_PVTT1_NRHIASRT                    407    /* +VTT1 Upper non-recoverable */
#define LcmS_FLT_PVTTDDR0_LOWASRT                  408    /* +VTT DDR0 Lower critical */
#define LcmS_FLT_PVTTDDR0_NRLOWASRT                409    /* +VTT DDR0 Lower non-recoverable */
#define LcmS_FLT_PVTTDDR0_HIASRT                   410    /* +VTT DDR0 Upper critical */
#define LcmS_FLT_PVTTDDR0_NRHIASRT                 411    /* +VTT DDR0 Upper non-recoverable */
#define LcmS_FLT_PVTTDDR1_LOWASRT                  412    /* +VTT DDR1 Lower critical */
#define LcmS_FLT_PVTTDDR1_NRLOWASRT                413    /* +VTT DDR1 Lower non-recoverable */
#define LcmS_FLT_PVTTDDR1_HIASRT                   414    /* +VTT DDR1 Upper critical */
#define LcmS_FLT_PVTTDDR1_NRHIASRT                 415    /* +VTT DDR1 Upper non-recoverable */
#define LcmS_FLT_P2_5VFE_LOWASRT                   416    /* +2.5V FE Lower critical */
#define LcmS_FLT_P2_5VFE_NRLOWASRT                 417    /* +2.5V FE Lower non-recoverable */
#define LcmS_FLT_P2_5VFE_HIASRT                    418    /* +2.5V FE Upper critical */
#define LcmS_FLT_P2_5VFE_NRHIASRT                  419    /* +2.5V FE Upper non-recoverable */
#define LcmS_FLT_PVDDFE_LOWASRT                    420    /* +VDD FE Lower critical */
#define LcmS_FLT_PVDDFE_NRLOWASRT                  421    /* +VDD FE Lower non-recoverable */
#define LcmS_FLT_PVDDFE_HIASRT                     422    /* +VDD FE Upper critical */
#define LcmS_FLT_PVDDFE_NRHIASRT                   423    /* +VDD FE Upper non-recoverable */
#define LcmS_FLT_RTMPVDDFE_LOWASRT                 424    /* RTM +VDD FE Lower critical */
#define LcmS_FLT_RTMPVDDFE_NRLOWASRT               425    /* RTM +VDD FE Lower non-recoverable */
#define LcmS_FLT_RTMPVDDFE_HIASRT                  426    /* RTM +VDD FE Upper critical */
#define LcmS_FLT_RTMPVDDFE_NRHIASRT                427    /* RTM +VDD FE Upper non-recoverable */
#define LcmS_FLT_PVCCPLL0_LOWASRT                  428    /* +VCCPLL0 Lower critical */
#define LcmS_FLT_PVCCPLL0_NRLOWASRT                429    /* +VCCPLL0 Lower non-recoverable */
#define LcmS_FLT_PVCCPLL0_HIASRT                   430    /* +VCCPLL0 Upper critical */
#define LcmS_FLT_PVCCPLL0_NRHIASRT                 431    /* +VCCPLL0 Upper non-recoverable */
#define LcmS_FLT_PVCCPLL1_LOWASRT                  432    /* +VCCPLL1 Lower critical */
#define LcmS_FLT_PVCCPLL1_NRLOWASRT                433    /* +VCCPLL1 Lower non-recoverable */
#define LcmS_FLT_PVCCPLL1_HIASRT                   434    /* +VCCPLL1 Upper critical */
#define LcmS_FLT_PVCCPLL1_NRHIASRT                 435    /* +VCCPLL1 Upper non-recoverable */
#define LcmS_FLT_PVSA0_LOWASRT                     436    /* +VSA0 Lower critical */
#define LcmS_FLT_PVSA0_NRLOWASRT                   437    /* +VSA0 Lower non-recoverable */
#define LcmS_FLT_PVSA0_HIASRT                      438    /* +VSA0 Upper critical */
#define LcmS_FLT_PVSA0_NRHIASRT                    439    /* +VSA0 Upper non-recoverable */
#define LcmS_FLT_PVSA1_LOWASRT                     440    /* +VSA1 Lower critical */
#define LcmS_FLT_PVSA1_NRLOWASRT                   441    /* +VSA1 Lower non-recoverable */
#define LcmS_FLT_PVSA1_HIASRT                      442    /* +VSA1 Upper critical */
#define LcmS_FLT_PVSA1_NRHIASRT                    443    /* +VSA1 Upper non-recoverable */
#define LcmS_FLT_P1_2VSBY_LOWASRT                  444    /* +1.2V Standby Lower critical */
#define LcmS_FLT_P1_2VSBY_NRLOWASRT                445    /* +1.2V Standby Lower non-recoverable */
#define LcmS_FLT_P1_2VSBY_HIASRT                   446    /* +1.2V Standby Upper critical */
#define LcmS_FLT_P1_2VSBY_NRHIASRT                 447    /* +1.2V Standby Upper non-recoverable */
#define LcmS_FLT_PLVDDQ0_LOWASRT                   448    /* +LVDDQ0 Lower critical */
#define LcmS_FLT_PLVDDQ0_NRLOWASRT                 449    /* +LVDDQ0 Lower non-recoverable */
#define LcmS_FLT_PLVDDQ0_HIASRT                    450    /* +LVDDQ0 Upper critical */
#define LcmS_FLT_PLVDDQ0_NRHIASRT                  451    /* +LVDDQ0 Upper non-recoverable */
#define LcmS_FLT_PLVDDQ1_LOWASRT                   452    /* +LVDDQ1 Lower critical */
#define LcmS_FLT_PLVDDQ1_NRLOWASRT                 453    /* +LVDDQ1 Lower non-recoverable */
#define LcmS_FLT_PLVDDQ1_HIASRT                    454    /* +LVDDQ1 Upper critical */
#define LcmS_FLT_PLVDDQ1_NRHIASRT                  455    /* +LVDDQ1 Upper non-recoverable */
#define LcmS_FLT_PLVTTDDR0_LOWASRT                 456    /* +LVTT DDR0 Lower critical */
#define LcmS_FLT_PLVTTDDR0_NRLOWASRT               457    /* +LVTT DDR0 Lower non-recoverable */
#define LcmS_FLT_PLVTTDDR0_HIASRT                  458    /* +LVTT DDR0 Upper critical */
#define LcmS_FLT_PLVTTDDR0_NRHIASRT                459    /* +LVTT DDR0 Upper non-recoverable */
#define LcmS_FLT_PLVTTDDR1_LOWASRT                 460    /* +LVTT DDR1 Lower critical */
#define LcmS_FLT_PLVTTDDR1_NRLOWASRT               461    /* +LVTT DDR1 Lower non-recoverable */
#define LcmS_FLT_PLVTTDDR1_HIASRT                  462    /* +LVTT DDR1 Upper critical */
#define LcmS_FLT_PLVTTDDR1_NRHIASRT                463    /* +LVTT DDR1 Upper non-recoverable */
#define LcmS_FLT_RTMP1_0V_LOWASRT                  464    /* RTM +3.3V MP Lower critical */
#define LcmS_FLT_RTMP1_0V_NRLOWASRT                465    /* RTM +3.3V MP Lower non-recoverable */
#define LcmS_FLT_RTMP1_0V_HIASRT                   466    /* RTM +3.3V MP Upper critical */
#define LcmS_FLT_RTMP1_0V_NRHIASRT                 467    /* RTM +3.3V MP Upper non-recoverable */
#define LcmS_FLT_RTMP3_3VMP_LOWASRT                468    /* RTM +1.0V Lower critical */
#define LcmS_FLT_RTMP3_3VMP_NRLOWASRT              469    /* RTM +1.0V Lower non-recoverable */
#define LcmS_FLT_RTMP3_3VMP_HIASRT                 470    /* RTM +1.0V Upper critical */
#define LcmS_FLT_RTMP3_3VMP_NRHIASRT               471    /* RTM +1.0V Upper non-recoverable */
#define LcmS_FLT_RTMP5VMP_LOWASRT                  472    /* RTM +5V MP Lower critical */
#define LcmS_FLT_RTMP5VMP_NRLOWASRT                473    /* RTM +5V MP Lower non-recoverable */
#define LcmS_FLT_RTMP5VMP_HIASRT                   474    /* RTM +5V MP Upper critical */
#define LcmS_FLT_RTMP5VMP_NRHIASRT                 475    /* RTM +5V MP Upper non-recoverable */
#define LcmS_FLT_RTMFRU_HSW_SM7                    476    /* RTM State M7 - Communication Lost */
#define LcmS_FLT_RTMFRU_HSW_SM0                    477    /* RTM State M0 - Not Installed */
#define LcmS_FLT_PHYSIPMBL_DEVDISABLED             478    /* ATCA Phys IPMB-L Device Disabled */
#define LcmS_FLT_M48VABSA_PWRFAIL                  479    /* -48V Absent A Power Supply Failure detected */
#define LcmS_FLT_M48VABSB_PWRFAIL                  480    /* -48V Absent B Power Supply Failure detected */
#define LcmS_FLT_M48VFUSEFLT_PWRFAIL               481    /* -48V Fuse Fault Power Supply Failure detected */
#define LcmS_FLT_SYSPWRFAIL_PWRFAIL                482    /* System PwrFail Power Supply Failure detected */
#define LcmS_FLT_P1_2VRTMPWR_PWRFAIL               483    /* RTM +12V RTM PwrFail Power Supply Failure detected */
#define LcmS_FLT_P3_3VRTM_PWRFAIL                  484    /* RTM +3.3V RTM Fail Power Supply Failure detected */
#define LcmS_FLT_RTMPWRFLT_PWRFAIL                 485    /* RTM PwrFault Power Supply Failure detected */
#define LcmS_FLT_CPU0THERM_PWRFAIL                 486    /* CPU0 ThermTrip failure */
#define LcmS_FLT_CPU1THERM_PWRFAIL                 487    /* CPU1 ThermTrip failure */
#define LcmS_FLT_CPUMCERR_PWRFAIL                  488    /* CPU MCERR failure */
#define LcmS_FLT_CPU0PROCHOT_PWRFAIL               489    /* CPU0 ProcHot failure */
#define LcmS_FLT_CPU1PROCHOT_PWRFAIL               490    /* CPU1 ProcHot failure */
#define LcmS_FLT_CPUIERR_PWRFAIL                   491    /* CPU IERR failure */
#define LcmS_FLT_MEMDEVDISABLED                    492    /* Memory device disabled */
#define LcmS_FLT_PROCESSOR_HANGFAIL                493    /* Processor FRB2/Hang in POST failure */
#define LcmS_FLT_SYSFW_SYSFWHANG                   494    /* Sys FW Progress System Firmware Hang */
#define LcmS_FLT_OEM_ACTBOOTFLASH                  495    /* OEM ActBootFlash OEM Event */

#if defined(CGHV) || defined(RHEL)
#define LcmS_FLT_CELL_PART_SOFT_FLT        1024 /* Cell/Partition Software Fault */
#define LcmS_FLT_CELL_PART_FLT             1025 /* Cell/Partition Fault */
#define LcmS_FLT_CPU_SELF_TEST_ERR         1026 /* CPU Self Test Error */
#define LcmS_FLT_CPU_INIT_ERR              1027 /* CPU Init Error */
#define LcmS_FLT_CPU_INSIDE_ERR            1028 /* CPU Inside Error */
#define LcmS_FLT_CPU_THERMAL_RUNAWAY       1029 /* CPU Thermal Runaway */
#define LcmS_FLT_ECC_MULT_BIT_ERR          1030 /* ECC Multi Bit Error */
#define LcmS_FLT_EISA_IO_CHANNEL_ERR       1031 /* EISA I/O Channel Check Error */
#define LcmS_FLT_EISA_BUS_TIMEOUT          1032 /* EISA Bus Time Out */
#define LcmS_FLT_HDD_TEMP_FLT              1033 /* HDD Temperature Fault */
#define LcmS_FLT_ICMB_LINE_FLT             1034 /* ICMB Line Fault */
#define LcmS_FLT_MCA_FLT                   1035 /* MCA  Fault */
#define LcmS_FLT_NMI_FLT                   1036 /* NMI  Fault */
#define LcmS_FLT_PAGEFLT_ERR               1037 /* Pagefault Error */
#define LcmS_FLT_PCI_CARD_FLT              1038 /* PCI Card Fault */
#define LcmS_FLT_PCI_SYSTEM_ERR            1039 /* PCI System Error */
#define LcmS_FLT_PCI_PARITY_ERR            1040 /* PCI Parity Error */
#define LcmS_FLT_POSTSTALL_FLT             1041 /* POST STALL Fault */
#define LcmS_FLT_CELL_ERR                  1042 /* Cell Error */
#define LcmS_FLT_CASH_ECC_MULT_BIT_ERR     1043 /* Cash ECC Multi Bit Error */
#define LcmS_FLT_CABLE_FLT                 1044 /* Cable Fault */
#define LcmS_FLT_CPU_HIGH_LOAD             1045 /* CPU High Load */
#define LcmS_FLT_SYSTEM_ERR                1046 /* System Error */
#define LcmS_FLT_SYSTEM_DRIVE_OFFLINE      1047 /* System Drive OFFLINE */
#define LcmS_FLT_SYSTEM_BUS_ERR            1048 /* System Bus Error */
#define LcmS_FLT_SYSTEM_TEMP_UPPER_FLT     1049 /* System Temperature Upper Fault */
#define LcmS_FLT_SYSTEM_TEMP_LOWER_FLT     1050 /* System Temperature Lower Fault */
#define LcmS_FLT_SENSOR_FAULT              1051 /* Sensor Fault */
#define LcmS_FLT_CHIPSET_ERR               1052 /* Chipset Error */
#define LcmS_FLT_CHIPSET_THERMAL_RUNAWAY   1053 /* Chipset Thermal Runaway */
#define LcmS_FLT_DRIVE_FLT                 1054 /* Drive Fault */
#define LcmS_FLT_HARDWARE_ERR              1055 /* Hardware Error */
#define LcmS_FLT_HDD_HARDWARE_ERR          1056 /* HDD Hardware Error */
#define LcmS_FLT_HDD_MEDIUM_ERR            1057 /* HDD Medium Error */
#define LcmS_FLT_HDD_NOTREADY_ERR          1058 /* HDD Not Ready Error */
#define LcmS_FLT_HDD_RECOVERED_ERR         1059 /* HDD Recovered Error */
#define LcmS_FLT_BUSECC_2BIT_ERR           1060 /* Bus ECC 2Bit Error */
#define LcmS_FLT_BUS_ERR                   1061 /* Bus Error */
#define LcmS_FLT_BATTERY_FLT               1062 /* Battery Fault */
#define LcmS_FLT_FAN_FLT                   1063 /* Fan Fault */
#define LcmS_FLT_FAILSAFE_TIME_OUT         1064 /* Failsafe Time Out */
#define LcmS_FLT_PROCESSOR_FLT             1065 /* Processor Fault */
#define LcmS_FLT_PROCESSOR_UNAVAILABLE     1066 /* Processor Unavailable */
#define LcmS_FLT_MANAGEMENT_CONTROLLER_FLT 1067 /* Management Controller Fault */
#define LcmS_FLT_MEM_PARITY_ERR            1068 /* Memory Parity Error */
#define LcmS_FLT_MEM_BOARD_FLT             1069 /* Memory Board Fault */
#define LcmS_FLT_MEM_FLT                   1070 /* Memory Fault */
#define LcmS_FLT_MEM_TEMP_FLT              1071 /* Memory Temperature Fault */
#define LcmS_FLT_MODULE_FLT                1072 /* Module Fault */
#define LcmS_FLT_MODULE_VOLTAGE_FLT        1073 /* Module Voltage Fault */
#define LcmS_FLT_TEMP_SENSOR_FAULT         1074 /* Temperature Sensor Fault */
#define LcmS_FLT_TEMP_FLT                  1075 /* Temperature Fault */
#define LcmS_FLT_WATCH_VAL_LOWER_FLT       1076 /* Watch Value Lower Fault */
#define LcmS_FLT_WATCH_VAL_UPPER_FLT       1077 /* Watch Value Upper Fault */
#define LcmS_FLT_START_ERR                 1078 /* Start Error */
#define LcmS_FLT_WATERCOOLUNIT_FLT         1079 /* Water Cool Unit Fault */
#define LcmS_FLT_VOLTAGE_SENSOR_FLT        1080 /* Voltage Sensor Fault */
#define LcmS_FLT_VOLTAGE_FLT               1081 /* Voltage Fault */
#define LcmS_FLT_POWERUNIT_FLT             1082 /* Power Unit Fault */
#define LcmS_FLT_POWERSUPPLY_FLT           1083 /* Power Supply Fault */
#define LcmS_FLT_POWERSUPPLY_DEGENERATION  1084 /* Power Supply Degeneration */
#define LcmS_FLT_POWER_OFF                 1085 /* Power Off */
#define LcmS_FLT_ELECTRIC_CURRENT_FLT      1086 /* Electric Current Fault */
#define LcmS_FLT_ESMFLT                    1087 /* ESM Fault */
#define LcmS_FLT_PHYSICALDEVICE_DEAD       1088 /* Physical Device Dead */
#define LcmS_FLT_CASE_FLT                  1089 /* Case Fault */
#define LcmS_FLT_OTHER_FLT                 1090 /* Detected ESMPRO Other Fault */
#define LcmS_FLT_SMI_TIMEOUT               1091 /* SMI Timeout */
#define LcmS_FLT_MNGENGINE_STATUS_CHG      1092 /* Management Engine Status Change */
#define LcmS_FLT_RAID_SYSTEM_ERROR         1093 /* RAID System Error */
#define LcmS_FLT_RAID_CONTROLLER_ERROR     1094 /* RAID Controller Error */
#define LcmS_FLT_LOGICAL_DEVICE_ERROR      1095 /* Logical Drive Error */
#define LcmS_FLT_OTHER_FAULT               1100 /* Other Fault */
#endif

#define LcmS_FLT_RBD_DISK                  1200 /* rbd disk fault             */
#define LcmS_FLT_RBD_DRIVER                1201 /* rbd driver fault           */

/*----------------------------------------------------------------------------*/
/* �����߽�������                                                             */
/*----------------------------------------------------------------------------*/
#define  LcmS_SV_CREREG            0             /* ������Ͽ����              */
#define  LcmS_SV_DELREG            1             /* ������Ͽ����              */

/*----------------------------------------------------------------------------*/
/* HDD̵�����ǥ���������                                                      */
/* �ʹ�������ɲä�����������¤��θ�����ͤȤ��뤳��(0x1,0x2,0x4,0x8,��)     */
/*----------------------------------------------------------------------------*/

#define  LcmS_DK_LOCAL           0x1             /* ��������ǥ�����          */ 

/*----------------------------------------------------------------------------*/
/* sysrecovery̤�»ܸ��н�������                                              */
/*----------------------------------------------------------------------------*/
#define LcmS_SYSRCVFILE_CRE    1   /* sysrecovery̤�»ܸ��Хե����� ����      */
#define LcmS_SYSRCVFILE_DEL    2   /* sysrecovery̤�»ܸ��Хե����� ���      */
#define LcmS_SYSRCVFILE_STAT   3   /* sysrecovery̤�»ܸ��Хե����� ���ֳ�ǧ  */

/*----------------------------------------------------------------------------*/
/* �إ륹�����å���IP���ɥ쥹��Ǽ��¤��                                       */
/*----------------------------------------------------------------------------*/
struct LcmT_hcaddr
{
    int            cnt;                  /* ����ǡ�����                      */
    struct in_addr addr[LcmS_HCADDRMAX]; /* IP address                        */
};

/*----------------------------------------------------------------------------*/
/* �إ륹�����å���IP���ɥ쥹��Ǽ��¤��(IPv4/IPv6����)                        */
/*----------------------------------------------------------------------------*/
struct LcmT_hcaddr6
{
    int             proj_IPv6;                /* ����(PDT 65)���� 0:IPv4/1:IPv6 */
    int             cnt;                      /* IPv4���ɥ쥹�����             */
    struct in_addr  addr[LcmS_HCADDRMAX];     /* IPv4 address                   */
    int             cnt6;                     /* IPv6���ɥ쥹�����             */
    struct in6_addr addr6[LcmS_HCADDRMAX];    /* IPv6 address                   */
    int             scope[LcmS_HCADDRMAX];    /* ��������                       */
    unsigned int    ifindex[LcmS_HCADDRMAX];  /* ���󥿥ե�����ID               */
};

/*----------------------------------------------------------------------------*/
/* LCM�����ƥ๽��SG�ơ��֥�(������API(Lcm_sysconfrd)��)                    */
/* Lcmlib_u.h��struct LcmT_systeminfo�ˤ�LCM�����ѤȤ��Ƥۤ�Ʊ�ͤ����������ޤ� */
/* ���������ǡ����򲼵���¤�Τ˥��ԡ����ޤ�                                   */
/*----------------------------------------------------------------------------*/
struct LcmT_systemconf {
    unsigned char chassis;         /* ���㡼���ֹ�                            */
    unsigned char hw_adr ;         /* Hardware Address                        */
    unsigned char bld_no ;         /* aTCA�֥졼���ֹ�                        */
    unsigned char ps_no ;          /* ʪ���������ֹ�                          */
    char          sv_nm[LcmS_SVNAME_MAX+1];    /* ����������̾��(ʸ����)      */
    unsigned char sve_no ;         /* �����г���ɽ���ֹ� [0-99]               */
    unsigned char ls_id ;          /* ���������м���                          */
    unsigned char ls_no ;          /* �����������ֹ�                          */
    unsigned char sys ;            /* ���ֹ�                                  */
    struct LcmT_hcaddr ip_adr ;    /* �ɣХ��ɥ쥹                            */
} ;

/*----------------------------------------------------------------------------*/
/* LCM�����ƥ๽��SG�ơ��֥�(������API(Lcm_sysconfrd6)��)                   */
/* Lcmlib_u.h��struct LcmT_systeminfo�ˤ�LCM�����ѤȤ��Ƥۤ�Ʊ�ͤ����������ޤ� */
/* ���������ǡ����򲼵���¤�Τ˥��ԡ����ޤ�                                   */
/*----------------------------------------------------------------------------*/
struct LcmT_systemconf6 {
    unsigned char chassis;         /* ���㡼���ֹ�                            */
    unsigned char hw_adr ;         /* Hardware Address                        */
    unsigned char bld_no ;         /* aTCA�֥졼���ֹ�                        */
    unsigned char ps_no ;          /* ʪ���������ֹ�                          */
    char          sv_nm[LcmS_SVNAME_MAX+1];    /* ����������̾��(ʸ����)      */
    unsigned char sve_no ;         /* �����г���ɽ���ֹ� [0-99]               */
    unsigned char ls_id ;          /* ���������м���                          */
    unsigned char ls_no ;          /* �����������ֹ�                          */
    unsigned char sys ;            /* ���ֹ�                                  */
    struct LcmT_hcaddr6 ip_adr6 ;  /* �ɣХ��ɥ쥹                            */
} ;

/*----------------------------------------------------------------------------*/
/* LAN����API(Lcm_sysconfmltrd_file)                                          */
/* �����ƥ���߻���/SYSTEM/LM/opf/absolute/lib/system_conf_mlt.txt�ե�����    */
/* ���ɽФ�������¤�Τ��ͤ����ꤹ�롣                                         */
/*----------------------------------------------------------------------------*/
struct LcmT_sysconfmlt {           /* system_conf_mlt.txt�ɽФ���             */
    unsigned char chassis;         /* ���㡼���ֹ�(P1)                        */
    unsigned char hw_adr ;         /* Hardware Address(P2)                    */
    unsigned char bld_no ;         /* aTCA�֥졼���ֹ�(P3)                    */
    unsigned char ps_no ;          /* ʪ���������ֹ�(P4)                      */
    char sv_nm[LcmS_SVNAME_MAX+1]; /* ����������̾��(P5)                      */
    unsigned char sve_no ;         /* �����г���ɽ���ֹ�(P6)                  */
    unsigned char ls_no ;          /* �����������ֹ�(P8)                      */
    unsigned char sys ;            /* ���ֹ�(P9)                              */
    unsigned char dmy ;
    char ls_nm[LcmS_SVNAME_MAX+1]; /* ���������м���(P7)                      */
    struct LcmT_hcaddr ip_adr ;    /* �ɣХ��ɥ쥹(P10��P13)                  */
} ;

/*----------------------------------------------------------------------------*/
/* LAN����API(Lcm_sysconfmltrd_file6)                                         */
/* �����ƥ���߻���/SYSTEM/LM/opf/absolute/lib/system_conf_mlt.txt�ե�����    */
/* ���ɽФ�������¤�Τ��ͤ����ꤹ�롣                                         */
/*----------------------------------------------------------------------------*/
struct LcmT_sysconfmlt6 {          /* system_conf_mlt.txt�ɽФ���             */
    unsigned char chassis;         /* ���㡼���ֹ�(P1)                        */
    unsigned char hw_adr ;         /* Hardware Address(P2)                    */
    unsigned char bld_no ;         /* aTCA�֥졼���ֹ�(P3)                    */
    unsigned char ps_no ;          /* ʪ���������ֹ�(P4)                      */
    char sv_nm[LcmS_SVNAME_MAX+1]; /* ����������̾��(P5)                      */
    unsigned char sve_no ;         /* �����г���ɽ���ֹ�(P6)                  */
    unsigned char ls_no ;          /* �����������ֹ�(P8)                      */
    unsigned char sys ;            /* ���ֹ�(P9)                              */
    unsigned char dmy ;
    char ls_nm[LcmS_SVNAME_MAX+1]; /* ���������м���(P7)                      */
    struct LcmT_hcaddr6 ip_adr6 ;  /* IPv6���ɥ쥹(P10��P13)                  */
} ;

/*----------------------------------------------------------------------------*/
/* �������ܾܺ�����  lcm->USER(LPC����)                                       */
/*----------------------------------------------------------------------------*/
struct LcmT_dstatus_info {
    int                     event;     /* �桼�����ꥤ�٥���ֹ桡*/
    int                     seqno;     /* ���������ֹ�          */
    unsigned char           ps_no;     /* ʪ���������ֹ�          */
    unsigned char           sys;       /* ��                      */
    unsigned char           status;    /* �����о���              */
    unsigned short          sys_ph;    /* �Ƴ��ե�����            */
    int                     nis_cause; /* nis�װ�                 */
    int                     fltno;     /* �㳲�ֹ�                */
};

/*----------------------------------------------------------------------------*/
/* ���������ι�¤��LCM->USER(LPC����)                                         */
/*----------------------------------------------------------------------------*/
struct LcmT_misinsert_info {
    int                     event    ;     /* �桼�����ꥤ�٥���ֹ桡*/
    unsigned char           ps_no    ;     /* ʪ���������ֹ�          */
    unsigned char           sys      ;     /* ��                      */
    unsigned char           chassis  ;     /* ��������������ֹ�      */
    unsigned char           bld_no   ;     /* �������֥졼�ɾ��      */
};

/*----------------------------------------------------------------------------*/
/* �إ륹�����å���ϩ�㳲����  lcm->USER(LPC����)                             */
/*----------------------------------------------------------------------------*/
struct LcmT_hcstatus_info {
    int                     event;     /* �桼�����ꥤ�٥���ֹ�              */
    int                     seqno;     /* ���������ֹ�                      */
    unsigned char           ifno;      /* �㳲������ݡ����ֹ�                */
    unsigned char           status;    /* �إ륹�����å���ϩ����              */
};
/*----------------------------------------------------------------------------*/
/* �إ륹�����å���ϩ���ּ���  lcm->USER                                      */
/*----------------------------------------------------------------------------*/
struct LcmT_hcport {
    unsigned char           ifno;      /* �㳲������ݡ����ֹ�                */
    unsigned char           status;    /* �إ륹�����å���ϩ����  OK or NG    */
};

struct LcmT_hcinfo {
    int                     cnt;       /* ����ǡ�����                        */
    struct LcmT_hcport      hcport[LcmS_HCADDRMAX];
                                       /* �إ륹�����å��ݡ��Ⱥ�����          */
};

struct LcmT_svinfo {
    unsigned short          kind;      /* ���٥�ȼ���                        */
    unsigned char           dmy;       /* ���ߡ�                              */
    unsigned char           psno;      /* ������ʪ���������ֹ�                */
};

/*----------------------------------------------------------------------------*/
/* �ե����०�����С���������  lcm->USER                                    */
/*----------------------------------------------------------------------------*/
struct LcmT_dldinfreq {
    unsigned char           psno;      /* ���ꥵ���Ф�ʪ���������ֹ�          */
    unsigned char           sys;       /* ���ꥵ���Фη��ֹ�                  */
    unsigned char           kind;      /* ��������                            */
};

struct LcmT_dldinfrsp {
    char                    version[LcmS_FW_VER_LEN];
                                       /* �ե����०�����С������ʸ��������  */
};

#ifdef Jpdt_vEPC
/*----------------------------------------------------------------------------*/
/* �ۥ��ȡ�������Ϣ�ȵ�ǽ����¤��                                           */
/*----------------------------------------------------------------------------*/
struct LcmT_sshhost {
    char                    vmname[(LcmS_VMNAME_MAX+1)];
    char                    hostip[(LcmS_HOST_IP6_MAX+1)];
    char                    hostaccount[(LcmS_HOST_ACCOUNT_MAX+1)];
};
#endif /* Jpdt_vEPC */

#ifdef __cplusplus
extern "C" {
#endif

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_attach                                               */
/*      NAME       : LCM(SBC��Ĺ����)�꥽�������å���                         */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : void                                                     */
/*                                                                            */
/******************************************************************************/
extern int Lcm_attach( void );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_detach                                               */
/*      NAME       : LCM(SBC��Ĺ����)�꥽�����ǥ��å�                         */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : void                                                     */
/*                                                                            */
/******************************************************************************/
extern int Lcm_detach( void );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_ThreadAssign                                         */
/*      NAME       : LCM(SBC��Ĺ����)����åɸ����ΰ���ݴؿ�                 */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : void                                                     */
/*                                                                            */
/******************************************************************************/
extern int Lcm_ThreadAssign( void );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_SwChgReq                                             */
/*      NAME       : ���ڤ��ؤ��׵�ؿ�                                       */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : void                                                     */
/*                                                                            */
/******************************************************************************/
extern int Lcm_SwChgReq( void );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_SwChgReq2                                            */
/*      NAME       : ���ڤ��ؤ��׵�ؿ�                                       */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned char) psno   ʪ����������                      */
/*                   (unsigned char) sys    ���ֹ�                            */
/*                                                                            */
/******************************************************************************/
extern int Lcm_SwChgReq2( unsigned char psno, unsigned char sys, unsigned char mode );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_SwStatusChg                                          */
/*      NAME       : ���ڤ��ؤ��׵�ؿ�                                       */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (int) status ���������                                  */
/*                                                                            */
/******************************************************************************/
extern int Lcm_SwStatusChg( int status );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_SwStatusChg2                                         */
/*      NAME       : ���ڤ��ؤ��׵�ؿ�2                                      */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned char) psno   ʪ���������ֹ�                    */
/*                   (unsigned char) sys    ���ֹ�                            */
/*                   (int)           status ���������                        */
/*                                                                            */
/******************************************************************************/
extern int Lcm_SwStatusChg2( unsigned char psno, unsigned char sys, int status );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_LookSwStatus                                         */
/*      NAME       : ���ּ����ؿ�                                             */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (int) *nodeSt  �������и���ž����                        */
/*                   (int) *bnodeSt ������������ž����                        */
/*                   (int) *mateSt  ��Ĺ¾�����и���ž����                    */
/*                                                                            */
/******************************************************************************/
extern int Lcm_LookSwStatus( int *nodeSt, int *bnodeSt, int *mateSt );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_LookSwStatus2                                        */
/*      NAME       : ���ּ����ؿ�2                                            */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned char) psno ʪ���������ֹ�                      */
/*                   (unsigned char) sys  ���ֹ�                              */
/*                   (int) *nodeSt  �������и���ž����                        */
/*                   (int) *bnodeSt ������������ž����                        */
/*                                                                            */
/******************************************************************************/
extern int Lcm_LookSwStatus2( unsigned char psno, unsigned char sys, int *nodeSt, int *bnodeSt );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_GetEventLnid                                         */
/*      NAME       : ���٥�������������Ρ����ֹ����                         */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (int) unsigned long  procid;                             */
/*                                        ���٥��������(LCM)�Υץ��������̻� */
/*                   (int) unsigned int  *lnid;    �����Ρ����ֹ�             */
/*                                                                            */
/******************************************************************************/
extern int Lcm_GetEventLnid( unsigned long procid, unsigned int *lnid );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         FUNCTION   : Lcm_NodePHStatusGet                                   */
/*         NAME       : �����Ρ��ɺƳ��¹Ծ��ֳ�ǧ�ؿ�                        */
/*                                                                            */
/*         RETURN     : LcmS_OK ���ｪλ                                      */
/*                      LcmS_NG �۾ｪλ                                      */
/*                                                                            */
/*         PARAMETERS : (unsigned int) �����Ρ����ֹ�                         */
/*                      (char *)       �����Ρ��ɺƳ��¹Ծ��ֳ�Ǽ���ɥ쥹     */
/*                      (char *)       lcmsw����ξ�����������ֳ�Ǽ���ɥ쥹  */
/*                                                                            */
/******************************************************************************/
extern int Lcm_NodePHStatusGet( unsigned int lnid, char *lnph_stat, char *swchg_flg );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_SwChgProcRes                                         */
/*      NAME       : �������ܱ��������ؿ�                                     */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (int) ch_type �ڤ��ؤ���������                           */
/*                   (int) result  ���ڤ��ؤ��������                         */
/*                                                                            */
/******************************************************************************/
#define Lcm_SwChgProcRes(P1, P2)           Lcma_SwChgProcRes(LcmS_NON_NODE,  0, P1, P2)
#define Lcm_SwChgProcRes_lnode(P1, P2, P3) Lcma_SwChgProcRes(LcmS_ADD_NODE, P1, P2, P3)
extern int Lcma_SwChgProcRes( int kind, unsigned int lnid, int ch_type, int result );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_FailSwProcRes                                        */
/*      NAME       : �㳲�������׵���������ؿ�                               */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (int) event_type ���٥�ȼ���                            */
/*                   (int) result     �㳲�����ؽ������                      */
/*                                                                            */
/******************************************************************************/
#define Lcm_FailSwProcRes(P1, P2)           Lcma_FailSwProcRes(LcmS_NON_NODE,  0, P1, P2)
#define Lcm_FailSwProcRes_lnode(P1, P2, P3) Lcma_FailSwProcRes(LcmS_ADD_NODE, P1, P2, P3)
extern int Lcma_FailSwProcRes( int kind, unsigned int lnid, int event_type, int result );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_lsidmap                                              */
/*      NAME       : ���������м��̤Υӥåȥޥå׼���                         */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned char) psno    ʪ���������ֹ�                   */
/*                   (unsigned int)  *ptlmap ���������м��̤Υӥåȥޥå�     */
/*                                                                            */
/******************************************************************************/
#define Lcm_lsidmap(P1, P2)      Lcma_lsidmap(LcmS_SELF_NODE, P1, P2)
#define Lcm_lsidmap_pair(P1, P2) Lcma_lsidmap(LcmS_PAIR_NODE, P1, P2)
extern int Lcma_lsidmap( int kind, unsigned char psno, unsigned int *ptlmap );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_lsidget                                              */
/*      NAME       : �������������̤��ֹ����                                 */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned char) psno ʪ���������ֹ�                      */
/*                   (unsigned char) lsid ���������м���                      */
/*                   (unsigned char) lsno �������������̤��ֹ�                */
/*                                                                            */
/******************************************************************************/
#define Lcm_lsidget(P1, P2, P3)      Lcma_lsidget(LcmS_SELF_NODE, P1, P2, P3)
#define Lcm_lsidget_pair(P1, P2, P3) Lcma_lsidget(LcmS_PAIR_NODE, P1, P2, P3)
extern int Lcma_lsidget( int kind, unsigned char psno, unsigned char lsid, unsigned char *lsno );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_lsnlts                                               */
/*      NAME       : ʪ���������ֹ���дؿ�                                   */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned char) lsid   ���������м���                    */
/*                   (unsigned char) lsno   �������������̤��ֹ�              */
/*                   (unsigned char) *psnop ʪ���������ֹ�                    */
/*                                                                            */
/******************************************************************************/
#define Lcm_lsnlts(P1, P2, P3)      Lcma_lsnlts(LcmS_SELF_NODE, P1, P2, P3)
#define Lcm_lsnlts_pair(P1, P2, P3) Lcma_lsnlts(LcmS_PAIR_NODE, P1, P2, P3)
extern int Lcma_lsnlts( int kind, unsigned char lsid, unsigned char lsno, unsigned char *psnop );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_lsnomap                                              */
/*      NAME       : �������������̤��ֹ�Υӥåȥޥå���дؿ�               */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned char) lsid     ���������м���                  */
/*                   (unsigned int)  *lsnomap ��������������̤��ֹ�bitmap    */
/*                                                                            */
/******************************************************************************/
#define Lcm_lsnomap(P1, P2)      Lcma_lsnomap(LcmS_SELF_NODE, P1, P2)
#define Lcm_lsnomap_pair(P1, P2) Lcma_lsnomap(LcmS_PAIR_NODE, P1, P2)
extern int Lcma_lsnomap( int kind, unsigned char lsid, unsigned int *lsnomap );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_psidmap                                              */
/*      NAME       : ����ʪ�������ФΥӥåȥޥå���дؿ�                     */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned int) *psidmap ����ʪ�������Ф�bitmap           */
/*                                                                            */
/******************************************************************************/
extern int Lcm_psidmap( unsigned int *psidmap );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾         : Lcm_psidmap_cresv                                 */
/*                          ����ʪ�������ФΥӥåȥޥå���дؿ�              */
/*                                                                            */
/*         �ѥ�᡼��     : P1:OUT(unsigned int *)����ʪ�������ФΥӥåȥޥå�*/
/*                                                                            */
/*         �����         : (int)LcmS_OK : ���ｪλ                           */
/*                          (int)LcmS_NG : �۾ｪλ                           */
/*                                                                            */
/*         ����           : ����ʪ�������ФΥӥåȥޥåפ���Ф�Ԥ�          */
/*                                                                            */
/******************************************************************************/
extern int Lcm_psidmap_cresv( unsigned int *psidmap );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_atopsn                                               */
/*      NAME       : �����г���ɽ��ʸ���󤫤�ʪ���������ֹ����               */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned char) len    ����ʸ����Ĺ                      */
/*                   (char)          *svstr �����г���ɽ����������饯����    */
/*                   (unsigned char) *psno  ʪ���������ֹ�                    */
/*                                                                            */
/******************************************************************************/
extern int Lcm_atopsn( unsigned char len, char *svstr, unsigned char *psno );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_psntoa                                               */
/*      NAME       : ʪ���������ֹ椫�饵���г���ɽ��ʸ��������             */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned char) psno   ʪ���������ֹ�                    */
/*                   (char)          *svstr �����г���ɽ����������饯����    */
/*                   (unsigned char) *len   ����ʸ����Ĺ                      */
/*                                                                            */
/******************************************************************************/
extern int Lcm_psntoa( unsigned char psno, char *svstr, unsigned char *len );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_psnget                                               */
/*      NAME       : �������Ф�ʪ���������ֹ����                             */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned char) *psno ʪ���������ֹ�                     */
/*                                                                            */
/******************************************************************************/
extern int Lcm_psnget( unsigned char *psno );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_psidget                                              */
/*      NAME       : �������Ф�ʪ�������м��̡����ֹ����                     */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned char) *psid ʪ�������м���                     */
/*                   (unsigned char) *sys  ���ֹ�                             */
/*                                                                            */
/******************************************************************************/
extern int Lcm_psidget( unsigned char *psid, unsigned char *sys );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_psntopsid                                            */
/*      NAME       : ʪ�������м��̼���                                       */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned char) psno  ʪ���������ֹ�                     */
/*                   (unsigned char) *psid ʪ�������м���                     */
/*                                                                            */
/******************************************************************************/
extern int Lcm_psntopsid( unsigned char psno, unsigned char *psid );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_gethcaddr                                            */
/*      NAME       : �إ륹�����å���IP���ɥ쥹�����ؿ�                       */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned char)      psno    ʪ���������ֹ�              */
/*                   (unsigned char)      sys     �ϼ���                      */
/*                   (struct LcmT_hcaddr) *hcaddr ʪ�������м���              */
/*                                                                            */
/******************************************************************************/
extern int Lcm_gethcaddr( unsigned char psno, unsigned char sys, struct LcmT_hcaddr *hcaddr );

/********************** FUNCTION DESCRIPTION **********************************/
/*      FUNCTION   : Lcm_gethcaddr6                                           */
/*      NAME       : �إ륹�����å���IP���ɥ쥹�����ؿ�(IPv4/IPv6����)        */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned char)       psno     ʪ���������ֹ�            */
/*                   (unsigned char)       sys      �ϼ���                    */
/*                   (struct LcmT_hcaddr6) *hcaddr6 ʪ�������м���            */
/*                                                                            */
/******************************************************************************/
extern int Lcm_gethcaddr6( unsigned char psno, unsigned char sys, struct LcmT_hcaddr6 *hcaddr6 );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         FUNCTION    : Lcm_sysconfrd                                        */
/*         NAME        : system_conf.txt��������ؿ�                          */
/*                                                                            */
/*         RETURN      : (int) LcmS_OK ���ｪλ                               */
/*                              LcmS_NG �۾ｪλ                              */
/*                                                                            */
/*         PARAMETERS  : (struct LcmT_systemconf) *sysinf �����������о���(O) */
/*                       (unsigned char) *regsv           ���������о����(O) */
/*                                                                            */
/******************************************************************************/
extern int Lcm_sysconfrd( struct LcmT_systemconf *sysinf, unsigned char *regsv);

/********************** FUNCTION DESCRIPTION ************************************/
/*                                                                              */
/*         FUNCTION    : Lcm_sysconfrd6                                         */
/*         NAME        : system_conf.txt��������ؿ�(IPv4/IPv6����)             */
/*                                                                              */
/*         RETURN      : (int) LcmS_OK ���ｪλ                                 */
/*                             LcmS_NG �۾ｪλ                                 */
/*                                                                              */
/*         PARAMETERS  : (struct LcmT_systemconf6) *sysinf6 �����������о���(O) */
/*                       (unsigned char) *regsv             ���������о����(O) */
/*                                                                              */
/********************************************************************************/
extern int Lcm_sysconfrd6( struct LcmT_systemconf6 *sysinf6, unsigned char *regsv);

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         FUNCTION    : Lcm_psstsreg                                         */
/*         NAME        : �����о����ѹ����Τμ�����Ͽ�����                   */
/*                                                                            */
/*         RETURN      : (int) LcmS_OK ���ｪλ                               */
/*                             LcmS_NG �۾ｪλ                               */
/*                                                                            */
/*         PARAMETERS  : (int)            sndsv_cnt ��Ͽ�����п�              */
/*                       (unsigned char) *psno      ��Ͽʪ��������            */
/*                       (int)            queid     ������LPC���塼ID         */
/*                       (int)            event     ���٥���ֹ�              */
/*                       (int)            reg_id    ��Ͽ�����                */
/*                                                                            */
/******************************************************************************/
extern int Lcm_psstsreg( int sndsv_cnt, unsigned char *psno, int queid, int event, int reg_id);

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*     FUNCTION    : Lcm_hcstsreg                                             */
/*     NAME        : �������Хإ륹�����å���ϩ�㳲���Τμ�����Ͽ�����       */
/*                                                                            */
/*     RETURN      : (int) LcmS_OK ���ｪλ                                   */
/*                         LcmS_NG �۾ｪλ                                   */
/*                                                                            */
/*     PARAMETERS  :                                                          */
/*                   (int)            queid     ������LPC���塼ID             */
/*                   (int)            event     ���٥���ֹ�                  */
/*                   (int)            reg_id    ��Ͽ�����                    */
/*                                                                            */
/******************************************************************************/
extern int Lcm_hcstsreg(int queid, int event, int reg_id);

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*     FUNCTION    : Lcm_hcstat                                               */
/*     NAME        : ��ͭ���꤫��إ륹�����å���ϩ���֤����               */
/*                                                                            */
/*     RETURN      : (int) LcmS_OK ���ｪλ                                   */
/*                         LcmS_NG �۾ｪλ                                   */
/*                                                                            */
/*     PARAMETERS  :                                                          */
/*                   (struct LcmT_hcinfo *)  ifnop  �إ륹�����å��ݡ��Ⱦ���  */
/*                                                                            */
/*                                                                            */
/******************************************************************************/
extern int Lcm_hcstat( struct LcmT_hcinfo *ifnop );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*     FUNCTION    : Lcm_svconfstat                                           */
/*     NAME        : ���������߾��֡������о�ʪ���������ֹ��ɤ߽Ф�           */
/*                                                                            */
/*     RETURN      : (int) LcmS_OK ���ｪλ                                   */
/*                         LcmS_NG �۾ｪλ                                   */
/*                                                                            */
/*     PARAMETERS  : (int *)svconf_st  ���������߾���                         */
/*                   (unsigned char *)psno �����о�ʪ���������ֹ�             */
/*                                                                            */
/*                                                                            */
/******************************************************************************/
extern int Lcm_svconfstat(int *svconf_st, unsigned char *psno);

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*     FUNCTION    : Lcm_svinfores                                            */
/*     NAME        : ������������Ͽ�׵ᡢ������Ͽ�׵��������                 */
/*                                                                            */
/*     RETURN      : (int) LcmS_OK ���ｪλ                                   */
/*                         LcmS_NG �۾ｪλ                                   */
/*                                                                            */
/*     PARAMETERS  : (int )svinfo  �����߽�������                             */
/*                   (unsigned char *)psno �����о�ʪ���������ֹ�             */
/*                                                                            */
/*                                                                            */
/******************************************************************************/
extern int Lcm_svinfores(int svinfo, int result);

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*     FUNCTION    : Lcm_dldinf                                               */
/*     NAME        : SBC�ե����०�����������                                */
/*                                                                            */
/*     RETURN      : (int) LcmS_OK ���ｪλ                                   */
/*                         LcmS_NG �۾ｪλ                                   */
/*                                                                            */
/*     PARAMETERS  : (struct LcmT_dldinfreq) dldinreq   �����׵��ѹ�¤��      */
/*                   (struct LcmT_dldinfrsp) *dldinfrsp �����Ǽ�ѹ�¤��      */
/*                                                                            */
/*                                                                            */
/******************************************************************************/
extern int Lcm_dldinf(struct LcmT_dldinfreq dldinfreq, struct LcmT_dldinfrsp *dldinfrsp);

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_SvModeGet                                            */
/*      NAME       : 1�Ų�/2�Ų������ɤ߽Ф�                                  */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned char) psno  ʪ���������ֹ�                     */
/*                   (unsigned char) *mode ���Ų�/���Ų��⡼��                */
/*                                                                            */
/******************************************************************************/
extern int Lcm_SvModeGet(unsigned char psno, unsigned char *mode);

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_SvModeGetChar                                        */
/*      NAME       : 1�Ų�/2�Ų������ɤ߽Ф�(����������̾��ʸ�����б�)        */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (char)          *svname ����������̾��ʸ����             */
/*                   (unsigned char) *mode ���Ų�/���Ų��⡼��                */
/*                                                                            */
/******************************************************************************/
extern int Lcm_SvModeGetChar( char *svname, unsigned char *mode );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_SvNbDigitGet.c                                       */
/*      NAME       : ������ɽ���ֹ����ɤ߽Ф��ؿ�                           */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned char) psno  ʪ���������ֹ�                     */
/*                   (unsigned char) *nbdigit ɽ���ֹ��  ��                  */
/*                                                                            */
/******************************************************************************/
extern int Lcm_SvNbDigitGet( unsigned char psno, unsigned char *nbdigit );

/********************** FUNCTION DESCRIPTION ********************************/
/*                                                                          */
/*         �ؿ�̾         : Lcm_Fupdrop                                     */
/*                          �����ڤ��ᤷ�׵�ؿ�                            */
/*                                                                          */
/*         ���ϥѥ�᡼�� : �ʤ�                                            */
/*                                                                          */
/*         �����         : LcmS_OK ���ｪλ                                */
/*                          LcmS_NG �۾ｪλ                                */
/*                                                                          */
/****************************************************************************/
extern int Lcm_Fupdrop( void );

/********************** FUNCTION DESCRIPTION ********************************/
/*                                                                          */
/*         �ؿ�̾         :  Lcm_LookSwStatus_ouschg                        */
/*                         �����б�ž���ּ����ؿ�(ous�������ɤ߽Ф���ǽ�դ�)*/
/*                                                                          */
/*         ���ϥѥ�᡼�� : ʪ���������ֹ�                                  */
/*                        : ���ֹ�                                          */
/*         ���ϥѥ�᡼�� : ����ž����                                      */
/*                        : ����ž����                                      */
/*                        : ous���������                                   */
/*                                                                          */
/*         �����         : LcmS_OK ���ｪλ                                */
/*                          LcmS_NG �۾ｪλ                                */
/*                                                                          */
/****************************************************************************/
extern int  Lcm_LookSwStatus_ouschg(unsigned char psno, unsigned char sys,
                             int *nodeSt, int *bnodeSt, int *ouschgflg );

/********************** FUNCTION DESCRIPTION ********************************/
/*                                                                          */
/*         �ؿ�̾         : Lcm_fltind                                      */
/*                          �����о㳲����                                  */
/*                                                                          */
/*         ���ϥѥ�᡼�� : �ʤ�                                            */
/*                                                                          */
/*         �����         : LcmS_OK ���ｪλ                                */
/*                          LcmS_NG �۾ｪλ                                */
/*                                                                          */
/****************************************************************************/
extern int Lcm_fltind( int fltcause );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾         : Lcm_SwChgChkProcRes                               */
/*                          ����������礻���������ؿ�                        */
/*                                                                            */
/*         ���ϥѥ�᡼�� : P1   ����������礻��������                       */
/*                          P2   ����������礻�������                       */
/*                                                                            */
/*         �����         : LcmS_OK ���ｪλ                                  */
/*                          LcmS_NG �۾ｪλ                                  */
/*                                                                            */
/*         ����           :                                                   */
/*                                                                            */
/******************************************************************************/
extern int Lcm_SwChgChkProcRes( int ch_type, int result ) ;

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾         : Lcm_SvObjIDGet                                    */
/*                          �����Х��֥�������ID�����ؿ�                      */
/*                                                                            */
/*         ���ϥѥ�᡼�� : P1   ʪ���������ֹ�                               */
/*                          P2   ���ֹ�                                       */
/*                          P3   ���֥�������ID                               */
/*                                                                            */
/*         �����         : LcmS_OK ���ｪλ                                  */
/*                          LcmS_NG �۾ｪλ                                  */
/*                                                                            */
/*         ����           :                                                   */
/*                                                                            */
/******************************************************************************/
extern int Lcm_SvObjIDGet( unsigned char psno, unsigned char sys, char *objid );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾         : Lcm_TMsaveTimerGet                                */
/*                         TM�����ֱ����Ԥ������޾������                     */
/*                                                                            */
/*         ���ϥѥ�᡼�� : P1:OUT(int *)��������                             */
/*                          P2:OUT(int *)��ȥ饤��                           */
/*                                                                            */
/*         �����         : (int)LcmS_OK : ���ｪλ                           */
/*                          (int)LcmS_NG : �۾ｪλ                           */
/*                                                                            */
/*         ����           : TM�����ֱ����Ԥ������޾����������                */
/*                                                                            */
/******************************************************************************/
extern int Lcm_TMsaveTimerGet( int *timer_value, int *timer_rty );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         FUNCTION    : Lcm_misinsertreg                                     */
/*         NAME        : �����и������������Τμ�����Ͽ�����                 */
/*                                                                            */
/*         RETURN      : (int) LcmS_OK ���ｪλ                               */
/*                             LcmS_NG �۾ｪλ                               */
/*                                                                            */
/*         PARAMETERS  : (int)            sndsv_cnt ��Ͽ�����п�              */
/*                       (unsigned char) *psno      ��Ͽʪ��������            */
/*                       (int)            queid     ������LPC���塼ID         */
/*                       (int)            event     ���٥���ֹ�              */
/*                       (int)            reg_id    ��Ͽ�����                */
/*                                                                            */
/******************************************************************************/
extern int Lcm_misinsertreg( int sndsv_cnt, unsigned char *psno, int queid, int event, int reg_id);

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾       : Lcm_atolsid                                         */
/*                        ���������м���ʸ���󤫤�                            */
/*                        ���������м��̥ӥåȥޥå��ͤ����                  */
/*                                                                            */
/*         �ѥ�᡼��   : P1:IN  (char *)         ���������м���ʸ����        */
/*                        P2:OUT (unsigned char *)���������м��̥ӥåȥޥå���*/
/*                                                                            */
/*         �����       : (int)LcmS_OK : ���ｪλ                             */
/*                        (int)LcmS_NG : �۾ｪλ                             */
/*                                                                            */
/*         ����         : ���Ϥ��줿���������м���ʸ��������������м���      */
/*                        �ӥåȥޥå��ͤ��Ѵ�����                            */
/*                                                                            */
/******************************************************************************/
#define Lcm_atolsid(P1, P2)      Lcma_atolsid(LcmS_SELF_NODE, P1, P2)
#define Lcm_atolsid_pair(P1, P2) Lcma_atolsid(LcmS_PAIR_NODE, P1, P2)
extern int Lcma_atolsid( int kind, char *svstr, unsigned char *lsid );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾         : Lcm_atonodeid                                     */
/*                          �Ρ��ɼ���ʸ���󤫤�                              */
/*                          �Ρ��ɼ��̥ӥåȥޥå��ͤ����                    */
/*                                                                            */
/*         �ѥ�᡼��     : P1:IN  (char *)         �Ρ��ɼ���ʸ����          */
/*                          P2:OUT (unsigned char *)�Ρ��ɼ��̥ӥåȥޥå���  */
/*                                                                            */
/*         �����         : (int)LcmS_OK : ���ｪλ                           */
/*                          (int)LcmS_NG : �۾ｪλ                           */
/*                                                                            */
/*         ����           : ���Ϥ��줿�Ρ��ɼ���ʸ�����Ρ��ɼ���            */
/*                          �ӥåȥޥå��ͤ��Ѵ�����                          */
/*                                                                            */
/******************************************************************************/
extern int Lcm_atonodeid( char *nodestr, unsigned char *nodeid );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾         : Lcm_lsidtoa                                       */
/*                          ���������м��̥ӥåȥޥå��ͤ������������м���    */
/*                          ʸ��������                                      */
/*                                                                            */
/*         �ѥ�᡼��     : P1:IN (unsigned char)���������м��̥ӥåȥޥå��� */
/*                          P2:OUT(char *)       ���������м���ʸ����         */
/*                                                                            */
/*         �����         : (int)LcmS_OK : ���ｪλ                           */
/*                          (int)LcmS_NG : �۾ｪλ                           */
/*                                                                            */
/*         ����           : ���Ϥ��줿���������м��̥ӥåȥޥå��ͤ�����������*/
/*                          ����ʸ������Ѵ�����                              */
/*                                                                            */
/******************************************************************************/
#define Lcm_lsidtoa(P1, P2)      Lcma_lsidtoa(LcmS_SELF_NODE, P1, P2)
#define Lcm_lsidtoa_pair(P1, P2) Lcma_lsidtoa(LcmS_PAIR_NODE, P1, P2)
extern int Lcma_lsidtoa( int kind, unsigned char lsid, char *svstr );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾         : Lcm_nodeidtoa                                     */
/*                          �Ρ��ɼ��̥ӥåȥޥå��ͤ���Ρ��ɼ���            */
/*                          ʸ��������                                      */
/*                                                                            */
/*         �ѥ�᡼��     : P1:IN (unsigned char)�Ρ��ɼ��̥ӥåȥޥå���     */
/*                          P2:OUT(char *)       �Ρ��ɼ���ʸ����             */
/*                                                                            */
/*         �����         : (int)LcmS_OK : ���ｪλ                           */
/*                          (int)LcmS_NG : �۾ｪλ                           */
/*                                                                            */
/*         ����           : ���Ϥ��줿�Ρ��ɼ��̥ӥåȥޥå��ͤ�Ρ���        */
/*                          ����ʸ������Ѵ�����                              */
/*                                                                            */
/******************************************************************************/
extern int Lcm_nodeidtoa( unsigned char nodeid, char *nodestr );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : LcmF_Errno(lcm_errno)                                    */
/*      NAME       : lcm_errno ��Ǽ��                                         */
/*                                                                            */
/*      RETURN     : int                                                      */
/*                                                                            */
/*      PARAMETERS : void                                                     */
/*                                                                            */
/******************************************************************************/
extern int *LcmF_Errno( void );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : Lcm_DkRspChk                                             */
/*      NAME       : HDD���������ġ��Բ�Ƚ��ؿ�                              */
/*                                                                            */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                  */
/*                         LcmS_NG  �۾ｪλ                                  */
/*                                                                            */
/*      PARAMETERS : (unsigned int *)                                         */
/*                                                                            */
/******************************************************************************/
extern int Lcm_DkRspChk( unsigned int *);

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾         : Lcm_SwChgProcRes_ftm                              */
/*                          �������ܱ��������ؿ�(FTM����)                     */
/*                                                                            */
/*         ���ϥѥ�᡼�� : P1   �ڤ��ؤ���������                             */
/*                          P2   ���ڤ��ؤ��������                           */
/*                          P3   �ץ��������̻�                               */
/*                                                                            */
/*         �����         : LcmS_OK ���ｪλ                                  */
/*                          LcmS_NG �۾ｪλ                                  */
/*                                                                            */
/*         ����           :                                                   */
/*                                                                            */
/******************************************************************************/
extern int Lcm_SwChgProcRes_ftm( int ch_type, int result, int procid );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾         : Lcm_FailSwProcRes_ftm                             */
/*                          �㳲�����ر��������ؿ�(FTM����)                   */
/*                                                                            */
/*         ���ϥѥ�᡼�� : P1   ��������                                     */
/*                          P2   �������                                     */
/*                          P3   �ץ��������̻�                               */
/*                                                                            */
/*         �����         : LcmS_OK ���ｪλ                                  */
/*                          LcmS_NG �۾ｪλ                                  */
/*                                                                            */
/******************************************************************************/
extern int Lcm_FailSwProcRes_ftm( int event_type, int result, int procid );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*     FUNCTION    : Lcm_svinfores_ftm                                        */
/*     NAME        : ������������Ͽ�׵ᡢ������Ͽ�׵��������(FTM����)        */
/*                                                                            */
/*     RETURN      : (int) LcmS_OK ���ｪλ                                   */
/*                         LcmS_NG �۾ｪλ                                   */
/*                                                                            */
/*     PARAMETERS  : (int )svinfo  �����߽�������                             */
/*                   (unsigned char *)psno �����о�ʪ���������ֹ�             */
/*                                                                            */
/*                                                                            */
/******************************************************************************/
extern int Lcm_read_stfile ( unsigned char *, unsigned char * );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*     FUNCTION    : Lcm_svinfores_ftm                                        */
/*     NAME        : ������������Ͽ�׵ᡢ������Ͽ�׵��������(FTM����)        */
/*                                                                            */
/*     RETURN      : (int) LcmS_OK ���ｪλ                                   */
/*                         LcmS_NG �۾ｪλ                                   */
/*                                                                            */
/*     PARAMETERS  : (int )svinfo  �����߽�������                             */
/*                   (unsigned char *)psno �����о�ʪ���������ֹ�             */
/*                                                                            */
/*                                                                            */
/******************************************************************************/
extern int Lcm_svinfores_ftm(int svinfo, short result, int procid);

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾         : Lcm_MemClrRes                                     */
/*                          ���ꥯ�ꥢ���������ؿ�                          */
/*                                                                            */
/*         ���ϥѥ�᡼�� : P1   ���ڤ��ؤ��������                           */
/*                                                                            */
/*         �����         : LcmS_OK ���ｪλ                                  */
/*                          LcmS_NG �۾ｪλ                                  */
/*                                                                            */
/*         ����           :                                                   */
/*                                                                            */
/******************************************************************************/
#define Lcm_MemClrRes(P1)           Lcma_MemClrRes(LcmS_NON_NODE,  0, P1)
#define Lcm_MemClrRes_lnode(P1, P2) Lcma_MemClrRes(LcmS_ADD_NODE, P1, P2)
extern int Lcma_MemClrRes( int kind, unsigned int lnid, int result );

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾         : Lcm_MemClrRes_ftm                                 */
/*                          ���ꥯ�ꥢ���������ؿ�(FTM����)                 */
/*                                                                            */
/*         ���ϥѥ�᡼�� : P1   ���ڤ��ؤ��������                           */
/*                          P2   �ץ��������̻�                               */
/*                                                                            */
/*         �����         : LcmS_OK ���ｪλ                                  */
/*                          LcmS_NG �۾ｪλ                                  */
/*                                                                            */
/*         ����           :                                                   */
/*                                                                            */
/******************************************************************************/
extern int Lcm_MemClrRes_ftm( int result, int procid );

/********************** FUNCTION DESCRIPTION ********************************/
/*                                                                          */
/*      FUNCTION   : Lcm_chgmodeget                                         */
/*      NAME       : �����إ⡼�ɼ����ؿ�                                   */
/*                                                                          */
/*      RETURN     : (int) LcmS_OK  ���ｪλ                                */
/*                         LcmS_NG  �۾ｪλ                                */
/*                                                                          */
/*      PARAMETERS : ( int *)                                               */
/*                                                                          */
/****************************************************************************/
extern int Lcm_chgmodeget(int * chgmode);

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾         : Lcm_sysconfmltrd_file                             */
/*                          �����ƥ���߻���system_conf_mlt.txt��������ؿ�   */
/*                                                                            */
/*         ���ϥѥ�᡼�� : P1   ���������������о���                         */
/*                          P2   �������������о����                         */
/*                                                                            */
/*         �����         : LcmS_OK ���ｪλ                                  */
/*                          LcmS_NG �۾ｪλ                                  */
/*                                                                            */
/******************************************************************************/
extern int Lcm_sysconfmltrd_file(struct LcmT_sysconfmlt  *sysinf, int *svcnt);

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾         : Lcm_sysconfmltrd_file6                            */
/*                          �����ƥ���߻���system_conf_mlt.txt��������ؿ�   */
/*                          (IPv4/IPv6����)                                   */
/*                                                                            */
/*         ���ϥѥ�᡼�� : P1   ���������������о���                         */
/*                          P2   �������������о����                         */
/*                                                                            */
/*         �����         : LcmS_OK ���ｪλ                                  */
/*                          LcmS_NG �۾ｪλ                                  */
/*                                                                            */
/******************************************************************************/
extern int Lcm_sysconfmltrd_file6(struct LcmT_sysconfmlt6  *sysinf6, int *svcnt);

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾         : Lcm_LookSwStatus_SelfSt                           */
/*                          �������и���ž���ּ����ؿ�                        */
/*                                                                            */
/*         �ѥ�᡼�� :     void                                              */
/*                                                                            */
/*         �����         : (int)�������и���ž����                           */
/*                                                                            */
/*         ����           : �������и���ž���֤�������롣                    */
/*                                                                            */
/******************************************************************************/
extern int Lcm_LookSwStatus_SelfSt(void);

/********************** FUNCTION DESCRIPTION ********************************/
/*                                                                          */
/*      FUNCTION   : Lcm_execution_sync                                     */
/*      NAME       : CR���顼��ȯ�����Υ���ž��̵ͭ��Ƚ��                 */
/*                                                                          */
/*      RETURN     : (int) LcmS_ON  ����ž��ͭ                            */
/*                         LcmS_OFF ����ž��̵                            */
/*                                                                          */
/*      PARAMETERS : void                                                   */
/*                                                                          */
/****************************************************************************/
extern int Lcm_execution_sync(void);

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾         : Lcm_hwmodelget                                    */
/*                          SBC�������ֹ��ɤ߽Ф��ؿ�                         */
/*                                                                            */
/*         �ѥ�᡼��     : P1:OUT   �����ֹ�(��ǥ�)                         */
/*                                                                            */
/*         �����         : LcmS_OK ���ｪλ                                  */
/*                          LcmS_NG �۾ｪλ                                  */
/*                                                                            */
/******************************************************************************/
extern int Lcm_hwmodelget(unsigned char *model);

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾       : Lcm_sysrcv_filectl                                  */
/*                                                                            */
/*         �ѥ�᡼��   : P1:IN ��������                                      */
/*                        P2:IN �о�ʪ���������ֹ�                            */
/*                        P3:IN �о�ʪ�������з��ֹ�                          */
/*                                                                            */
/*         �����       : LcmS_OK ���ｪλ                                    */
/*                        LcmS_NG �۾ｪλ                                    */
/*                                                                            */
/*         ����         : sysrecovery̤�»ܸ����ѥե�������������           */
/*                                                                            */
/******************************************************************************/
extern int Lcm_sysrcv_filectl( int mode, unsigned char psno, unsigned char sys );

#ifdef Jpdt_vEPC
/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*         �ؿ�̾         : Lcm_get_sshhost                                   */
/*                          SSH����������SG�ǡ�������                         */
/*                                                                            */
/*         �ѥ�᡼�� :     P1:OUT (struct LcmT_sshhost *)����SG�ǡ���        */
/*                                                                            */
/*         �����         : (int)LcmS_OK : ���ｪλ                           */
/*                          (int)LcmS_NG : �۾ｪλ                           */
/*                          (int)LcmS_NOFUNC : �ۥ��ȡݥ�����Ϣ�ȵ�ǽ̵��     */
/*                                                                            */
/******************************************************************************/
extern int Lcm_get_sshhost(struct LcmT_sshhost *sshhost);
#endif /* Jpdt_vEPC */

/********************** FUNCTION DESCRIPTION **********************************/
/*                                                                            */
/*      FUNCTION   : LcmF_Logguard()                                          */
/*      NAME       : lcm_logguard ��Ǽ��                                      */
/*                                                                            */
/*      RETURN     : int                                                      */
/*                                                                            */
/*      PARAMETERS : void                                                     */
/*                                                                            */
/******************************************************************************/
extern int *LcmF_Logguard( void );

#ifdef __cplusplus
}
#endif

#define lcm_errno (*LcmF_Errno())
#define lcm_logguard (LcmF_Logguard())

#endif /* !_LCMLIB_H */
/*------------------------------ END OF FILE ---------------------------------*/
