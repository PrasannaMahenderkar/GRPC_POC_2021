#include<stdio.h>
#include<stdlib.h>
#include"DbgCom.h"
int main()
{
	DbgFTrc(DbgDTxt,"[EMC-ROUTE]===>>Semcc_hopre_cause_set START");
}
