/***********************************************************************

�Υե����복�ס�    �ģ�� �ƣɣƣϤκ���
�ε�ǽ�֥��å�̾��  �ǥХå��ץ�������ʣģ���
�Υ⥸�塼��̾��    �������

    Copyright (C) 2000,2001 NEC Corporation
    NEC CONFIDENTIAL AND PROPRIETARY
    All rights reserved by NEC Corporation.

***********************************************************************/

#ifndef lint
static char ident_DbgfAgFifoCreat_c[] = "$Id: DbgfAgFifoCreat.c,v 1.1 2004/11/22 09:10:30 youki Exp $";
#endif

#include "opf_func.h"
#include "DbgfAg.h"
#include "DbgCom.h"

void *DbgfAgFifoCreat(size_t reserve, key_t shmkey, size_t bufsize)
{
	size_t		size;
	DbgsAgFifo_t	*fifo;
	void		*shmaddr;

	reserve = DbgmAgRound(reserve);

	size = reserve + sizeof(DbgsAgFifo_t) + bufsize - 1;

	if((shmaddr = DbgfAgShmCreat(shmkey, size)) == (void *)-1) {
		return (void *)-1;
	}

	fifo = (DbgsAgFifo_t *)((char *)shmaddr + reserve);

	fifo->bufsize = bufsize;
	fifo->r_off = 0;
	fifo->w_off = 0;
	fifo->e_off = 0;

	return shmaddr;
}
