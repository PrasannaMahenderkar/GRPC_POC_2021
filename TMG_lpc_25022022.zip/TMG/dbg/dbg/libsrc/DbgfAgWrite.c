/***********************************************************************

�Υե����복�ס�    �ģ�� �ƣɣƣϤؤν񤭹���
�ε�ǽ�֥��å�̾��  �ǥХå��ץ�������ʣģ���
�Υ⥸�塼��̾��    �������

    Copyright (C) 2000,2001 NEC Corporation
    NEC CONFIDENTIAL AND PROPRIETARY
    All rights reserved by NEC Corporation.

***********************************************************************/

#ifndef lint
static char ident_DbgfAgWrite_c[] = "$Id: DbgfAgWrite.c,v 1.1 2004/11/22 09:10:31 youki Exp $";
#endif

#include "opf_func.h"
#include <string.h>

#include "DbgfAg.h"
#include "DbgCom.h"

int DbgfAgWrite(DbgsAgFifo_t *fifo, const void *buf1, int len1,
											const void *buf2, int len2)
{
	const int	bufsize = fifo->bufsize;
	const int	r_off = fifo->r_off;
	const int	len = len1 + len2;
	int			capacity;

	if(r_off > fifo->w_off) {
		capacity = r_off - fifo->w_off - 1;
	} else {
		capacity = bufsize - fifo->w_off;
		if(len > capacity && r_off != 0) {
			fifo->e_off = fifo->w_off;
			fifo->w_off = 0;

			capacity = r_off - fifo->w_off - 1;
		}
	}

	if(len > capacity || len < 0) {
		return -1;
	}

	memcpy(&fifo->buf[fifo->w_off], buf1, len1);
	fifo->w_off += len1;
	memcpy(&fifo->buf[fifo->w_off], buf2, len2);
	fifo->w_off += len2;

	if(fifo->e_off < fifo->w_off) fifo->e_off = fifo->w_off;

	return 0;
}
