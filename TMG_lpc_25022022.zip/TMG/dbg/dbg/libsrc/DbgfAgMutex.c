/***********************************************************************

�Υե����복�ס�    �ģ�� �ͣ����������
�ε�ǽ�֥��å�̾��  �ǥХå��ץ�������ʣģ���
�Υ⥸�塼��̾��    �������

    Copyright (C) 2000,2001 NEC Corporation
    NEC CONFIDENTIAL AND PROPRIETARY
    All rights reserved by NEC Corporation.

***********************************************************************/

#ifndef lint
static char ident_DbgfAgMutex_c[] = "$Id: DbgfAgMutex.c,v 1.1 2004/11/22 09:10:30 youki Exp $";
#endif

#include "opf_func.h"
#include <unistd.h>
#ifdef _SC_THREADS
#include <pthread.h>
#endif
#include <sys/time.h>
#include <errno.h>

#include "DbgfAg.h"
#include "DbgCom.h"

#ifdef _SC_THREADS
static pthread_mutex_t	lock = PTHREAD_MUTEX_INITIALIZER;
#endif

extern int DbgdRetry;

int DbgfAgMutexTryLock(void)
{
#ifdef _SC_THREADS
    int             i;
    struct timeval  timeout;

    for(i = 0; i <= DbgdRetry; i++)
	{
    	if(!pthread_mutex_trylock(&lock))
		{
			return 0;
		}
        timeout.tv_sec  = 0;
        timeout.tv_usec = 10;               /* 10ms sleep(10us ���˾)  */
        select(1, NULL, NULL, NULL, &timeout);
    }
    return -1;
#else
	return 0;
#endif
}

int DbgfAgMutexLock(void)
{
#ifdef _SC_THREADS
	if(pthread_mutex_lock(&lock)) {
		return -1;
	}
#endif

	return 0;
}

int DbgfAgMutexUnlock(void)
{
#ifdef _SC_THREADS
	if(pthread_mutex_unlock(&lock)) {
		return -1;
	}
#endif

	return 0;
}
