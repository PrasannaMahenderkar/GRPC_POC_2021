/******************************************************************************
* �����ƥ�̾: OPF                                                             *
* �ƣ�̾    : Dbg                                                             *
* �ե�����̾: dbg_string.h                                                    *
* ����      : opf_func.h�饤�֥������                                      *
* ����      : ����ѥ��륪�ץ�����-O2���б�                                 *
******************************************************************************/
#ifndef __DBG_STRING_H__
#define __DBG_STRING_H__

#if !defined(CGHV) && !defined(RHEL)

#undef        strcmp
#undef        strncmp
#undef        memset
#undef        strcpy
#undef        strncpy
#undef        strncat
#undef        strtok
#undef        strtok_r
#undef        strncat

#define       strcmp        opf_strcmp
#define       strncmp       opf_strncmp
#define       memset        opf_memset
#define       strcpy        opf_strcpy
#define       strncpy       opf_strncpy
#define       strncat       opf_strncat
#define       strtok        opf_strtok
#define       strtok_r      opf_strtok_r
#define       strncat       opf_strncat

#endif

#endif
