/***********************************************************************

�Υե����복�ס�    �ģ�������إå��ʣ�����
�ε�ǽ�֥��å�̾��  �ǥХå��ץ�������ʣģ���
�Υ⥸�塼��̾��    -------

    Copyright (C) 2000,2001 NEC Corporation
    NEC CONFIDENTIAL AND PROPRIETARY
    All rights reserved by NEC Corporation.

***********************************************************************/

#ifndef _DbgfAg_h
#define _DbgfAg_h

#ifndef lint
static char ident_DbgfAg_h[] = "$Id: DbgfAg.h,v 1.1 2004/11/22 09:10:29 youki Exp $";
#endif

#include <sys/types.h>
#include "DbgCom.h"

typedef struct {
	char	*word;
	void	(*func)(void *, char **, unsigned int);
} DbgsAgDict_t;

#define DbgmAgRound(x)	(((x) + 7) / 8 * 8)
#define DbgdAgBufSize   8192

extern void DbgfAgDate(time_t, char *, size_t);
extern void DbgfAgDateTime(time_t, char *, size_t);
extern int DbgfAgLastFile(const char *, const char *, const char *,
														char *, size_t);
extern int DbgfAgFiles(const char *, const char *, const char *);
extern int DbgfAgDivShmAt(key_t, size_t, void **, void **);
extern void *DbgfAgFifoCreat(size_t, key_t, size_t);
extern int DbgfAgFlush(int, DbgsAgFifo_t *);
extern int DbgfAgFstat(int, int);
extern int DbgfAgStat(const char *);
extern int DbgfAgMutexTryLock(void);
extern int DbgfAgMutexLock(void);
extern int DbgfAgMutexUnlock(void);
extern int DbgfAgOpen(const char *);
extern int DbgfAgRmFile(const char *, const char *, char *, size_t);
extern int DbgfAgRmFiles(const char *, const char *, const char *);
extern int DbgfAgRetry(int);
extern int DbgfAgSemTryLock(int, int);
extern int DbgfAgSemLock(int, int);
extern int DbgfAgSemUnlock(int);
extern int DbgfAgSemRm(key_t);
extern void *DbgfAgShmAt(key_t);
extern void *DbgfAgShmCreat(key_t, size_t);
extern int DbgfAgShmRm(key_t);
extern int DbgfAgTrans(const DbgsAgDict_t *, void *);
extern int DbgfAgWrite(DbgsAgFifo_t *, const void *, int, const void *, int);
extern int DbgSemLock(key_t semkey, int trynum);
extern void DbgSemUnlock(key_t semkey) ;

#endif /* _DbgfAg_h */
