/******************************************************************************
* �����ƥ�̾: OPF                                                             *
* �ƣ�̾    : Opm                                                             *
* �ե�����̾: Caplib.h                                                        *
* ����      : Cap����define���                                               *
* ����      :                                                                 *
******************************************************************************/

/* Cap_define Marking */
#ifndef		__Caplib__
#define		__Caplib__

#ifdef CVS
static const char Caplib_h[] =
	"$Id: Caplib.h,v 1.2 2005/09/29 12:07:10 utsumi Exp $";
#endif

#include <pthread.h>

/* CapF_CapProcId : Cap ProcId definesion : 1 to 64 */
/* CapV_opm list definesion : 10 to 19 */
#define		CapV_opminit	(10)  /* Opm Init ProcId */
#define		CapV_opmctrl	(11)  /* Opm main ProcId */
#define		CapV_opm		CapV_opmctrl
#define		CapV_opmwatch	(12)  /* Opm system watcher ProcId */
#define		CapV_opmcom		(17)  /* Opmc ProcId */

/* CapV_tim list definesion : 20 to 29 */

/* CapV_dbg list definesion : 30 to 39 */
#define		CapV_dbg		(30)  /* Dbg ProcId */
#define		CapV_dbgfree    (31)  /* Dbg IPC free */
#define		CapV_dbgmain	(32)  /* DbgMain ProcId */

/* CapV_alm list definesion : 40 to 49 */
#define		CapV_alm		(40)  /* Alm ProcId */
#define		CapV_almfree		(41)  /* AlmIPCfree ProcId */
#define		CapV_almmain	(42)  /* AlmMain ProcId */
#define		CapV_almlog		(43)  /* AlmLog ProcId  */
#define 	CapV_almtrap	(44)  /* Alm Trap ProcId */
#define		CapV_almSktActSby	(45)  /* Alm Act-Sby���̿��ץ�����*/
#define		CapV_almSktFs	(46)  /* Alm Fs-Sbc ���̿�FS�ץ�����*/
#define		CapV_almSktSbc	(47)  /* Alm Fs-Sbc ���̿�SBC�ץ�����*/
#define		CapV_almlogcom	(48)  /* AlmLogCom ProcId*/

/* CapV_mbm list definesion : 50 to 59 */
#define		CapV_mbm		(50)  /* Mbm ProcId */
#define		CapV_mbmfree		(51)  /* MbmIPCfree ProcId */
#define		CapV_almlogcomccf	(59)  /* AlmLogComCcf ProcId*/

/* CapV_tmg list definesion : 60 to 69 */

/* CapV_lcm list definesion : 70 to 79 */
#define		CapV_lcm			(70) /* Lcm ProcId */
#define		CapV_lcmmain		(72) /* LcmMain ProcId */
#if 0
#define		CapV_clmsw			(51) /* clmsw */
#define		CapV_ClmIPCfree		(52) /* clmIPCfree   */
#define		CapV_clmipf			(54) /* clmipf   */
#define		CapV_tcpifmgr		(55) /* tcpifmgr */
#define		CapV_tcpif0			(56) /* tcpif0   */
#define		CapV_tcpif1			(57) /* tcpif1   */
#define		CapV_pipinfo		(58) /* pipinfo  */
#define		CapV_pipref			(59) /* pipref   */
#endif

/* CapV_lsf list definesion : xx to xx */
#define		CapV_lsfmain		(200) /* Lcf ProcId */

/* CapV_prm list definesion : 240 to xxx */
#define         CapV_prm                (240) /* PrM ProcId *//* ������(������SG�ե����뤫����ɤ߹��ߤˤ���) */

/* CapV_tmp list definesion : 500 to 511 (opm used) */
#define		CapV_TMPPROC		(500)
#define		CapV_RESTOREPROC	(501)

/* CapV_srvctl list definesion 502 to xx (opm used) */
#define         CapV_SRVCTLPROC         (502)

/* CapV_loadctl list definesion 503 to xx (opm used) */
#define         CapV_BKLOADTRS          (503)

/* CapV_cmd list definesion : xx to xx */
#define		CapV_CMDPROC		(4096)


/* CapF_SystemId : System Id definesion */
#define		CapS_SYSIDEXOS		(0x01)	/* EXOS (No.7) */
#define		CapS_SYSIDCAP		(0x02)	/* Common APlcation */
#define		CapS_SYSIDAPL		(0x10)	/* User Aplcation */

/* CapF_CapFunction : Common Aplcation Function Id definesion */
#define		CapS_FIDCAP		(0x00)	/* Cap Union ID */
#define		CapS_FIDOPM		(0x01)	/* Opm ID */
#define		CapS_FIDALM		(0x02)	/* Alm ID */
#define		CapS_FIDMBM		(0x03)	/* Mbm ID */
#define		CapS_FIDTRM		(0x04)	/* Trm ID */
#define		CapS_FIDCOM		(0x05)	/* Com ID */

/* CapF_ReturnValue : Common Aplcation Function Return Value */
#define		CapS_OK			(0)
#define		CapS_NG			(-1)

/* CapF_YesNo */
#define		CapS_YES		(1)
#define		CapS_NO			(0)

/* CapF_OnOff */
#define		CapS_ON			(1)
#define		CapS_OFF		(0)

#define		CapS_NODATA		(1)

/* CapF_Eenviron : Cap Common Environment */
#define		CapS_PH			"PH"
#define		CapS_MAINDIR	"MAINDIR"


/*
 *  System ID Encoder Macro
 *    unsigned int CapM_SysIdec(sysid, funcid, free);
 *	unsigend char sysid;
 *	unsigend char funcid;
 *	unsigend short free;
 */
#define		CapM_SysIdec(sysid, funcid, free)		\
	(((CapS_SYSIDEXOS <= sysid) && (sysid <= 0xFF)) &&	\
	 ((0 <= funcid) && (funcid <= 0xFF)) &&			\
	 ((0 <= free) && (free <= 0xFFFF))) ?			\
	((sysid << 24) | ((funcid & 0xFF)<< 16) | (free & 0xFFFF)) : \
	0

/*
 *  System ID Dncoder Macro
 *    unsigned int CapM_SysIddc(code, p_sysid, p_funcid, p_free);
 *	unsigend int code;
 *	unsigend char *p_sysid;
 *	unsigend char *p_funcid;
 *	unsigend short *p_free;
 */
#define		CapM_SysIddc(code, p_sysid, p_funcid, p_free)	\
	{ *p_sysid = (code >> 24);				\
	  *p_funcid = ((code >> 16) & 0xFF);			\
	  *p_free = (code & 0xFFFF);				\
	}




/* CapD_ThreadStat icKeySet */
typedef struct {
	int            flag;
	pthread_key_t  key;
} CapTs_ThreadStaticKey_t;

#define CapDv_ThreadStaticKeySetting            (-1)
#define CapDv_ThreadStaticKeySetOff             (0)
#define CapDv_ThreadStaticKeySetOn              (1)

#define CapDi_ThreadStaticKey_Init              { CapDv_ThreadStaticKeySetOff }
/************************/
/* usr open function's  */
/************************/
#ifdef __cplusplus
extern "C" {
#endif

extern void *CapF_ThreadStaticArea_Get( CapTs_ThreadStaticKey_t * );
extern int CapF_ThreadStaticArea_Creater( CapTs_ThreadStaticKey_t *,
                                   void *(*)(void), void (*)(void *) );
extern void CapF_ThreadStaticArea_Destructor( void * );

#ifdef __cplusplus
}
#endif

#define CapE_AllReady                           (0x0001)
#define CapE_AllocNg                            (0x0002)

#define CapE_KeyCreating                        (0x0010)
#define CapE_KeyCreateNg                        (0x0011)
#define CapE_KeyFlagFault                       (0x0012)

#define CapE_UserCreaterNg                      (0x0100)
#define CapE_SetspecificNg                      (0x0101)

/* �����������֤����ܻ��֤κ�ʬ */
#define JTZ										(9)
#endif

#ifdef __sparcv9
#define SYS_NERR								(152)
#endif

