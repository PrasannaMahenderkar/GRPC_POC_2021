/**********************************************************************
*                                                                     *
* NEC TECHNOLOGIES INDIA CONFIDENTIAL AND PROPRIETARY                 *
*                                                                     *
* COPYRIGHT (C) NEC CORPORATION INDIA, LTD 2021                       *
*                                                                     *
* ALL RIGHTS RESERVED BY NEC CORPORATION, LTD. THIS PROGRAM MUST      *
* BE USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY        *
* NEC CORPORATION, LTD. NO PART OF THIS PROGRAM MAY BE REPRODUCED     *
* OR DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN      *
* PERMISSION OF NEC CORPORATION, LTD.                                 *
*                                                                     *
*USE OF COPYRIGHT NOTICE DOES NOT EVIDENCE PUBLICATION OF THE PROGRAM.*
*                                                                     *
* NEC CORPORATION CONFIDENTIAL AND PROPRIETARY                        *
*                                                                     *
**********************************************************************/  
/*
 * Title: main.c
 * Description : This file contains wrapper code to send request to Timer
 *  client
 * Revision History
 * Owner                Date                Reason for change  
 * Prasanna M	        20-01-2020          Initial version created
 **********************************************************************/ 
#include <stdio.h>
#include "Timer_wrap.h"
#include <pthread.h>	
#include "DbgCom.h"
#include "Timer_service_lpc_if.h"

#define MAX_RECEIVE_QUEUES 24 //12 receive set timer queues and 12 cancel timer queues


int main()
{
    DbgFTrc(DbgDTxt,"------------main() called -----------");
    
    pthread_t serverThread, clientThread;
  
    pthread_create(&clientThread, NULL, Timer_wrap_client_run, NULL);
    pthread_create(&serverThread, NULL, Timer_wrap_server_run, NULL);

    pthread_t ipcReceiveThread[MAX_RECEIVE_QUEUES];
    Timer_wrap_init();
    //for(int queueid = TMR_SRV_EMC_SETTIMER; queueid < TMR_SRV_EVC_SETTIMER; ++queueid)
    //{
        int queueid = TMR_SRV_EMC_SETTIMER;
        DbgFDbg(DbgDTxt,"Creating set timer pthread for queue id : %d\n", queueid);
        pthread_create(&ipcReceiveThread[TMR_SRV_EMC_SETTIMER], NULL, Timer_service_lpc_settimer_receive, (void*)&queueid);
        sleep(5);
    //}

   // for(int queueid = TMR_SRV_EMC_CANCELTIMER; queueid < TMR_SRV_EVC_CANCELTIMER; ++queueid)
   // {
        int queueid1 = TMR_SRV_EMC_CANCELTIMER;
        DbgFDbg(DbgDTxt,"Creating cancel timer pthread for queue id : %d\n", queueid);
        pthread_create(&ipcReceiveThread[TMR_SRV_EMC_CANCELTIMER], NULL, Timer_service_lpc_canceltimer_receive, (void*)&queueid1);
  //  }
    
 
    // wait for threads to finish
    pthread_join(serverThread,NULL);
    pthread_join(clientThread,NULL);
   // for(int queueid = TMR_SRV_EMC_SETTIMER; queueid < TMR_SRV_EVC_SETTIMER; ++queueid)
    //{
    	pthread_join(ipcReceiveThread[TMR_SRV_EVC_SETTIMER],NULL);
    //}

    //for(int queueid = TMR_SRV_EMC_CANCELTIMER; queueid < TMR_SRV_EVC_CANCELTIMER; ++queueid)
    //{
        pthread_join(ipcReceiveThread[TMR_SRV_EVC_CANCELTIMER],NULL);
    //}
}
