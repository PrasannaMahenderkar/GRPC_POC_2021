/**********************************************************************
*                                                                     *
* NEC TECHNOLOGIES INDIA CONFIDENTIAL AND PROPRIETARY                 *
*                                                                     *
* COPYRIGHT (C) NEC CORPORATION INDIA, LTD 2021                       *
*                                                                     *
* ALL RIGHTS RESERVED BY NEC CORPORATION, LTD. THIS PROGRAM MUST      *
* BE USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY        *
* NEC CORPORATION, LTD. NO PART OF THIS PROGRAM MAY BE REPRODUCED     *
* OR DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN      *
* PERMISSION OF NEC CORPORATION, LTD.                                 *
*                                                                     *
*USE OF COPYRIGHT NOTICE DOES NOT EVIDENCE PUBLICATION OF THE PROGRAM.*
*                                                                     *
* NEC CORPORATION CONFIDENTIAL AND PROPRIETARY                        *
*                                                                     *
**********************************************************************/ 
/*
 * Title: Timer_client.cc
 * Description : This file contains client code to interact with Timer pod
 * over Grpc
 * Revision History
 * Owner                Date                Reason for change  
 * Prasanna M	        20-01-2020          Initial version created
 **********************************************************************/ 
#include <string>
#include "Timer_client.h"
#include "Timer_wrap.h"
#include "Tmg_if_CommonDebug.h"
#include "DbgCom.h"
/************************************************************************
* Function Name: Timer_client(const Timer_client& client)
*
* @brief:  Copy constructor
*                               
* @param[in]: Timer_client
*
* @return:    None
************************************************************************/
Timer_client::Timer_client(const Timer_client& client)
{
	m_stub_ = std::unique_ptr<Timer::Stub>(client.m_stub_.get());
}
/************************************************************************
* Function Name: ~Timer_client()
*
* @brief:  destructor
*                               
* @param[in]: None
*
* @return:    None
************************************************************************/
Timer_client::~Timer_client()
{
}
/************************************************************************
* Function Name: Timer_client(std::shared_ptr<Channel> channel) 
*
* @brief:  parameterized constructor
*                               
* @param[in]: std::shared_ptr<Channel> channel
*
* @return:    None
************************************************************************/
Timer_client::Timer_client(std::shared_ptr<Channel> channel) 
    : m_stub_(Timer::NewStub(channel))
{
}
/************************************************************************
* Function Name: Timer_client& operator=(const Timer_client& client) 
*
* @brief:  copy Assignment constructor
*                               
* @param[in]: Timer_client&
*
* @return:    Timer_client& 
************************************************************************/
Timer_client& Timer_client::operator=(const Timer_client& client)
{
	m_stub_ = std::unique_ptr<Timer::Stub>(client.m_stub_.get());
        if(m_stub_ != nullptr)
	   DbgFDbg(DbgDTxt,"Timer_client::operator=");
	return *this;
}
/************************************************************************
* Function Name: ResultResponse Timer_client::SetTimer(char* servicenm, int32_t userid, uint32_t timerid, char* userdata, int64_t timeout)
*
* @brief:  this function is used to send SetTimer request over GRPC
*                               
* @param[in]: char* servicenm, 
*             int32_t userid, 
*             uint32_t timerid,
*             char* userdata,
*             int64_t timeout
*
* @return:    Timer_client& 
************************************************************************/
ResultResponse Timer_client::SetTimer(char* servicenm, int32_t userid, uint32_t timerid, char* userdata, int64_t timeout)
{
	RequestSetTimer request;
	request.set_userdata(std::string(userdata));
	request.set_userid(userid);
	request.set_timerid(timerid);
	request.set_tmout(timeout);
	request.set_servicename(std::string(servicenm));

	ResultResponse reply;

	ClientContext context;

	DbgFDbg(DbgDTxt,"Timer_client::SetTimer() called : %d", timerid);
        if(m_stub_ != nullptr)
              DbgFDbg(DbgDTxt,"m_stub_  is not null");
	Status status = m_stub_->SetTimer(&context, request, &reply);
	if(!status.ok()){
	    reply.set_result(-1);
	    DbgFDbg(DbgDTxt,"%d : %s", status.error_code(), status.error_message());
	}
	return reply;
}
/************************************************************************
* Function Name: ResultResponse Timer_client::CancelTimer(uint32_t timerid)
*
* @brief:  CancelTimer is a function to handle Cancellation of a timerID
*                               
* @param[in]: uint32_t timerid,
*
* @return:    Timer_client& 
************************************************************************/
ResultResponse Timer_client::CancelTimer(uint32_t timerid)
{
	RequestCancelTimer request;
	request.set_timerid(timerid);
	ResultResponse reply;

	ClientContext context;
	
	DbgFDbg(DbgDTxt,"Timer_client::CancelTimer() called: %d",timerid);
	Status status = m_stub_->CancelTimer(&context, request, &reply);
	if(!status.ok()){
	    reply.set_result(-1);
	    DbgFDbg(DbgDTxt,"%d : %s", status.error_code(), status.error_message());
	}
	return reply;
}
/************************************************************************
* Function Name: ResultResponse Timer_client::CancelTimer(uint32_t timerid)
*
* @brief:  TimeoutNotification is a function to handle the timeout of timerIDs
*                               
* @param[in]: uint32_t timerid,
*
* @return:    Timer_client& 
************************************************************************/
Status Timer_client::TimeoutNotification(ServerContext* context, const RequestTimeoutNotification* request, ResultResponse* reply) 
{
       std::string userdata = request->userdata();
       int32_t userid = request->userid();
       uint32_t timerid = request->timerid();
       Status retStatus;
       DbgFDbg(DbgDTxt,"TimeoutNotification got called for userid : %d,timerid = %d", userid,timerid);
       if(SUCCESS == Timer_wrap_timeout_notify(userid, timerid, const_cast<char*>(userdata.c_str())))// 1st param = key
       {
            reply->set_cause("Timeout notification received for expected timer and user ids");
	    reply->set_result(500);
	    retStatus = Status::OK;
       }
       else
       {
	    reply->set_cause("Timeout notification received for incorrect User or Timer Id");
	    reply->set_result(204);
	    retStatus = Status::OK;
       }
       return retStatus;
}

