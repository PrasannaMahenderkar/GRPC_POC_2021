/**********************************************************************
*                                                                     *
* NEC TECHNOLOGIES INDIA CONFIDENTIAL AND PROPRIETARY                 *
*                                                                     *
* COPYRIGHT (C) NEC CORPORATION INDIA, LTD 2021                       *
*                                                                     *
* ALL RIGHTS RESERVED BY NEC CORPORATION, LTD. THIS PROGRAM MUST      *
* BE USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY        *
* NEC CORPORATION, LTD. NO PART OF THIS PROGRAM MAY BE REPRODUCED     *
* OR DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN      *
* PERMISSION OF NEC CORPORATION, LTD.                                 *
*                                                                     *
*USE OF COPYRIGHT NOTICE DOES NOT EVIDENCE PUBLICATION OF THE PROGRAM.*
*                                                                     *
* NEC CORPORATION CONFIDENTIAL AND PROPRIETARY                        *
*                                                                     *
**********************************************************************/ 
/*
 * Title: Timer_wrap.cc
 * Description : This file contains wrapper code to send request to Timer 
 * client over Grpc
 * Revision History
 * Owner                Date                Reason for change  
 * Prasanna M	        20-01-2020          Initial version created
 **********************************************************************/ 
#include <arpa/inet.h>
#include <errno.h>
#include <netdb.h>
#include <netinet/in.h>
#include <pthread.h>
#include <string.h>
#include "Timer_wrap.h"
#include "Timer_client.h"
#include "Tmg_if_CommonDebug.h"
#include "Timer_service_lpc_if.h"

uint32_t g_module_num;
Timer_client clientObj;
int g_set_timer_status = 0;
uint32_t g_cancelTimerId = 0;
struct stTimer_wrap_TimerData tstTmData{};
pthread_mutex_t mlock;

char *g_servicename = NULL; /**<  it contains service name of this pod */
char *g_timer_pod_ip = NULL; /**< It stored pod ip address */
/************************************************************************
* Function Name: Timer_wrap_init()
*
* @brief:  initialization function
*                               
* @param[in]: None
*
* @return:    None
************************************************************************/
void Timer_wrap_init()
{
    char buf[256];
    struct hostent* host_entry;
    char* IPbuf = NULL;    
    char* port = NULL;

    g_timer_pod_ip = getenv("TIMER_POD_ADDRPORT"); 
    DbgFDbg(DbgDTxt,"Timer Pod Address : %s",g_timer_pod_ip);
    
    port = getenv("CMME_TMG_PORT");
    DbgFDbg(DbgDTxt,"CMME_TMG_PORT : %s",port);    
    
    if(FAILURE != gethostname(buf, sizeof(buf)))
    {   
    	// To retrieve host information
    	host_entry = gethostbyname(buf);
    }
    
    // To convert an Internet network
    // address into ASCII string
    IPbuf = inet_ntoa(*((struct in_addr*)host_entry->h_addr_list[0]));
    DbgFDbg(DbgDTxt,"Host IP: %s", IPbuf);
    
    strcat(IPbuf+1,":");
    strcat(IPbuf+4,port);
    
    DbgFDbg(DbgDTxt,"Host ADDRPORT: %s", IPbuf);  
    g_servicename = IPbuf;
}
/************************************************************************
* Function Name: Timer_wrap_timer_set(char* servicenm, int32_t userid, uint32_t timerid, char* userdata, int64_t timeout)
*
* @brief:  This function is used to set the timer through this wrapper function
*                               
* @param[in]: char* servicenm, 
*             int32_t userid,
*             uint32_t timerid, 
*             char* userdata, 
*             int64_t timeout
*
* @return:    None
************************************************************************/
void Timer_wrap_timer_set(char* servicenm, int32_t userid, uint32_t timerid, char* userdata, int64_t timeout)
{
    ResultResponse response;
    response = clientObj.SetTimer(servicenm, userid, timerid, userdata, timeout);
    DbgFDbg(DbgDTxt,"Response result received: %d, Response cause received : %s",response.result(),response.cause());
    if(response.result() == 204)
	DbgFDbg(DbgDTxt,"Timer Id : %d, set successfully",timerid);
    else
        DbgFDbg(DbgDTxt,"Timer Id : %d not set ",timerid);
}
/************************************************************************
* Function Name: Timer_wrap_timer_cancel(uint32_t timerID)
*
* @brief:  This function is used to cancel the timer
*                               
* @param[in]: uint32_t timerID  
*
* @return:    None
************************************************************************/
void Timer_wrap_timer_cancel(uint32_t timerID)
{
    ResultResponse response;
    response = clientObj.CancelTimer(timerID);
    DbgFDbg(DbgDTxt,"Response result received: %d, Response cause received : %s",response.result(),response.cause());
    if(response.result() == 204)
      DbgFDbg(DbgDTxt,"Cancelled Timer successfully with Timer ID : %d ", timerID); 
}
/************************************************************************
* Function Name: Timer_wrap_client_run(void* param) 
*
* @brief:  This function is used to run the client thread to send the set and cancel timer request
*                               
* @param[in]: void* param
*
* @return:   0
************************************************************************/
void *Timer_wrap_client_run(void* param) 
{
    //char* clientAddr = (char*)param;
    std::string clientAddress(g_timer_pod_ip); //amf-timer.ns-nec-cnf-timer.svc.cluster.local, 10.106.142.59:8082
    DbgFDbg(DbgDTxt, "Timer_wrap_client_run() called with client Address : %s\n", clientAddress);
    Timer_client client(grpc::CreateChannel(clientAddress, grpc::InsecureChannelCredentials()));
    clientObj = client; 

    if (pthread_mutex_init(&mlock, NULL) != 0) {
        DbgFDbg(DbgDTxt, "mutex init has failed");
   }
   for(;;)
   {
        pthread_mutex_lock(&mlock);
	if(g_set_timer_status == 1)
	{	
	    Timer_wrap_timer_set(tstTmData.servicename, tstTmData.userID, tstTmData.timerID, tstTmData.userdata, tstTmData.timeout);
	    g_set_timer_status = 0;
	}
        else if(g_set_timer_status == 2)
	{
            DbgFDbg(DbgDTxt,"g_cancelTimerId : %d",g_cancelTimerId);
	    Timer_wrap_timer_cancel(g_cancelTimerId);
	    g_set_timer_status = 0;
	}
	else
	{
	}  
        pthread_mutex_unlock(&mlock);
    }  
    pthread_mutex_destroy(&mlock);
    return 0;
}
/************************************************************************
* Function Name: *Timer_wrap_server_run(void* param)
*
* @brief:  This function is used to cancel the timer
*                               
* @param[in]: void* param
*
* @return:    0
************************************************************************/
//Timer_wrap_server_run : Server listens to Timer pod
void *Timer_wrap_server_run(void* param)
{
    ServerBuilder builder;
    builder.AddListeningPort(g_servicename, grpc::InsecureServerCredentials());
    builder.RegisterService(&clientObj);

    std::unique_ptr<Server> server(builder.BuildAndStart());
    DbgFDbg(DbgDTxt, "Server listening on port: %s", g_servicename);
    server->Wait();
    return 0;
}
/************************************************************************
* Function Name: Timer_wrap_timeout_notify(int32_t userid, uint32_t timerid, char* userdata)
*
* @brief:  This function will be called on receiving timeout notification and to set the TO bit in kvs db
*                               
* @param[in]: int32_t userid,
*             uint32_t timerid, 
*             char* userdata
*
* @return:    SUCCESS or FAILURE
************************************************************************/
int32_t Timer_wrap_timeout_notify(int32_t userid, uint32_t timerid, char* userdata)
{
   DbgFDbg(DbgDTxt,"Timer_wrap_timeout_notify() called, userdata:  %s",userdata);
   stTimerData tmdata;
   tmdata.userid = (eMmp_module_userid)userid;
   tmdata.timerid = timerid;
   tmdata.userdata = (char*)malloc(strlen(userdata));
   tmdata.userdata_size = strlen(userdata);
   //tmdata.timeout = 0; // This parameter in notification is unused.
   if(Jlpc_OK != Timer_Service_lpctimeout_notify(tmdata))
   { 
      return FAILURE;
   }
   return SUCCESS;
}
/************************************************************************
* Function Name: Timer_wrap_settimer(stTimer_wrap_TimerData tmdata)
*
* @brief:  This function is used to set the timer status so that client thread checks if 
*            settimer is set and triggers settimer over GRPC
*                               
* @param[in]: stTimer_wrap_TimerData tmdata
*
* @return:    None
************************************************************************/
void Timer_wrap_settimer(stTimer_wrap_TimerData tmdata)
{
    pthread_mutex_lock(&mlock);
    g_set_timer_status = 1; 
    tstTmData.userID = tmdata.userID;
    tstTmData.timerID = tmdata.timerID;
    tstTmData.userdata = tmdata.userdata;
    tstTmData.timeout = tmdata.timeout;
    tstTmData.servicename = (char*)malloc(strlen(g_servicename)+1);
    tstTmData.userdata = (char*)malloc(strlen(tmdata.userdata)+1);    
    
    strcpy(tstTmData.servicename,g_servicename);
    strcpy(tstTmData.userdata,tmdata.userdata);
    pthread_mutex_unlock(&mlock);
    DbgFDbg(DbgDTxt,"tstTmData.servicename : %s", tstTmData.servicename);
   // free(tmdata.servicename);
    free(tmdata.userdata);   
}
/************************************************************************
* Function Name: Timer_wrap_canceltimer(uint32_t timerID)
*
* @brief:  This function is used to set the cancel timerid 
*                               
* @param[in]: uint32_t timerID
*
* @return:    None
************************************************************************/
void Timer_wrap_canceltimer(uint32_t timerID)
{
    DbgFDbg(DbgDTxt,"CancelWrpTimer() called :%d", timerID);
    pthread_mutex_lock(&mlock);
    g_set_timer_status = 2;
    g_cancelTimerId = timerID;
    pthread_mutex_unlock(&mlock);
}
/************************************************************************
* Function Name: Timer_wrap_modulenum_set(uint32_t num)
*
* @brief:  This function is used to set the module number
*                               
* @param[in]: uint32_t num
*
* @return:    None
************************************************************************/
void Timer_wrap_modulenum_set(uint32_t num)
{
   g_module_num = num;
}
