#ifndef _TIMER_WRAP_H_
#define _TIMER_WRAP_H_
/**********************************************************************
*                                                                     *
* NEC TECHNOLOGIES INDIA CONFIDENTIAL AND PROPRIETARY                 *
*                                                                     *
* COPYRIGHT (C) NEC CORPORATION INDIA, LTD 2021                       *
*                                                                     *
* ALL RIGHTS RESERVED BY NEC CORPORATION, LTD. THIS PROGRAM MUST      *
* BE USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY        *
* NEC CORPORATION, LTD. NO PART OF THIS PROGRAM MAY BE REPRODUCED     *
* OR DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN      *
* PERMISSION OF NEC CORPORATION, LTD.                                 *
*                                                                     *
*USE OF COPYRIGHT NOTICE DOES NOT EVIDENCE PUBLICATION OF THE PROGRAM.*
*                                                                     *
* NEC CORPORATION CONFIDENTIAL AND PROPRIETARY                        *
*                                                                     *
**********************************************************************/ 
/*
 * Title: Timer_wrap.cc
 * Description : This file contains wrapper code to send request to Timer
 *  client
 * Revision History
 * Owner                Date                Reason for change  
 * Prasanna M	        20-01-2022          Initial version created
 **********************************************************************/ 
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif

/** @struct timer_wrap_stTimerData
 * stTimerData defintion
 */
struct stTimer_wrap_TimerData{
    char* servicename;
    int32_t userID;
    uint32_t timerID;
    char* userdata;
    int64_t timeout;
    uint32_t result;
};

void Timer_wrap_timer_set(char* servicenm, int32_t userid, uint32_t timerid, char* userdata, int64_t timeout);
void Timer_wrap_timer_cancel(uint32_t timerID);
void *Timer_wrap_server_run(void *param);
void *Timer_wrap_client_run(void* param);
int32_t Timer_wrap_timeout_notify(int32_t timerIdKey, uint32_t timerId, char* userdata);
void Timer_wrap_settimer(struct stTimer_wrap_TimerData tmdata);
void Timer_wrap_canceltimer(uint32_t timerID);
void Timer_wrap_modulenum_set(uint32_t num);
void Timer_wrap_init();
#ifdef __cplusplus
}
#endif

#endif /*_TIMER_WRAP_H_ */
/*--- END of FILE ------------------------------------------------------*/

