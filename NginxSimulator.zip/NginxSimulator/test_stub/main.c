/**********************************************************************
*                                                                     *
* NEC TECHNOLOGIES INDIA CONFIDENTIAL AND PROPRIETARY                 *
*                                                                     *
* COPYRIGHT (C) NEC CORPORATION INDIA, LTD 2021                       *
*                                                                     *
* ALL RIGHTS RESERVED BY NEC CORPORATION, LTD. THIS PROGRAM MUST      *
* BE USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY        *
* NEC CORPORATION, LTD. NO PART OF THIS PROGRAM MAY BE REPRODUCED     *
* OR DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN      *
* PERMISSION OF NEC CORPORATION, LTD.                                 *
*                                                                     *
*USE OF COPYRIGHT NOTICE DOES NOT EVIDENCE PUBLICATION OF THE PROGRAM.*
*                                                                     *
* NEC CORPORATION CONFIDENTIAL AND PROPRIETARY                        *
*                                                                     *
**********************************************************************/  
/*
 * Title: main.c
 * Description : This file contains wrapper code to send request to Timer
 *  client
 * Revision History
 * Owner                Date                Reason for change  
 * Prasanna M	        20-01-2020          Initial version created
 **********************************************************************/ 
#include <stdio.h>
#include "Timer_wrap.h"
#include <pthread.h>	
#include <stdlib.h>
#include <string.h>
#include "DbgCom.h"

void Testcase1_SetCancelTimer();
void Testcase2_SetCancelTimer();
void Testcase3_SetCancelTimer();
void Testcase4_SetCancelTimer();
void Testcase5_SetCancelTimerWithInvalidUser();
void Testcase6_SetCancelTimerWithZeroTimeOut();
void Testcase7_SetCancelTimerWithEmptyUserdata();
void Testcase8_SetCancelTimerWithInvalidTimeOut();
void Testcase9_SetCancelTimerWithCallBackRegister();

void timeout_notify_testcallback(int32_t userid, uint32_t timerid, char* userdata)
{
    DbgFDbg(DbgDTxt,"timeout_notify_testcallback() called");
}

//TestCase to set and cancel Same Timer Id
//
//export CMME_CNC_TIMER_GRPC_SERVICE=172.30.63.126:8080
//export CMME_VLR_TIMER_GRPC_SERVICE=172.30.63.126:8080
//export TIMER_POD_ADDRPORT=amf-timer.ns-nec-cnf-timer.svc.cluster.local:8082
void Testcase1_SetCancelTimer()
{
    DbgFDbg(DbgDTxt,"-------------- Testcase1_SetCancelTimer() -----------------");
    sleep(5);
    stTimer_wrap_TimerData tmdata;
    tmdata.userID = eMmp_module_userid::MMP_EGP_MODULE;
    tmdata.timerID = 1;
    tmdata.userdata="0651";
    tmdata.userdata[4] = 0x67;
    Timer_wrap_timeout_notify(tmdata.userID,tmdata.timerID,tmdata.userdata);   

   // Timer_wrap_settimer(tmdata);
    sleep(5);
   // Timer_wrap_canceltimer(tmdata.timerID);
}

/*
//TestCase to cancel Timer Id which is not set
void Testcase2_SetCancelTimer()
{
   DbgFDbg(DbgDTxt,"-------------- Testcase2_SetCancelTimer() -----------------");
   sleep(5);
   Timer_wrap_canceltimer(2); //Cancelling timer which is not set
}

//TestCase to set the Same Timer Id again
void Testcase3_SetCancelTimer()
{
    DbgFDbg(DbgDTxt,"-------------- Testcase3_SetCancelTimer() -----------------");
    sleep(5);
    stTimer_wrap_TimerData tmdata;
    char* servicename = "127.0.0.1:5001";
    tmdata.userID = eMmp_module_userid::MMP_ELC_MODULE;
    tmdata.timerID = 4;
    tmdata.timeout = 100;
        
    tmdata.userdata_size = 6;
    Timer_wrap_servicename_set(servicename); 
    memcpy(tmdata.userdata,"0653",4);
    tmdata.userdata[4] = 0x01;
    tmdata.userdata[5] = 0x34;
    Timer_wrap_settimer(tmdata);
    sleep(5);
    Timer_wrap_settimer(tmdata);
}

//TestCase to set, cancel Same Timer Id and cancel the same timer Id again
void Testcase4_SetCancelTimer()
{
    DbgFDbg(DbgDTxt,"-------------- Testcase4_SetCancelTimer() -----------------");
    sleep(5);
    stTimer_wrap_TimerData tmdata;
    char* servicename = "127.0.0.1:5001";
    tmdata.userID = eMmp_module_userid::MMP_ELC_MODULE;
    tmdata.timerID = 5;
    tmdata.timeout = 100;
        
    tmdata.userdata_size = 6;
 
    Timer_wrap_servicename_set(servicename); 
    memcpy(tmdata.userdata,"0653",4);//process id : 653 and 01 is some other data
    tmdata.userdata[4] = 0x56;
    tmdata.userdata[5] = 0x78;
    Timer_wrap_settimer(tmdata);
    sleep(10);
    Timer_wrap_canceltimer(tmdata.timerID);
    sleep(5);
    Timer_wrap_canceltimer(tmdata.timerID);
}

//TestCase to call settimer with invalid userId
void Testcase5_SetCancelTimerWithInvalidUser()
{
    DbgFDbg(DbgDTxt,"-------------- Testcase5_SetCancelTimerWithInvalidUser() -----------------");
    sleep(5);
    stTimer_wrap_TimerData tmdata;
    char* servicename = "127.0.0.1:5001";
    tmdata.userID = (eMmp_module_userid)0;
    tmdata.timerID = 5;
    tmdata.timeout = 300;
        
    tmdata.userdata_size = 7;
   
    Timer_wrap_servicename_set(servicename); 
    strncpy(tmdata.userdata,"0653",4);//process id : 653 and 01 is some other data
    tmdata.userdata[4] = 0x56;
    tmdata.userdata[5] = 0x68;
    tmdata.userdata[6] = 0x89;

    Timer_wrap_settimer(tmdata);
}

//TestCase to call settimer with 0 TimeOut
void Testcase6_SetCancelTimerWithZeroTimeOut()
{
   DbgFDbg(DbgDTxt,"-------------- Testcase6_SetCancelTimerWithZeroTimeOut() -----------------");
    sleep(5);
    stTimer_wrap_TimerData tmdata;
    char* servicename = "127.0.0.1:5001";
    tmdata.userID = eMmp_module_userid::MMP_E1M_MODULE;
    tmdata.timerID = 6;
    tmdata.timeout = 0;
        
    tmdata.userdata_size = 6;
    Timer_wrap_servicename_set(servicename); 
    strncpy(tmdata.userdata,"0653",4);//process id : 653 and 01 is some other data
    tmdata.userdata[4] = 0x56;
    tmdata.userdata[5] = 0x89;
    Timer_wrap_settimer(tmdata);
}

//TestCase to call settimer with Empty user Data
void Testcase7_SetCancelTimerWithEmptyUserdata()
{
   DbgFDbg(DbgDTxt,"-------------- Testcase7_SetCancelTimerWithInvalidPodId() -----------------");
    sleep(5);
    stTimer_wrap_TimerData tmdata;
    char* servicename = "127.0.0.1:5001";
    tmdata.userID = eMmp_module_userid::MMP_EMC_MODULE;
    tmdata.timerID = 6;
    tmdata.timeout = 0;    
    tmdata.userdata_size = 6;      
    Timer_wrap_servicename_set(servicename); 
    memcpy(tmdata.userdata,"0653",4);//process id : 653 and 01 is some other data
    tmdata.userdata[4] = 0x56;
    tmdata.userdata[5] = 0x89;
    Timer_wrap_settimer(tmdata);
}

//TestCase to call settimer with invalid TimeOut
void Testcase8_SetCancelTimerWithInvalidTimeOut()
{
   DbgFDbg(DbgDTxt,"--------------Testcase10_SetCancelTimerWithInvalidTimeOut() -----------------");
    sleep(5);
    stTimer_wrap_TimerData tmdata;
    char* servicename = "127.0.0.1:5001";
    tmdata.userID = eMmp_module_userid::MMP_E1M_MODULE;
    tmdata.timerID = 6;
    tmdata.timeout = -1;    
    tmdata.userdata_size = 6;      
    Timer_wrap_servicename_set(servicename); 
    memcpy(tmdata.userdata,"0653",4);//process id : 656 and 56 is some other data
    tmdata.userdata[4] = 0x56;
    tmdata.userdata[5] = 0x89;
    Timer_wrap_settimer(tmdata);
}

//TestCase to call settimer with callback registered
void Testcase9_SetCancelTimerWithCallBackRegister()
{
   DbgFDbg(DbgDTxt,"--------------Testcase10_SetCancelTimerWithInvalidTimeOut() -----------------");
    sleep(5);
    stTimer_wrap_TimerData tmdata;
    char* servicename = "127.0.0.1:5001";
    tmdata.userID = eMmp_module_userid::MMP_E1M_MODULE;
    tmdata.timerID = 7;
    tmdata.timeout = 100;    
    tmdata.userdata_size = 6; 

    stTimeoutData tstTimeoutData;    
    tstTimeoutData.modulenum = MMP_E1M_MODULE;
    tstTimeoutData.timertype = 21;
    tstTimeoutData.TimeoutCBfunctionptr = &timeout_notify_testcallback;
    Timer_wrap_servicename_set(servicename); 
    memcpy(tmdata.userdata,"0653",4);//process id : 653 and 56 is some other data
    tmdata.userdata[4] = 0x56;
    tmdata.userdata[5] = 0x67;
    Timer_wrap_settimer(tmdata);
}*/
int main()
{
    DbgFTrc(DbgDTxt,"------------main() called -----------");
    
    pthread_t serverThread, clientThread;
	uint32_t processid = CNC_PROCID;
    Timer_wrap_init();
    pthread_create(&clientThread, NULL, Timer_wrap_client_run, NULL);
    pthread_create(&serverThread, NULL, Timer_wrap_server_run, &processid);


    Testcase1_SetCancelTimer();
   /* Testcase2_SetCancelTimer();
    Testcase3_SetCancelTimer();
    Testcase4_SetCancelTimer();
    Testcase5_SetCancelTimerWithInvalidUser();
    Testcase6_SetCancelTimerWithZeroTimeOut();
    Testcase7_SetCancelTimerWithEmptyUserdata();
    Testcase8_SetCancelTimerWithInvalidTimeOut();
    Testcase9_SetCancelTimerWithCallBackRegister();*/

    // wait for threads to finish
    pthread_join(serverThread,NULL);
    pthread_join(clientThread,NULL);
}



