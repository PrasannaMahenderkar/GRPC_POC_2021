#ifndef _TIMER_CLIENT_H_
#define _TIMER_CLIENT_H_
/**********************************************************************
*                                                                     *
* NEC TECHNOLOGIES INDIA CONFIDENTIAL AND PROPRIETARY                 *
*                                                                     *
* COPYRIGHT (C) NEC CORPORATION INDIA, LTD 2021                       *
*                                                                     *
* ALL RIGHTS RESERVED BY NEC CORPORATION, LTD. THIS PROGRAM MUST      *
* BE USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY        *
* NEC CORPORATION, LTD. NO PART OF THIS PROGRAM MAY BE REPRODUCED     *
* OR DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN      *
* PERMISSION OF NEC CORPORATION, LTD.                                 *
*                                                                     *
*USE OF COPYRIGHT NOTICE DOES NOT EVIDENCE PUBLICATION OF THE PROGRAM.*
*                                                                     *
* NEC CORPORATION CONFIDENTIAL AND PROPRIETARY                        *
*                                                                     *
**********************************************************************/ 
/*
 * Title: Timer_client.h
 * Description : This file contains client code to interact with Timer pod
 * over Grpc
 * Revision History
 * Owner                Date                Reason for change  
 * Prasanna M	        20-01-2020          Initial version created
 **********************************************************************/ 
#include <grpcpp/grpcpp.h>
#include "timer.grpc.pb.h"
#include <string>
#include <map>
using grpc::Channel;
using grpc::ClientContext;
using grpc::Status;
using grpc::Server;
using grpc::ServerBuilder;
using grpc::ServerContext;

using timer::Timer;
using timer::RequestTimeoutNotification;
using timer::ResultResponse;

class Timer_client final : public Timer::Service {
    public:
    Timer_client() = default;
    //Timer_client(std::shared_ptr<Channel> channel);
    Timer_client(const Timer_client& client);
    Timer_client& operator=(const Timer_client& client);
    ~Timer_client();
    Status TimeoutNotification(ServerContext* context, const RequestTimeoutNotification* request, ResultResponse* reply) override;
    ResultResponse TimerClientTimeoutNotify(int32_t userid, uint32_t timerId, std::string userdata);
	void Create_insertGrpcChannel(uint32_t procid, std::shared_ptr<Channel> channel);
    private:
	//typedef std::unique_ptr<Timer::Stub> stubObj;
    //stubObj m_stub_;
	std::map<uint32_t,std::unique_ptr<Timer::Stub>> m_stubMap;
};

#endif/* _TIMER_CLIENT_H_ */
/*--- END of FILE ------------------------------------------------------*/
