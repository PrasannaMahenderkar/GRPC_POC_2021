#ifndef _TIMER_WRAP_H_
#define _TIMER_WRAP_H_
/**********************************************************************
*                                                                     *
* NEC TECHNOLOGIES INDIA CONFIDENTIAL AND PROPRIETARY                 *
*                                                                     *
* COPYRIGHT (C) NEC CORPORATION INDIA, LTD 2021                       *
*                                                                     *
* ALL RIGHTS RESERVED BY NEC CORPORATION, LTD. THIS PROGRAM MUST      *
* BE USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY        *
* NEC CORPORATION, LTD. NO PART OF THIS PROGRAM MAY BE REPRODUCED     *
* OR DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN      *
* PERMISSION OF NEC CORPORATION, LTD.                                 *
*                                                                     *
*USE OF COPYRIGHT NOTICE DOES NOT EVIDENCE PUBLICATION OF THE PROGRAM.*
*                                                                     *
* NEC CORPORATION CONFIDENTIAL AND PROPRIETARY                        *
*                                                                     *
**********************************************************************/ 
/*
 * Title: Timer_wrap.cc
 * Description : This file contains wrapper code to send request to Timer
 *  client
 * Revision History
 * Owner                Date                Reason for change  
 * Prasanna M	        20-01-2022          Initial version created
 **********************************************************************/ 
#include <stdint.h>
#include <string>
#ifdef __cplusplus
extern "C" {
#endif

#define MAX_USERDATA_SIZE 40

/* MMP Module Numbers */
typedef enum eMmp_module_userid
{
MMP_EMC_MODULE = 1,
MMP_EDC_MODULE,
MMP_E1M_MODULE,
MMP_ECC_MODULE,
MMP_EGG_MODULE,
MMP_ELC_MODULE,
MMP_EGP_MODULE,
MMP_EGT_MODULE,
MMP_EGX_MODULE,
MMP_EOC_MODULE,
MMP_EVC_MODULE
}eMmp_module_userid;

typedef enum eMmp_process_id
{
	NO_PROCID = 0,
	CNC_PROCID = 651,
	EQP_PROCID = 652,
	VLR_PROCID = 653,
	OAM_PROCID = 654,
	CDR_PROCID = 655,
	TRF_PROCID = 656,
	CFG_PROCID = 657,
	SGS_PROCID = 659,
	DIA_PROCID = 661,
	LCS_PROCID = 662,
	CBS_PROCID = 663
	
}eMmp_process_id;

typedef enum eTimerStatus{
	NO_TIMER = 0,
	SET_TIMER = 1,
	CANCEL_TIMER = 2,
    TIMEOUT_NOTIFY = 3
}eTimerStatus;
/** @struct timer_wrap_stTimerData
 * stTimerData defintion
 */
typedef struct stTimer_wrap_TimerData{
    eMmp_module_userid userID;
    uint32_t timerID;
	std::string userdata;
}stTimer_wrap_TimerData;

void *Timer_wrap_server_run(void *param);
void *Timer_wrap_client_run(void* param);
void Timer_wrap_modulenum_set(uint32_t num);
void Timer_wrap_init();
void Timer_wrap_servicename_set(char* servicenm);
void Timer_wrap_servicename_create(uint32_t processid);
int32_t Timer_wrap_timeout_notify(int32_t userid, uint32_t timerId, std::string userdata);
#ifdef __cplusplus
}
#endif

#endif /*_TIMER_WRAP_H_ */
/*--- END of FILE ------------------------------------------------------*/

