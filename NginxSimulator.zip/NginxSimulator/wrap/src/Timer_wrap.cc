/**********************************************************************
*                                                                     *
* NEC TECHNOLOGIES INDIA CONFIDENTIAL AND PROPRIETARY                 *
*                                                                     *
* COPYRIGHT (C) NEC CORPORATION INDIA, LTD 2021                       *
*                                                                     *
* ALL RIGHTS RESERVED BY NEC CORPORATION, LTD. THIS PROGRAM MUST      *
* BE USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY        *
* NEC CORPORATION, LTD. NO PART OF THIS PROGRAM MAY BE REPRODUCED     *
* OR DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN      *
* PERMISSION OF NEC CORPORATION, LTD.                                 *
*                                                                     *
*USE OF COPYRIGHT NOTICE DOES NOT EVIDENCE PUBLICATION OF THE PROGRAM.*
*                                                                     *
* NEC CORPORATION CONFIDENTIAL AND PROPRIETARY                        *
*                                                                     *
**********************************************************************/ 
/*
 * Title: Timer_wrap.cc
 * Description : This file contains wrapper code to send request to Timer 
 * client over Grpc
 * Revision History
 * Owner                Date                Reason for change  
 * Prasanna M	        20-01-2020          Initial version created
 **********************************************************************/ 
#include <pthread.h>
#include <string.h>
#include "Timer_wrap.h"
#include "Timer_client.h"
#include "Tmg_if_CommonDebug.h"

#define TOINDEX 15
Timer_client clientObj;
struct stTimer_wrap_TimerData tstTmData{};
pthread_mutex_t mlock;
int g_set_timer_status = NO_TIMER;
char *g_servicename = NULL; /**<  it contains service name of this pod */
char *g_timer_pod_addr = NULL; /**< It stored pod ip address */

/************************************************************************
* Function Name: Timer_wrap_init()
*
* @brief:  initialization function
*                               
* @param[in]: None
*
* @return:    None
************************************************************************/
void Timer_wrap_init()
{
	g_timer_pod_addr = getenv("TIMER_POD_ADDRESS"); 
	if(g_timer_pod_addr != NULL)
		DbgFTrc(DbgDTxt,"Timer_wrap_init()  called , Timer Pod Address : %s",g_timer_pod_addr);
	else
		DbgFErr(DbgDTxt,"Timer_wrap_init()  called ,Timer Pod address is not valid");
	Timer_client client;
	clientObj = client; 
	for(int procid = CNC_PROCID; procid <= (int)CBS_PROCID; ++procid)
	{
		Timer_wrap_servicename_create(procid);
		if(g_servicename != NULL)
		{
			std::string clientAddress(g_servicename); 
			client.Create_insertGrpcChannel(procid,grpc::CreateChannel(clientAddress, grpc::InsecureChannelCredentials()));
		}
	}
}
/************************************************************************
* Function Name: Timer_wrap_client_run(void* param) 
*
* @brief:  This function is used to run the client thread to send the set and cancel timer request
*                               
* @param[in]: void* param
*
* @return:   0
************************************************************************/
void *Timer_wrap_client_run(void* param) 
{
    if (pthread_mutex_init(&mlock, NULL) != 0) {
        DbgFErr(DbgDTxt, "mutex init has failed");
   }
   for(;;)
   {
        pthread_mutex_lock(&mlock);
		if(g_set_timer_status == TIMEOUT_NOTIFY)
		{	
			ResultResponse response;
			response = clientObj.TimerClientTimeoutNotify(tstTmData.userID,tstTmData.timerID,tstTmData.userdata);
			g_set_timer_status = NO_TIMER;
		}
        pthread_mutex_unlock(&mlock);
    }  
    pthread_mutex_destroy(&mlock);
    return 0;
}
/************************************************************************
* Function Name: *Timer_wrap_server_run(void* param)
*
* @brief:  This function is used to cancel the timer
*                               
* @param[in]: void* param
*
* @return:    0
************************************************************************/
//Timer_wrap_server_run : Server listens to Timer pod
void *Timer_wrap_server_run(void* param)
{
    ServerBuilder builder;
	eReturnValue ret = SUCCESS;
	if(g_timer_pod_addr == NULL)
	{
		DbgFErr(DbgDTxt,"Timer_wrap_server_run() called with invalid timer pod address\n");
		ret = ERROR;
	}
	if(ret == SUCCESS)
	{
		builder.AddListeningPort(g_timer_pod_addr, grpc::InsecureServerCredentials());
		builder.RegisterService(&clientObj);

		std::unique_ptr<Server> server(builder.BuildAndStart());
		DbgFTrc(DbgDTxt, "Server listening on port: %s", g_timer_pod_addr);
		server->Wait();
	}
    return 0;
}
/************************************************************************
* Function Name: Timer_wrap_modulenum_set(uint32_t num)
*
* @brief:  This function is used to set the module number
*                               
* @param[in]: uint32_t num
*
* @return:    None
************************************************************************/
void Timer_wrap_servicename_set(char* servicenm)
{
    g_servicename = servicenm;
}
/************************************************************************
* Function Name: Timer_wrap_servicename_create(uint32_t processid)
*
* @brief:  This function is used to create the servicename from process id which is used in settimer 
* API to send over grpc and getback the timeout notification on same service name.
*                               
* @param[in]: uint32_t processid
*
* @return:    None
************************************************************************/
void Timer_wrap_servicename_create(uint32_t processid)
{
	char* serviceName = NULL;
	DbgFTrc(DbgDTxt,"Timer_wrap_servicename_create() called :%d", processid);
	switch((eMmp_process_id)processid)
	{
		case CNC_PROCID: 
		 serviceName = getenv("CMME_CNC_TIMER_GRPC_SERVICE"); // this variable will contain this pods serviceurl:process port
		 break;
		case EQP_PROCID: 
		 serviceName = getenv("CMME_EQP_TIMER_GRPC_SERVICE");
		 break; 
		case VLR_PROCID: 
		 serviceName = getenv("CMME_VLR_TIMER_GRPC_SERVICE");
		 break;
		case OAM_PROCID: 
		 serviceName = getenv("CMME_OAM_TIMER_GRPC_SERVICE");
		 break;
		case CDR_PROCID: 
		 serviceName = getenv("CMME_CDR_TIMER_GRPC_SERVICE");
		 break;
		case TRF_PROCID: 
		 serviceName = getenv("CMME_TRF_TIMER_GRPC_SERVICE");
		 break;
		case CFG_PROCID: 
		 serviceName = getenv("CMME_CFG_TIMER_GRPC_SERVICE");
		 break;
		case SGS_PROCID: 
		 serviceName = getenv("CMME_SGS_TIMER_GRPC_SERVICE");
		 break;
		case DIA_PROCID: 
		 serviceName = getenv("CMME_DIA_TIMER_GRPC_SERVICE");
		 break;
		case LCS_PROCID: 
		 serviceName = getenv("CMME_LCS_TIMER_GRPC_SERVICE");
		 break;
		case CBS_PROCID: 
		 serviceName = getenv("CMME_CBS_TIMER_GRPC_SERVICE");
		 break;
		default:
		 DbgFTrc(DbgDTxt,"No matching process id found");
		 break;
	}
	if(serviceName != NULL)
		Timer_wrap_servicename_set(serviceName);
}
/************************************************************************
* Function Name: Timer_wrap_timeout_notify(int32_t userid, uint32_t timerid, char* userdata)
*
* @brief:  This function will be called on receiving timeout notification and to set the TO bit in kvs db
*                               
* @param[in]: int32_t userid,
*             uint32_t timerid, 
*             char* userdata
*
* @return:    SUCCESS or FAILURE
************************************************************************/
int32_t Timer_wrap_timeout_notify(int32_t userid, uint32_t timerId, std::string userdata)
{
	DbgFTrc(DbgDTxt,"Timer_wrap_timeout_notify() called, userid : %d, userdata:  %s",userid,userdata);
	pthread_mutex_lock(&mlock);
	tstTmData.userID = (eMmp_module_userid)userid;
	tstTmData.timerID = timerId;
	tstTmData.userdata = std::string(userdata);
	g_set_timer_status = TIMEOUT_NOTIFY;
	pthread_mutex_unlock(&mlock);
	return SUCCESS;
}