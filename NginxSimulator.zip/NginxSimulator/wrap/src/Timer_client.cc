/**********************************************************************
*                                                                     *
* NEC TECHNOLOGIES INDIA CONFIDENTIAL AND PROPRIETARY                 *
*                                                                     *
* COPYRIGHT (C) NEC CORPORATION INDIA, LTD 2021                       *
*                                                                     *
* ALL RIGHTS RESERVED BY NEC CORPORATION, LTD. THIS PROGRAM MUST      *
* BE USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY        *
* NEC CORPORATION, LTD. NO PART OF THIS PROGRAM MAY BE REPRODUCED     *
* OR DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN      *
* PERMISSION OF NEC CORPORATION, LTD.                                 *
*                                                                     *
*USE OF COPYRIGHT NOTICE DOES NOT EVIDENCE PUBLICATION OF THE PROGRAM.*
*                                                                     *
* NEC CORPORATION CONFIDENTIAL AND PROPRIETARY                        *
*                                                                     *
**********************************************************************/ 
/*
 * Title: Timer_client.cc
 * Description : This file contains client code to interact with Timer pod
 * over Grpc
 * Revision History
 * Owner                Date                Reason for change  
 * Prasanna M	        20-01-2020          Initial version created
 **********************************************************************/ 
#include <string.h>
#include "Timer_client.h"
#include "Timer_wrap.h"
#include "Tmg_if_CommonDebug.h"
#include "DbgCom.h"
/************************************************************************
* Function Name: Timer_client(const Timer_client& client)
*
* @brief:  Copy constructor
*                               
* @param[in]: Timer_client
*
* @return:    None
************************************************************************/
Timer_client::Timer_client(const Timer_client& client)
{
	//m_stub_ = std::unique_ptr<Timer::Stub>(client.m_stub_.get());
	//m_stubMap = client.m_stubMap;
	for (const auto &entry : client.m_stubMap)
	{
		auto* stub = entry.second.get();
		m_stubMap.insert(std::pair<uint32_t,std::unique_ptr<Timer::Stub>>(entry.first, std::unique_ptr<Timer::Stub>(stub)));
	}
}
/************************************************************************
* Function Name: ~Timer_client()
*
* @brief:  destructor
*                               
* @param[in]: None
*
* @return:    None
************************************************************************/
Timer_client::~Timer_client()
{
}
/************************************************************************
* Function Name: Timer_client(std::shared_ptr<Channel> channel) 
*
* @brief:  parameterized constructor
*                               
* @param[in]: std::shared_ptr<Channel> channel
*
* @return:    None
************************************************************************/
/*
Timer_client::Timer_client(std::shared_ptr<Channel> channel) 
    : m_stubMap(Timer::NewStub(channel))
{
}*/
/************************************************************************
* Function Name: Timer_client& operator=(const Timer_client& client) 
*
* @brief:  copy Assignment constructor
*                               
* @param[in]: Timer_client&
*
* @return:    Timer_client& 
************************************************************************/
Timer_client& Timer_client::operator=(const Timer_client& client)
{
    if(m_stubMap.size() != 0)
		return *this;
   	for (const auto &entry : client.m_stubMap)
	{
		auto* stub = entry.second.get();
		m_stubMap.insert(std::pair<uint32_t,std::unique_ptr<Timer::Stub>>(entry.first, std::unique_ptr<Timer::Stub>(stub)));
	}
    return *this;
}
/************************************************************************
* Function Name: Create_insertGrpcChannel(std::shared_ptr<Channel> channel) 
*
* @brief:  create and insert the channel into map
*                               
* @param[in]: std::shared_ptr<Channel> channel
*
* @return:    None
************************************************************************/
void Timer_client::Create_insertGrpcChannel(uint32_t procid,std::shared_ptr<Channel> channel)
{
	if(m_stubMap.find(procid) == m_stubMap.end())
		m_stubMap[procid] = std::unique_ptr<Timer::Stub>(Timer::NewStub(channel));
	else
	   DbgFTrc(DbgDTxt,"Timer_client::Create_insertGrpcChannel() proc id : %d already exists\n", procid);
}
/************************************************************************
* Function Name: ResultResponse Timer_client::CancelTimer(uint32_t timerid)
*
* @brief:  TimeoutNotification is a function to handle the timeout of timerIDs
*                               
* @param[in]: uint32_t timerid,
*
* @return:    Timer_client& 
************************************************************************/
Status Timer_client::TimeoutNotification(ServerContext* context, const RequestTimeoutNotification* request, ResultResponse* reply) 
{
       std::string touserdata;
       touserdata.assign(request->userdata().data(),request->userdata().size());
       int32_t userid = request->userid();
       uint32_t timerid = request->timerid();
       Status retStatus;
       DbgFTrc(DbgDTxt,"TimeoutNotification got called for userid : %d,timerid = %d", userid,timerid);
       if(SUCCESS == Timer_wrap_timeout_notify(userid, timerid, touserdata))// 1st param = key
       {
            reply->set_cause("Timeout notification received for expected timer and user ids");
			reply->set_result(500);
			retStatus = Status::OK;
       }
       else
       {
			reply->set_cause("Timeout notification received for incorrect User or Timer Id");
			reply->set_result(204);
			retStatus = Status::OK;
       }
       return retStatus;
}
/************************************************************************
* Function Name: Timer_wrap_timeout_notify(int32_t userid, uint32_t timerid, char* userdata)
*
* @brief:  This function will be called on receiving timeout notification and to set the TO bit in kvs db
*                               
* @param[in]: int32_t userid,
*             uint32_t timerid, 
*             char* userdata
*
* @return:    SUCCESS or FAILURE
************************************************************************/
ResultResponse Timer_client::TimerClientTimeoutNotify(int32_t userid, uint32_t timerId, std::string userdata)
{
	RequestTimeoutNotification request;
	request.set_userdata(std::string(userdata));
	request.set_userid(userid);
	request.set_timerid(timerId);
	ResultResponse reply;
	ClientContext context;
	std::string strprocid;
	strprocid.assign(userdata,4);// procid is 1st 4 bytes in userdata
	uint32_t procid = stoi(strprocid);  
	DbgFTrc(DbgDTxt,"Timer_client::TimerClientTimeoutNotify() called, procid : %d\n",procid);
	auto it = m_stubMap.find(procid);
	if(it != m_stubMap.end())
	{
		Status status = (it->second)->TimeoutNotification(&context, request, &reply);
		if(!status.ok()){
			reply.set_result(-1);
			std::cout << status.error_code() << ": " << status.error_message() << std::endl;
		}
	}
	return reply;
}

