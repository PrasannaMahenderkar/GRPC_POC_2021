#ifndef _TMG_IF_COMMONDEBUG_H_
#define _TMG_IF_COMMONDEBUG_H_
/**********************************************************************
*                                                                     *
* NEC TECHNOLOGIES INDIA CONFIDENTIAL AND PROPRIETARY                 *
*                                                                     *
* COPYRIGHT (C) NEC CORPORATION INDIA, LTD 2021                       *
*                                                                     *
* ALL RIGHTS RESERVED BY NEC CORPORATION, LTD. THIS PROGRAM MUST      *
* BE USED SOLELY FOR THE PURPOSE FOR WHICH IT WAS FURNISHED BY        *
* NEC CORPORATION, LTD. NO PART OF THIS PROGRAM MAY BE REPRODUCED     *
* OR DISCLOSED TO OTHERS, IN ANY FORM, WITHOUT THE PRIOR WRITTEN      *
* PERMISSION OF NEC CORPORATION, LTD.                                 *
*                                                                     *
*USE OF COPYRIGHT NOTICE DOES NOT EVIDENCE PUBLICATION OF THE PROGRAM.*
*                                                                     *
* NEC CORPORATION CONFIDENTIAL AND PROPRIETARY                        *
*                                                                     *
**********************************************************************/ 
/*
 * Title: Tmg_if_CommonDebug.h
 * Description : This file contains common data required for tmg functionality
 * like success, failure return, print statements etc
 * Revision History
 * Owner                Date                Reason for change  
 * Prasanna M	        20-01-2020          Initial version created
 **********************************************************************/ 
#include "DbgCom.h"
/** @enum eReturnValue
 * eReturnValue defintion
 */
enum eReturnValue{
    ERROR = 0,
    SUCCESS = 1,
    FAILURE = -1
};

#endif /* _TMG_IF_COMMONDEBUG_H_ */
/*--- END of FILE ------------------------------------------------------*/
