/***********************************************************************

�Υե����복�ס�    �ģ��ե����������
�ε�ǽ�֥��å�̾��  �ǥХå��ץ�������ʣģ���
�Υ⥸�塼��̾��    �ե��������

    Copyright (C) 2000,2001 NEC Corporation
    NEC CONFIDENTIAL AND PROPRIETARY
    All rights reserved by NEC Corporation.

***********************************************************************/

#ifndef lint
static char ident_DbgfAgTrans_c[] = "$Id: DbgfAgTrans.c,v 1.2 2005/09/13 06:57:56 msaito Exp $";
#endif

#include "opf_func.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>

#include "Opmlib.h"
#include "Lcmlib.h"
#include "Dbg.h"
#include "DbgfAg.h"
#include "DbgCom.h"
#include "dbg_string.h"

int dbg_fifo_num = 0;

#define BUFSIZE 128

int DbgfAgTrans(const DbgsAgDict_t *dict, void *addr)
{
	DbgSConf_t *conf = (DbgSConf_t *) addr;
	FILE *fp;
	char *sg_path;
	char sgfname[BUFSIZE];
	char buf[2048], *token, *last;
	unsigned int i;
	unsigned int node_cnt; /* �Ρ��ɥ�������� */
	int found;
	int ret;
	struct stat stat_buffer;

    /* �ӣǥѥ����� */
    sg_path = getenv( "BASEDIR" );

    bzero( sgfname, BUFSIZE );
    sprintf( sgfname, "%s/real/lib/SG_Dbg", sg_path );

	if((fp = fopen(sgfname, "r")) == NULL) {
		return -1;
	}

    dbg_fifo_num = 0;
    while (fgets(buf, sizeof(buf), fp) != NULL) {
        if (buf[0] == '#' || buf[0] == '\n')
            continue;

        token = strtok_r(buf, "\t\n ", &last);

        for (found = 0, i = 0; (dict + i)->func != NULL; i++) {
            if (!strcmp((dict + i)->word, token)) {
                (dict + i)->func(addr, &last, 0);
                found = 1;
                break;
            }
        }
    }

    fclose(fp);

    if (DBG_PDTFLG_ON == conf->nodeflg || DBG_PDTFLG_ON == conf->nodeinvalidflg) {
        for (node_cnt = 1; node_cnt < DBG_LNODEON_MAX; node_cnt++) {
            /* �ӣǥѥ����� */
            bzero( sgfname, BUFSIZE );
            sprintf( sgfname, "%s/real/lib/SG_Dbg_lnode%02d", sg_path , node_cnt);

            /*  SG¸�ߤ��Ƥ��뤫��Ƚ�� */
            ret = stat(sgfname,&stat_buffer);
            if (0 != ret) {

                if (ENOENT == errno) {
                    DbgFErr(DbgDTxt, "stat(%s) error errno = %d", sgfname,
                        errno );
                    continue;
                }
                DbgFErr(DbgDTxt, "stat(%s) error errno = %d", sgfname, errno);
                return -1;
            }

            if ((fp = fopen(sgfname, "r")) == NULL) {
                return -1;
            }
            
            if (DBG_PDTFLG_ON == conf->nodeflg) {
                dbg_fifo_num = 0;
            }
            
            while(fgets(buf, sizeof(buf), fp) != NULL) {
                if(buf[0] == '#' || buf[0] == '\n') continue;

                token = strtok_r(buf, "\t\n ", &last);

                for(found = 0, i = 0; (dict + i)->func != NULL; i++) {
                    if(!strcmp((dict + i)->word, token)) {
                        (dict + i)->func(addr, &last, node_cnt);
                        found = 1;
                        break;
                    }
                }
            }

            fclose(fp);
        }
    }

	return 0;
}
