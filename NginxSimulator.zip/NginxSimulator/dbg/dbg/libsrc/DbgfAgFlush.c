/***********************************************************************

�Υե����복�ס�    �ģ�� �ƣɣƣϤ��Ǥ��Ф�
�ε�ǽ�֥��å�̾��  �ǥХå��ץ�������ʣģ���
�Υ⥸�塼��̾��    �������

    Copyright (C) 2000,2001 NEC Corporation
    NEC CONFIDENTIAL AND PROPRIETARY
    All rights reserved by NEC Corporation.

***********************************************************************/

#ifndef lint
static char ident_DbgfAgFlush_c[] = "$Id: DbgfAgFlush.c,v 1.1 2004/11/22 09:10:30 youki Exp $";
#endif

#include "opf_func.h"
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include "DbgfAg.h"
#include "DbgCom.h"

#ifndef Min
#define Min(a, b)   (((a) < (b)) ? (a) : (b))
#endif

int DbgfAgFlush(int fd, DbgsAgFifo_t *fifo)
{
	const int	w_off = fifo->w_off;
	const int	e_off = fifo->e_off;
	char		buf[DbgdAgBufSize];
	int			len;
	int			rval;

	if(w_off == fifo->r_off) return 0;

	if(w_off > fifo->r_off) {
		len = w_off - fifo->r_off;
	} else {
		len = e_off - fifo->r_off;
		if(len == 0) {
			fifo->r_off = 0;
			len = w_off - fifo->r_off;
		}
	}

	len = Min(len, sizeof(buf));

	memcpy(buf, &fifo->buf[fifo->r_off], len);
	fifo->r_off += len;

	if((rval = write(fd, buf, len)) != len) {
		return -1;
	}

	return 0;
}
